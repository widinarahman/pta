<?php
  require 'config/config.php';
  require '_header.php';

  $result=tampiladmin();
 ?>
<div class="container">
  <div class="content">
    <h4>Data Pembayaran</h4>
    <ol class="breadcrumb">
      <li class="ti-panel">
        <a href="?">Dasboard</a>
      </li>
      <li class="active">
        Data Pembayaran
      </li>
    </ol>
    <div class="row">
      <div class="col-lg-5">
        <button class="btn btn-default" type="button" name="" value="Tambah" onclick="window.location.href='setting_input_admin.php'">Tambah</button>
      </div>
    </div>
    <br>
    <div class="table-responsive">
      <table id="data" class="table table-striped table-bordered data">
        <thead>
          <tr>
            <th width="5%">ID</th>
            <th width="30%">Username</th>
            <th width="20%">Nama Admin</th>
            <th width="15%">Telepon </th>
            <th width="20%">Alamat</th>
            <th width="10%">Status</th>
            <th width="10%">Setiing</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $no=1;
          while ($a=mysqli_fetch_assoc($result)) {
            ?>
              <tr>
                <td><?php echo $a['id_admin']; ?></td>
                <td><?php echo $a['user_name']; ?></td>
                <td><?php echo $a['nama_admin']; ?></td>
                <td><?php echo $a['no_telepon']; ?></td>
                <td><?php echo $a['alamat']; ?></td>
                <td><?php echo $a['status']; ?></td>
                <td class="center">
                  <a  class="glyphicon glyphicon-edit" href="transaksi_cek.php?id=<?= $a['id'];?>"></a>
                  <a data-toggle="modal" data-target="#myModal" class="glyphicon glyphicon-trash" href="#"></a>
                </td>
              </tr>
            <?php
            $no++;
          }
          ?>
          <!-- Modal -->
          <div class="modal fade" id="myModal" role="dialog">
            <div class="modal-dialog">

              <!-- Modal content-->
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4 class="modal-title">Modal Header</h4>
                </div>
                <div class="modal-body">
                  <label for="">Username</label>
                  <input type="text" name="" value="">
                  <label for="">Password</label>
                  <input type="text" name="" value="">
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
              </div>

            </div>
          </div>

        </tbody>
      </table>
    </div>
  </div>
  </div>
<?php require '_footer.php'; ?>
