<?php
include 'config/config.php';

$kode_pembayaran = $_GET['kode_pembayaran'];
$kode_tahun_ajaran =$_GET['kode_tahun_ajaran'];
$nis=$_GET['nis'];
$query = mysqli_query($konek, " SELECT sum(jumlah_pem_siswa) FROM siswa b JOIN detail_pembayaran d ON b.nis = d.nis JOIN transaksi a ON d.kode_transaksi = a.kode_transaksi JOIN pembayaran c ON c.kode_pembayaran = a.kode_pembayaran left join tahun_ajaran g on a.kode_tahun_ajaran=g.kode_tahun_ajaran where b.nis ='$nis' and a.kode_pembayaran ='$kode_pembayaran'  AND a.kode_tahun_ajaran='$kode_tahun_ajaran'");
$siswa = mysqli_fetch_array($query);
$siswa=['jumlah_pem_siswa'];
// $data = array(
//             'jumlah_pem_siswa'      =>  $siswa['jumlah_pem_siswa'],
//           );
 echo json_encode($data);
?>
