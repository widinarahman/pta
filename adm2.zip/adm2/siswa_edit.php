<?php
require_once 'config/config.php';
require_once '_header.php';

 // $result=tampilkelas();

 $nis=$_GET['$nis'];
 $result=tampilsiswapernis($nis);

 ?>

 <div class="container">
   <div class="content">
     <h4>Data Admin</h4>

     <ol class="breadcrumb">
       <li class="ti-panel">
         <a href="index.php">Dasboard</a>
       </li>
       <li>
         <a href="tabungan.php">Tabungan</a>
       </li>
       <li class="active">
         Input Nasabah Tabungan
       </li>
     </ol>

     <br>
     <div class="row">
       <div class="col-md-3">
       </div>
       <div class="col-md-7">
          <form id="form1" class="form-inline" action="" method="post" enctype="multipart/form-data">
            <?php while ($a=mysqli_fetch_assoc($result)) {
              # code...
             ?>

           <div class="panel panel-default">
             <div class="panel-heading">Input Siswa </div>
             <div class="panel-body">
               <!--  NIS-->
               <div class="form-group col-md-12">
                 <div class="col-sm-3">
                   <label class="control-label" for="">NIS</label>
                 </div>
                 <div class="col-sm-6 margin"  >
                   <input onkeypress="return hanyaAngka(event)" style="width:100px;" type="text" class="form-control" placeholder="NIS Siswa" name="nis"  value="<?= $a['nis'] ?>">
                 </div>
                 <div class="col-sm-3">
                 </div>
               </div>
               <!-- Tanggal masuk -->
               <div class="form-group col-md-12">
                 <div class="col-sm-3">
                   <label class="control-label" for="">Tahun Masuk</label>
                 </div>
                 <div class="col-sm-6 margin" >
                   <select name="thn1" class="form-control" required>
                     <option value="">Pilih</option>
                     <option value="2013">2013</option>
                     <option value="2014">2014</option>
                     <option value="2015">2015</option>
                     <option value="2016">2016</option>
                     <option value="2017">2017</option>
                     <option value="2018">2018</option>
                     <option value="2019">2019</option>
                     <option value="2020">2020</option>
                     <option value="2021">2021</option>
                     <option value="2022">2022</option>
                     <option value="2023">2023</option>
                     <option value="2024">2024</option>

                   </select>
                   /
                   <select name="thn2" class="form-control" required>
                     <option value="">Pilih</option>
                     <option value="2013">2013</option>
                     <option value="2014">2014</option>
                     <option value="2015">2015</option>
                     <option value="2016">2016</option>
                     <option value="2017">2017</option>
                     <option value="2018">2018</option>
                     <option value="2019">2019</option>
                     <option value="2020">2020</option>
                     <option value="2021">2021</option>
                     <option value="2022">2022</option>
                     <option value="2023">2023</option>
                     <option value="2024">2024</option>

                   </select>

                   <!--
                   <input onkeypress="return hanyaAngka(event)" maxlength="4" style="width:70px;" type="text" class="form-control" placeholder="Tahun Ajaran" name="thn1" required>
                   /
                   <input onkeypress="return hanyaAngka(event)" maxlength="4" style="width:70px;" type="text" class="form-control" placeholder="Tahun Ajaran" name="thn2" required>
                   <br>-->
                   <br>
                   <span>Contoh 2018/2019</span>
                 </div>
                 <div class="col-sm-3">
                 </div>
               </div>
               <!-- Nama siswa -->
               <div class="form-group col-md-12">
                 <div class="col-sm-3">
                   <label class="control-label" for="nama">Nama Siswa</label>
                 </div>
                 <div class="col-sm-6 margin">
                   <input id="nama" type="text" class="form-control require" placeholder="Nama Siswa"  name="nm_siswa"  value="<?=$a['nama_siswa']?>" required>
                 </div>
                 <div class="col-sm-3">
                 </div>
               </div>
               <div class="form-group col-md-12">
                 <div class="col-sm-3">
                   <label class="control-label" for="nama">No Telephon</label>
                 </div>
                 <div class="col-sm-6 margin">
                   <input onkeypress="return hanyaAngka(event)" style="width:60px;" id="nama" type="text" class="form-control require" placeholder="+62"  name="tlp1"  value="+62" readonly="readonly">
                   <input onkeypress="return hanyaAngka(event)"  maxlength="11" style="width:130px;" id="nama" type="text" class="form-control require" placeholder="Nama Siswa"  name="tlp2"  value="" required>
                 </div>
                 <div class="col-sm-3">
                 </div>
               </div>

               <!--  tanggal lahir-->
               <div class="form-group col-md-12 ">
                 <div class="col-sm-3">
                   <label class="control-label" for="">TLL</label>
                 </div>
                 <div class="col-sm-5 margin">
                   <input type="text" class="form-control" placeholder="Tempat Lahir"  name="tempat_lahir">
                 </div>
                 <div class="col-sm-4  input-group date" data-provide="datepicker">
                   <input type="date" class="form-control" placeholder="0000-00-00" name="tgl_lahir" required>
                   <div class="input-group-addon" >
                     <span class="glyphicon glyphicon-th"></span>
                   </div>
                 </div>
               </div>
               <!-- kelas -->
               <div class="form-group col-md-12">
                 <div class="col-sm-3">
                   <label class="control-label" for="">Kelas</label>
                 </div>
                 <div class="col-sm-6 margin">
                   <select name="kd_kelas" class="form-control" required>
                       <option value=""> Pilih Kelas Siswa</option>
                       <?php
                       while ($a=mysqli_fetch_assoc($result)) {
                       ?>
                       <option value="<?php echo $a['kode_kelas']; ?>" require> <?php echo $a['nama_kelas']?></option>
                       <?php
                        }
                       ?>
                   </select>
                 </div>
                 <div class="col-sm-3">
                 </div>
                </div>
                <!-- jenis kelamin -->
               <div class="form-inline col-md-12">
                 <div class="col-sm-3">
                   <label class="control-label" for="">Jenis Kelamin</label>
                 </div>
                 <div class="col-sm-6">
                     <label  for="" class="radio-inlin"><input  type="radio" name="jenis_kelamin" value="L" required>Laki-laki</label>
                     <label  for="" class="radio-inline"><input  type="radio" name="jenis_kelamin" value="P" ><b>Perempuan</b></label>
                 </div>
                 <div class="col-sm-3">
                 </div>
               </div>
               <div class="form-group col-md-12">
                 <div class="col-sm-3">
                   <label class="control-label" for="">Alamat</label>
                 </div>
                 <div class="col-sm-9 margin">
                   <textarea name="alamat" rows="4" class="form-control" cols="40" required></textarea>
                 </div>
                 <!-- <div class="col-sm-3">
                 </div> -->
               </div>




               <div class="form-group col-sm-12 margin_top">
                 <div class="col-sm-5">
                 </div>
                   <div class="col-sm-7  ">
                   <input class="btn btn-default" type="submit" name="submitx" value="Simpan">
                   <input class="btn btn-default" type="submit" name="" value="Cancel">
                   </div>
               </div>



             </div>
           </div>
           <?php } ?>
         </form>

     </div>
     </div>
   </div>
  </div>

<script type="text/javascript">
function hanyaAngka(evt) {
  var charCode = (evt.which) ? evt.which : event.keyCode
   if (charCode > 31 && (charCode < 48 || charCode > 57))

    return false;
  return true;
}
</script>
<?php
require_once '_footer.php';
 ?>
