<?php
include 'config/config.php';

if(isset($_GET['id'])){
  if(hapus_transaksi_tb($_GET['id'])){
    echo "<script>document.location.href='tabungan.php';</script>";
  }else{

   echo "gagal menghapus data";
 }
 ?>
