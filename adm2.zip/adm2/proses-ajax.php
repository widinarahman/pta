<?php
include 'config/config.php';
$mode = $_GET['mode'];


	switch ($mode) {
	case 'detail_mhs':

	$nis = $_GET['nis'];
	$kode_pembayaran= $_GET['kode_pembayaran'];
	$tahun_ajaran= $_GET['tahun_ajaran'];
	$query = "SELECT a.nis,a.nama_siswa,a.tempat_lahir,a.tanggal_lahir,a.alamat,a.jenis_kelamin,a.tahun_ajaran_masuk,a.kode_kelas,b.nama_kelas FROM siswa a join kelas b on a.kode_kelas=b.kode_kelas WHERE a.nis='$nis' order by b.nama_kelas, a.nama_siswa
	";
	$query = mysqli_query($konek, $query);
	$siswa = mysqli_fetch_array($query);
	$data = array(
		'nama_siswa'    =>  $siswa['nama_siswa'],
		'nama_kelas'   =>  $siswa['nama_kelas']
		);
	echo json_encode($data);
	break;

	case 'get_table':
	// mengamil taun jaran yang aktif
	$xyz=mysqli_query($konek, "SELECT * FROM tahun_ajaran WHERE status='Aktif'");
	$row=mysqli_fetch_array($xyz);
	$kd_thn_ajaran=$row['kode_tahun_ajaran'];
	//
	$nis = $_GET['nis'];
	$kode_pembayaran= $_GET['kode_pembayaran'];
	$kode_thn_ajaran=$kd_thn_ajaran;

	$query ="SELECT a.tanggal_transaksi, a.kode_transaksi,
                    b.nis, b.nama_siswa, c.nama_pembayaran, e.bulan, f.semester,g.tahun_ajaran, a.jumlah
                    FROM siswa b
                    JOIN detail_pembayaran d ON b.nis = d.nis
                    JOIN transaksi a ON d.kode_transaksi = a.kode_transaksi
                    JOIN pembayaran c ON c.kode_pembayaran = a.kode_pembayaran
                    LEFT JOIN bulan e ON d.kode_bulan = e.kode_bulan
                    LEFT JOIN semester f ON d.kode_semester = f.kode_semester
                    left join tahun_ajaran g on a.kode_tahun_ajaran=g.kode_tahun_ajaran
                    where b.nis ='$nis' and a.kode_pembayaran ='$kode_pembayaran' and a.kode_tahun_ajaran ='$kode_thn_ajaran'";
	// $query = "SELECT d.jumlah,e.tahun_ajaran ,d.tanggal_transaksi , c.kode_transaksi ,a.nis,a.nama_siswa,a.tempat_lahir,a.tanggal_lahir,a.alamat,a.jenis_kelamin,a.tahun_ajaran_masuk,a.kode_kelas,b.nama_kelas, c.kode_semester  , f.nama_pembayaran
	// FROM siswa a
	// INNER JOIN detail_pembayaran c ON a.nis = c.nis
	// INNER JOIN transaksi d ON c.kode_transaksi = d.kode_transaksi
	// INNER JOIN pembayaran f ON d.kode_pembayaran = f.kode_pembayaran
	// INNER JOIN tahun_ajaran e ON d.kode_tahun_ajaran = d.kode_tahun_ajaran
	// INNER JOIN kelas b ON a.kode_kelas=b.kode_kelas
	// WHERE COALESCE(c.kode_bulan,'') = '' and a.nis='$nis' AND d.kode_pembayaran = '$kode_pembayaran'
	// ORDER BY b.nama_kelas, a.nama_siswa";
	$query = mysqli_query($konek, $query);
	//$datatable = mysqli_fetch_array($query,MYSQLI_NUM);
	$data = [];
	$i = 0;
	while ($datatable=mysqli_fetch_assoc($query)) {
		$data[$i]=  array(
			'tanggal_transaksi' => $datatable['tanggal_transaksi'],
			'kode_transaksi' => $datatable['kode_transaksi'],
			'nis' => $datatable['nis'],
			'nis' => $datatable['nis'],
			'nama_siswa' => $datatable['nama_siswa'],
			'nama_pembayaran' => $datatable['nama_pembayaran'],
			'bulan' => $datatable['bulan'],
			'semester' => $datatable['semester'],
			'tahun_ajaran' => $datatable['tahun_ajaran'],
			'jumlah' => $datatable['jumlah'],
			);
		$i++;

	}
	echo json_encode($data);

	default:
		// echo "wee error";
	break;

	// case 'sum_bayar':
	//
	// $kode_pembayaran= $_GET['kode_pembayaran'];
	// $kode_thn_ajaran=2;
	//
	// $query="select sum(jumlah) from transaksi where kode_pembayaran = '$' and jenis_transaksi='Pemasukan'"
	// $query = mysqli_query($konek, $query);
	// $siswa = mysqli_fetch_array($query);
	// $data = array(
	// 		'jumlah'    =>  $siswa['jumlah']
	// 			);
	// echo json_encode($data);


}

?>
