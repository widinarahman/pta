<?php
  require 'config/config.php';
  require '_header.php';


  $result=tampilpembayaran();
 ?>
<div class="container">
  <div class="content">
    <h4>Data Pembayaran</h4>
    <ol class="breadcrumb">
      <li class="ti-panel">
        <a href="?">Dasboard</a>
      </li>
      <li class="active">
        Data Pembayaran
      </li>
    </ol>
    <div class="row">
      <div class="col-lg-5">
        <button class="btn btn-default" type="button" name="" value="Tambah" onclick="window.location.href='setting_input_pembayaran.php'">Tambah</button>
      </div>
    </div>
    <br>
    <style media="screen">
      .center{
        text-align: center;
      }
    </style>
    <div class="table-responsive">
      <table id="data" class="table table-striped table-bordered data">
        <thead>
          <tr>
            <th width="10%">Kode Pembayaran</th>
            <th width="40%">Nama Pembayaran</th>
            <th width="30%">Masa Pembayaran</th>
            <th width="20%">Saldo Awal</th>
            <th width="10%">Setting</th>
          </tr>
        </thead>
        <tbody>
          <?php while ($a=mysqli_fetch_assoc($result)) {
            ?>
              <tr>
                <td><?php echo $a['kode_pembayaran']; ?></td>
                <td><?php echo $a['nama_pembayaran']; ?></td>
                <td><?php echo $a['masa_pembayaran']; ?></td>
                <td><?php echo rupiah($a['saldo_awal']); ?></td>
                <td class="center">
                  <a class="glyphicon glyphicon-edit"></a>
                  <a class="glyphicon glyphicon-trash" href="#"></a>
                </td>

              </tr>
            <?php
          }
          ?>
        </tbody>
      </table>
    </div>
  </div>
  </div>
<?php require '_footer.php'; ?>
