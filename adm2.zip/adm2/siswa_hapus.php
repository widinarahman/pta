<?php


include 'config/config.php';
if (isset($_GET['nis'])) {
  if (hapus_siswa($_GET['nis'])) {

    echo "<script>document.location.href='siswa.php';</script>";
  }else {
    echo "<script>alert('Gagal hapus')</script";
  }
}
 ?>
