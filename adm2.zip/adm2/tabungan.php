<?php
  require 'config/config.php';
  require '_header.php';
  $result=transaksi_tb();

 ?>
<div class="container">
  <div class="content">
    <h4>Data Transaksi Tabungan</h4>
    <ol class="breadcrumb">
      <li class="ti-panel">
        <a href="?">Dasboard</a>
      </li>
      <li class="active">
        Data Transaksi Tabungan
      </li>
    </ol>
    <div class="row">
      <div class="col-lg-5">
        <button class="btn btn-default" type="button" name="" value="Tambah" onclick="window.location.href='tabungan_buka.php'">Buka Tabungan</button>
        <button class="btn btn-default" type="button" name="" value="Tambah" onclick="window.location.href='tabungan_nasabah.php'">Data Nasbah</button>
        <button class="btn btn-default" type="button" name="" value="Tambah" onclick="window.location.href='tabungan_penarikan.php'">Penarikan</button>
        <button class="btn btn-default" type="button" name="" value="Tambah" onclick="window.location.href='tabungan_setoran.php'">Setoran</button>
      </div>
    </div>
    <br>
    <div class="table-responsive">
      <table id="data" class="table table-striped table-bordered data">
        <thead>
          <tr>
            <th width="5%">NO</th>
            <th width="20%">Tgl Transaksi</th>
            <th width="15%">NO Rekening</th>
            <th width="10%">NIS</th>
            <th width="20%">DEBIT</th>
            <th width="20%">CREDIT</th>
            <th width="10%">Keterangan</th>
            <th width="10">Hapus</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $no=1;
          while ($a=mysqli_fetch_assoc($result)) {
            ?>
              <tr>
                <td  class"center"><?php echo $no; ?></td>
                <td><?php echo $a['tgl_transaksi'];?></td>
                <td><?php echo $a['no_rekening']; ?></td>
                <td><?php echo $a['nis']; ?></td>
                <td><?php echo rupiah($a['jumlah_penarikan']); ?></td>
                <td><?php echo rupiah($a['jumlah_setor']); ?></td>

                <td><?php
                    if ($a['keterangan'] =="Credit") {
                      echo "<p class='label label-success'>Credit</p>";
                    }else {
                      echo "<p class='label label-danger'>Debet</Tidak Aktif>";
                    }
                 ?>
                </td>
                <td class="center">
                  <a class="glyphicon glyphicon-trash" href="tabungan_hapus.php?id=<?=$a['id_tabungan'];?>" onclick="return confirm('Yakin anda ingin menghapusnya ?')"></a>
                </td>
              </tr>
            <?php
           $no++;
         }
          ?>
        </tbody>
      </table>
    </div>
  </div>
  </div>
<?php require '_footer.php'; ?>
