<?php
  require 'config/config.php';
  require '_header.php';
  $result=tampiltahunajaran();

 ?>
 <style media="screen">
   .center {
     text-align: center;
   }
 </style>
<div class="container">
  <div class="content">
    <h4>Data Kelas</h4>
    <ol class="breadcrumb">
      <li class="ti-panel">
        <a href="?">Dasboard</a>
      </li>
      <li class="active">
        Data Tahun Ajaran
      </li>
    </ol>
    <div class="row">
      <div class="col-lg-5">
        <button class="btn btn-default" type="button" name="" value="Tambah" onclick="window.location.href='setting_input_thn_ajaran.php'">Tambah</button>
      </div>
    </div><br>
    <div class="row">

      <div class="col-md-5">
        <!-- <div class="alert alert-warning" role="alert">
          <b>Info</b> Tahun Ajaran hanya dibolehkan satu yang aktif!
        </div> -->
      </div>
    </div>
    <br>
    <div class="table-responsive">
      <table id="data" class="table table-striped table-bordered data">
        <thead>
          <tr>
            <th width="10%">Kode</th>
            <th width="40%">Tahun Ajaran</th>
            <th width="20%">Status</th>
            <th width="20%">Aktif</th>
            <th class="center" width="10%">Setting</th>
          </tr>
        </thead>
        <tbody>
          <?php while ($a=mysqli_fetch_assoc($result)) {
            ?>
              <tr>
                <td><?php echo $a['kode_tahun_ajaran']; ?></td>
                <td><?php echo $a['tahun_ajaran']; ?></td>
                <td> <?php if ($a['status']=="Aktif") {
                    echo "<p class='label label-success'>Aktif</a>";
                  }else {
                    echo "<p class='label label-warning'>Tidak Aktif</a>";
                  }?>
                </td>
                <td>
                  <?php if ($a['status']=="Tidak Aktif") { ?>
                    <a onclick="return confirm('Perubahan data Tahun Ajaran akan merubah data keuangan. Apakah Anda yakin akan merubah data tahun ajaran.')"class="btn btn-default" type="button" name="button" href="setting_thn_ajaranA.php?kd_thn_ajaran=<?=$a['kode_tahun_ajaran']; ?>" ></i>Aktifkan</a>
                  <?php } ?>
                </td>

                <td class="center">
                  <a class="glyphicon glyphicon-edit" href="setting_edit_kelas.php?kode_kelas=<?= $a['kode_kelas'];?>"></a>
                  <a class="glyphicon glyphicon-trash" href="#"></a>
                  <!-- <a class="glyphicon glyphicon-eye-open" href="#"></a> -->

                </td>


              </tr>

            <?php
          }
          ?>
        </tbody>
      </table>
    </div>
  </div>
  </div>
<?php require '_footer.php'; ?>
