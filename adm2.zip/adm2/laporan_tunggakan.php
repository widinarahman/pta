<?php
require 'config/config.php';
require '_header.php';

$result=transaksi_tb();
// $result2=tampilpembayaran_pertahun();

// $kode_pem =99;
// $kode_thn=2;
//
// $sp ="CALL sp_TunggakanPerbulan ('$kode_pem', '$kode_thn')";

// $r=$konek->query($sp);
//$querypro=mysqli_query($konek,$sp);

?>
<style>
  /* General */

  table {
    border-collapse:collapse;
  }

  .center {
    text-align:center;
  }

  .right {
    text-align : right;
  }

  .left {
    text-align : left;
  }

  tr {
    margin : 5px 0 ;
    line-height : 18px;
  }

  th {
    text-align : center;
    padding : 10px 0;
  }

  td {
    padding: 5px 0;
    word-wrap: break-word;
  }

  tr td.label {
    width : 100px;
  }

  .item-header {
    margin : 15px 0;
  }

  table.item-detail,
  table.item-detail	th,
  table.item-detail td {
    border : 1px solid #000;
  }

  /* Header */

  #header {
    /*width : 755px;*/
    padding-bottom : 5px;
    border-bottom:3px solid #000;
    /*//text-align:center;*/

  }
  #logo {
    float:left;
    display:inline;
    width : 100px;
    margin-top: 10px;
  }
  #kop-surat {
    margin-top : -100;
    width : 700px;
    display:inline-block;
    text-align : center;
  }
  #separator {
    padding : 2px 0;
    border-bottom:1px solid #000;
  }

  /* Content */

  #content {
    width : 755px;
  }

  #report-title {
    font-size : 16px;
    text-align : center;
    margin-bottom:10px;
  }

  table.item-summary {
    margin : 15px 0;
  }

  .currency {

  }

  .space {
    width:20px;
  }
  .laporan{
    background-color: #ffffff;
    padding-right: 15px;
    padding-left: 15px;
    width: 880px;
    margin-left: 120px;
  /*text-align: center;*/
  }
  thead{
    color: #ffffff;
  }
</style>
<div class="container">
  <div class="content">
    <h4> Laporan Tunggakan</h4>
    <ol class="breadcrumb">
      <li class="ti-panel">
        <a href="?">Dasboard</a>
      </li>
      <li class="active">
        Laporan Tunggakan Pembayaran Pertahun
      </li>
    </ol>

    <!--Pembayaran-->
        <br>
    <div class="laporan" >

      <br>

    <div id="header">
 			<div id="logo">
 				<img src="style/img/logo.png" alt="" style="width:80%;"/>
 			</div><br>
 			<div id="kop-surat">
 				<h4><b>SMK BISMA KERSANA</b></h4>
 				<p style="font-size:12px;">

 					Kecamatan Kersana, Brebes, Jawa Tengah.<br>
 					Telp : 4248755,4221111,4265555 <br />
 					<!-- Email : yayasandaarulhikmah@gmail.com<br /> -->
 				</p>
 			</div>
 		</div>
    <br>
    <div class="" style="text-align:center">
      <hp><b>Laporan Transaksi Tabungan</b></p>
        <span>Dari Tanggl :2017/2/20  Sampai 2017/08/1 </span> 
    </div>
    <!-- <p>Jenis Pembayaran :<input type="text" name="" value="" disabled> </p>
    <p>Tahun Ajaran :<input type="text" name="" value="" disabled> </p> -->

    <br>
    <div class="table-responsive">
      <table id="data2" class="table table-striped table-bordered data">
        <thead style="background-color:#434747; ">
          <!-- <thead> -->
            <tr>
              <th width="5%">NO</th>
              <th width="20%">Tgl Transaksi</th>
              <th width="15%">NO Rekening</th>
              <th width="10%">NIS</th>
              <th width="20%">DEBIT</th>
              <th width="20%">CREDIT</th>
              <th width="10%">Keterangan</th>

            </tr>
          </thead>
          <tbody>
            <?php
            $no=1;
            while ($a=mysqli_fetch_assoc($result)) {
              ?>
                <tr>
                  <td  class"center"><?php echo $no; ?></td>
                  <td><?php echo $a['tgl_transaksi'];?></td>
                  <td><?php echo $a['no_rekening']; ?></td>
                  <td><?php echo $a['nis']; ?></td>
                  <td><?php echo rupiah($a['jumlah_penarikan']); ?></td>
                  <td><?php echo rupiah($a['jumlah_setor']); ?></td>

                  <td><?php
                      if ($a['keterangan'] =="Credit") {
                        echo "<p class='label label-success'>Credit</p>";
                      }else {
                        echo "<p class='label label-danger'>Debet</Tidak Aktif>";
                      }
                   ?>
                  </td>
                  <!-- <td class="center">
                    <a class="glyphicon glyphicon-trash" href="tabungan_hapus.php?id=<?=$a['id_tabungan'];?>" onclick="return confirm('Yakin anda ingin menghapusnya ?')"></a>
                  </td> -->
                </tr>
              <?php
             $no++;
           }
            ?>
          </tbody>
        </table>
   </div>
  </div>
</div>

<?php
 //mysqli_free_result($r);
require '_footer.php';
 ?>
