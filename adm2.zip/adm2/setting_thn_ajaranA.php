<?php
include 'config/config.php';

$kd_thn_ajaran=$_GET['kd_thn_ajaran'];

$sql1="UPDATE tahun_ajaran SET status='Tidak Aktif' WHERE status='Aktif' ";
$sql2="UPDATE tahun_ajaran SET status='Aktif' WHERE kode_tahun_ajaran='$kd_thn_ajaran'";

if (isset($_GET['kd_thn_ajaran'])) {

    if (mysqli_query($konek, $sql1)) {

      if (mysqli_query($konek, $sql2)) {

      }
      echo "<script>document.location.href='setting_thn_ajaran.php';</script>";
    }

}else {
  echo "gagal 3";
}

 ?>
