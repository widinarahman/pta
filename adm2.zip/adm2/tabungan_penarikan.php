<?php
require 'config/config.php';
require '_header.php';

if (isset($_POST['submit'])) {

  $no_rekening=$_POST['no_rekening'];
  $tgl_transaksi=date('Y-m-d');
  $jumlah_penarikan=$_POST['jumlah_penarikan'];
  $jumlah_setor=0;
  $keterangan='Debit';

  // Menampilakan saldo awal
  $sql=mysqli_query($konek, "SELECT saldo FROM no_tabungan WHERE no_rekening='$no_rekening'");
  $row=mysqli_fetch_array($sql);
  // saldo - saldo setor uang
  $tot_saldo=$row['saldo'];
  $saldo=$row['saldo']-$jumlah_penarikan;

  $sql2="UPDATE no_tabungan SET saldo='$saldo' WHERE no_rekening='$no_rekening'";

  // Simpan transaksi
  if (!preg_match('/^[0-9]*$/',$jumlah_penarikan)) {
      echo "<script>alert('Jumlah penarikan harus angka, tidak huruf atau tanda !')</script>";
  }
  elseif ( $tot_saldo >= $jumlah_penarikan) {

    if(nabung($no_rekening,$tgl_transaksi, $jumlah_penarikan, $jumlah_setor,$keterangan)) {
      echo "<script>alert('Berhasil menambah tabungan')</script>";
        // fungsi di tambah saldo awal

      if(mysqli_query($konek, $sql2)) {
        echo "<script>alert('Saldo berhasil di tambah $jumlah_penarikan makan saldo tabungan anda $saldo')</script>";
      }
    }else {
      echo "Error: " . $query . "<br>" . mysqli_error($konek);
    }
  }else {
    echo "<script>alert('Saldo tidak cukup, dari jumlah penarikan !')</script>";
  }
}
 ?>

<div class="container">
  <div class="content">
    <h4>Penarikan Tabungan</h4>
    <ol class="breadcrumb">
      <li class="ti-panel">
        <a href="index.php">Dasboard</a>
      </li>
      <li>
        <a href="tabungan.php">Tabungan</a>
      </li>
      <li class="active">
        Penarikan  Tabungan
      </li>
    </ol>

    <br>
    <div class="row">
      <div class="col-md-3">

      </div>
      <div class="col-md-7">
        <!-- <div class="alert alert-info" role="alert">
          <b>Info</b> Untuk menambah kelas silahkan masukan kode dan nama kelas, kode kelas dan nama kelas tidak boleh sama !
        </div> -->
        <form class="form-inline" action="" method="post">
          <div class="panel panel-default">
            <div class="panel-heading">
              Siswa Menabung <span class="date"></span>
              <p class="date"><?php echo date('Y/m/d'); ?></p>
            </div>

            <div class="panel-body">

              <div class="form-group col-sm-12">
                <div class="col-sm-3">
                  <label class="control-label" for="">No Rekening</label>
                </div>
                <div class="col-sm-5 margin">
                  <input  type="text" class="form-control" onkeyup="isi_otomatis_rk()" placeholder="No Rekening" id="no_rekening" name="no_rekening" required>
                </div>
                <div class="col-sm-4">
                  <label for="">NIS</label>
                  <input  type="text" class="form-control" style="width:100px;"placeholder="" name="nis" id="nis"  value=""  disabled>
                </div>
              </div>

              <div class="form-group col-sm-12">
                <div class="col-sm-3">
                  <label class="control-label" for="">Saldo Tabungan</label>
                </div>
                <div class="col-sm-6 margin">
                  <input  type="text" class="form-control" placeholder="" name="saldo" id="saldo"  value=""  disabled>
                </div>
                <div class="col-sm-3">
                </div>
              </div>



              <!-- <div class="form-group col-md-12">
                <div class="col-sm-3">
                  <label class="control-label" for="">Nama</label>
                </div>
                <div class="col-sm-5">
                  <input type="text" class="form-control" placeholder="Nama Siswa" id="nama_siswa" name="nama_siswa"   value="" disabled>
                </div>
                <div class="col-sm-4">
                  <input type="text" class="form-control" placeholder="Kelas" id="nama_kelas" name="nama_kelas"   value="" disabled>
                </div>
              </div> -->

            </div>
            <div class="panel-footer col-xs-12">
                  <div class="form-group col-xs-12 ">
                      <label for="" class="col-md-4">Jumlah Penarikan</label><span>Rp</span>
                      <input onkeypress="return hanyaAngka(event)" type="text" class="form-control margin" name="jumlah_penarikan" value="">
                  </div>
                  <!-- <div class="form-group col-xs-12">
                    <label for="" class="col-md-4">keterangan</label>
                    <textarea name="name" class="form-control" rows="4" cols="20"></textarea>
                  </div> -->
                  <div class="form-group col-sm-12 margin_top">
                    <div class="col-sm-5">
                    </div>
                      <div class="col-sm-7  ">
                      <input class="btn btn-default" type="submit" name="submit" value="Simpan">
                      </div>
                  </div>
            </div>

          </div>
        </form>
    </div>
  </div>
</div>

</div>
<script src="assets/js/jquery-2.1.4.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script type="text/javascript">
function hanyaAngka(evt) {
  var charCode = (evt.which) ? evt.which : event.keyCode
   if (charCode > 31 && (charCode < 48 || charCode > 57))

    return false;
  return true;
}
function isi_otomatis_rk(){
    var no_rekening = $("#no_rekening").val();
    $.ajax({
        url: 'proses_setor_tb.php',
        data:"no_rekening="+no_rekening ,
    }).success(function (data) {
        var json = data,
        obj = JSON.parse(json);
        $('#nis').val(obj.nis);
        $('#saldo').val(obj.saldo);
        // $('#alamat').val(obj.alamat);
    });
  }
</script>
<?php require '_footer.php'; ?>
