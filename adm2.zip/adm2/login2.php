<?php
session_start();
include 'config/config.php';

if (isset($_POST['submit'])) {
  $user_name=$_POST['username'];
  $password=$_POST['password'];
  $password=sha1($password);

  if (ceklogin($user_name, $password)) {
    echo $_SESSION['id_admin']; 
    echo "<script>document.location.href='index.php'</script>";
  }else {
    echo "<script>alert('Username dan password anda salah, ulangi kembali')</script>";
  }
}
 ?>
 <!DOCTYPE html>
 <html>
   <head>
     <meta charset="utf-8">
     <title>Administrasi Keuangan</title>
     <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
     <style media="screen">
       .login {
         margin-top: 50px;
       }
     </style>
   </head>
   <body>

   <div class="container">
     <div class="row">
       <div class="col-md-3">

       </div>
       <div class="col-md-5 login">
         <div class="well">
           <div class="header">
             <center><img src="" alt=""></center>
           </div>
           <form class="" action="" method="post">
             <div class="form-group">
               <label for="">username</label>
               <input type="text" id="username" name="username" class="form-control">
             </div>
             <div class="form-group">
               <label for="">Password</label>
               <input type="password" id="password" name="password" class="form-control">
             </div>
             <button type="submit" name="submit" class="btn btn-primary"> Login</button>
           </form>
         </div>
       </div>
     </div>
   </div>

 </body>
 </html>
