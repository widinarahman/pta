<?php
require 'config/config.php';
require '_header.php';


if (isset($_POST['submit'])) {

  $nis=$_POST['nis'];
  $tgl_kepemilikan=date('Y-m-d');
  $status='Aktif';
  $year=date('my');
  $kode=1;

  $x="SELECT COUNT(*) AS jumlah FROM no_tabungan";
  $y=mysqli_query($konek, $x) or die (mysqli_error());
  $jumlah_col=mysqli_fetch_array($y);
  $x=$jumlah_col['jumlah'];
  //$jumlah_col=mysqli_fetch_row(mysqli_query($konek, "SELECT COUNT(*)AS jumlah FROM no_tabungan"));
  $cek_no_tabungan=mysqli_fetch_row(mysqli_query($konek, "SELECT * FROM no_tabungan WHERE nis='$nis'"));
  //$cenis_tabungan=cek_no_tabungan();


  $no_rekening=$kode.'-'.$year.'-'.$x;

  $nama_siswa = $_POST['nama_siswa'];
  $nama_kelas= $_POST['nama_kelas'];
  // echo "<script>alert('$nama_siswa')</script>";
  if(!preg_match('/^[0-9]*$/',$nis)){
    echo "<script>alert('NIS hanya boleh angka !')</script>";
  }
  elseif (empty($nama_siswa) && empty($nama_siswa) ) {
      echo "<script>alert('NIS tidak terdaftar !')</script>";
  }
  elseif ($cek_no_tabungan > 0) {
    echo "<script>alert('Nomor NIS $nis sudah membuka tabungan,satu siswa hanya di perbolehkan membuka satu tabungan ')</script>";
    echo "<script>window.location.href='tabungan_nasabah.php'</script>";
  }
  elseif(simpan_no_tabungan($no_rekening,$nis,$tgl_kepemilikan,$status)) {
    echo "<script>alert('Siswa dengan NIS $nis Berhasil membuka tabungan dengan no rekening $no_rekening')</script>";
    echo "<script>window.location.href='tabungan_nasabah.php'</script>";
  }else {
    echo "Error: " . $query . "<br>" . mysqli_error($konek);
  }
}
 ?>
<div class="container">
  <div class="content">
    <h4>Data Admin</h4>
    <ol class="breadcrumb">
      <li class="ti-panel">
        <a href="index.php">Dasboard</a>
      </li>
      <li>
        <a href="tabungan.php">Tabungan</a>
      </li>
      <li class="active">
        Input Nasabah Tabungan
      </li>
    </ol>

    <br>
    <div class="row">
      <div class="col-md-3">

      </div>
      <div class="col-md-7">
        <!-- <div class="alert alert-info" role="alert">
          <b>Info</b> Untuk menambah kelas silahkan masukan kode dan nama kelas, kode kelas dan nama kelas tidak boleh sama !
        </div> -->
        <form class="form-inline" action="" method="post">
          <div class="panel panel-default">
            <div class="panel-heading">Input Calon Nasbah </div>
            <div class="panel-body">

              <!-- <div class="form-group col-md-12"> -->
                <!-- <div class="col-sm-3">
                  <label class="control-label" for="">Jenis Tabungan</label>
                </div>
                <div class="col-sm-3 margin" >
                  <select name="kode" class="form-control">
                    <option value="">Pilih</option>
                    <option value="">Siswa</option>
                    <option value="">Guru</option>
                    <option value="">Unit</option>
                  </select>
                </div>
              </div> -->
              <div class="form-group col-md-12">
                <div class="col-sm-3">
                  <label class="control-label" for="">NIS</label>
                </div>
                <div class="col-sm-6 margin">
                  <input  type="text" class="form-control" placeholder="Nis Siswa" onkeyup="isi_otomatis()" id="nis" name="nis" required>
                </div>
                <div class="col-sm-3">
                </div>
              </div>
              <div class="form-group col-md-12 margin">
                <div class="col-sm-3">
                  <label class="control-label" for="">Nama</label>
                </div>
                <div class="col-sm-5">
                  <input type="text" class="form-control" placeholder="Nama Siswa" id="nama_siswa" name="nama_siswa"   value=""  readonly="readonly">
                  <!-- <input type="hidden" class="form-control" placeholder="Nama Siswa" id="nama_siswa" name="nama_siswa"   value=""> -->
                </div>
                <div class="col-sm-4">
                  <input type="text" class="form-control" placeholder="Kelas" id="nama_kelas" name="nama_kelas"   value=""  readonly="readonly">
                  <!-- <input type="hidden" class="form-control" placeholder="Kelas" id="nama_kelas" name="nama_kelas"   value="" > -->
                </div>
              </div>
              <div class="form-group col-sm-12 margin_top">
                <div class="col-sm-5">
                </div>
                  <div class="col-sm-7  ">
                  <input class="btn btn-default" type="submit" name="submit" value="Simpan">
                  </div>
              </div>



            </div>
          </div>
        </form>
    </div>
  </div>
</div>

</div>
<script src="assets/js/jquery-2.1.4.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script type="text/javascript">
function isi_otomatis(){
    var nis = $("#nis").val();
    $.ajax({
        url: 'proses-ajax_tb.php',
        data:"nis="+nis ,
    }).success(function (data) {
        var json = data,
        obj = JSON.parse(json);
        $('#nama_siswa').val(obj.nama_siswa);
        $('#nama_kelas').val(obj.nama_kelas);
        // $('#alamat').val(obj.alamat);
    });
  }
</script>
<?php require '_footer.php'; ?>
