<?php
require 'config/config.php';
require '_header.php';

$pembayaran=tampilpembayaran_bulan();
$thn_aktif=thn_ajar_aktif();
$thn_aktif2=thn_ajar_aktif();

if (isset($_POST['submit'])) {

  $kode_pembayaran=$_POST['kode_pembayaran'];
  $id_admin=$_SESSION['id_admin'];

    while($a=mysqli_fetch_assoc($thn_aktif)){
    $aktif=$a['kode_tahun_ajaran'];
    $kode_tahun_ajaran=$aktif;
  }
  $tanggal_transaksi=date('Y/m/d');
  $jenis_transaksi='Pemasukan';
  $jumlah=$_POST['jumlah'];
  $keterangan=null;

  if (simpan_transaksi($kode_pembayaran, $id_admin, $kode_tahun_ajaran, $tanggal_transaksi, $jenis_transaksi, $jumlah, $keterangan)) {

      echo "<script>alert('Berhasil')</script>";

      $sql=mysqli_query($konek, "SELECT kode_transaksi FROM transaksi ORDER BY kode_transaksi DESC LIMIT 1");
      $row=mysqli_fetch_array($sql);
      $id_terakhir=$row['kode_transaksi'];


      echo "<script>alert($id_terakhir)</script>";

      $nis=$_POST['nis'];
      $kode_transaksi=$id_terakhir;
      $kode_bulan=$_POST['kd_bulan'];

    if (simpan_detail_pembayaran_bulan($nis,$kode_transaksi,$kode_bulan)) {
      echo "<script>alert('berhasil detail pembayaran')</script>";
    }else {
      echo "Error: " . $query . "<br>" . mysqli_error($konek);
    }
  }else {
    echo "Error: " . $query . "<br>" . mysqli_error($konek);
  }
}

 ?>


<div class="container">
  <div class="content">
    <h4>Transaksi Pembayaran Persemester</h4>
    <ol class="breadcrumb">
      <li class="ti-panel">
        <a href="index.php">Dasboard</a>
      </li>
      <li>
        <a href="transaksi_pemasukan.php">Transaksi Pemasukan</a>
      </li>
      <li class="active">
        Pembayaran Persemester
      </li>
    </ol>

    <br>
    <div class="row">
      <div class="col-md-2">

      </div>
      <div class="col-md-8">
        <form class="form-inline" action="" method="post">
          <div class="panel panel-default">
            <div class="panel-heading">

              <div class="form-group col-sm-12">
                <div class="col-sm-3">
                  <label class="control-label" for="">Nama Pembayaran</label>
                </div>
                <div class="col-sm-4 margin">
                  <!-- Kode pembayaran untuk ajax-->
                  <select class="form-control" name="kode_pembayaran" id="kode_pembayaran" required>
                    <option value=""> PILIH </option>
                    <?php
                      while($data=mysqli_fetch_assoc($pembayaran)){
                    ?>
                      <option value="<?php echo $data['kode_pembayaran'];?>" onclick="isi_otomatis()"> <?php echo $data['nama_pembayaran'];?> </option>
                      <?php
                     }
                    ?>
                  </select>



                </div>
                <div class="col-sm-5">
                  <label for="">Tahun Ajaran : </label>
                  <?php
                    while($a=mysqli_fetch_assoc($thn_aktif2)){
                      $aktif=$a['tahun_ajaran'];
                      echo "$aktif";
                  ?>
                  <!-- Kode Tahun ajaran untuk ajax -->
                    <input type="hidden" name="kode_tahun_ajaran" value="<?php echo $a['kode_tahun_ajaran']; ?>" onkeyup="isi_otomatis()" id="kode_tahun_ajaran" disabled>
                  <?php } ?>
                </div>
              </div>
              <div class="form-group col-sm-12">
                <div class="col-sm-3">
                  <label class="control-label" for="">Rp</label>
                </div>
                <div class="col-sm-4 margin">
                  <input type="text" class="form-control" id="jumlah_pembayaran" name="jumlah_pembayaran" value="" disabled>
                </div>
              </div>
              <p class="date"> Tanggal : <?php echo date('Y/m/d'); ?></p>
            </div>

            <div class="panel-body">
              <div class="form-group col-sm-12">

              </div>
              <div class="form-group col-sm-12">
                <div class="col-sm-3">
                  <label class="control-label" for="">NIS</label>
                </div>
                <div class="col-sm-6 margin">

                  <!------------------------------------- NIS  untuk ajax--------------------------->
                  <input  type="text"  class="form-control"  placeholder="" name="nis" onkeyup="isi_otomatis2()" id="nis" required>
                </div>
                <div class="col-sm-3">
                </div>
              </div>
              <div class="form-group col-sm-12">
                <div class="col-sm-3">
                  <label class="control-label" for="">Nama Siswa</label>
                </div>
                <div class="col-sm-5 margin">
                  <input  type="text" class="form-control" placeholder="Nama Siswa" id="nama_siswa" name="nama_siswa" disabled>
                </div>
                <div class="col-sm-4">
                  <label for="">Kelas</label>
                  <input  type="text" class="form-control" style="width:100px;" placeholder="Kelas" name="nama_kelas" id="nama_kelas"  value=""  disabled>
                </div>
              </div>
              <div class="form-group col-sm-12 margin">
                <div class="col-sm-3">
                  <label class="control-label" for=""> Bulan</label>
                </div>
                <div class="col-sm-3" style="margin-left:0px;">
                    <label for="" class="checkbox-inline" style="margin-left: 0px;margin-right: 50px;"><input id="juli" type="checkbox" name="kd_bulan" value="1">Juli</label>
                    <label for="" class="checkbox-inline" style="margin-left: 0px;margin-right: 50px;"><input id="agustus" type="checkbox" name="kd_bulan" value="2">Agustus</label>
                    <label for="" class="checkbox-inline" style="margin-left: 0px;margin-right: 50px;"><input id="september" type="checkbox" name="kd_bulan" value="3">September</label>
                    <label for="" class="checkbox-inline" style="margin-left: 0px;margin-right: 50px;"><input id="okt" type="checkbox" name="kd_bulan" value="4">Oktober</label>
                </div>
                <div class="col-sm-3" style="margin-left:0px;">
                  <label for="" class="checkbox-inline" style="margin-left: 0px;margin-right: 50px;"><input id="nov" type="checkbox" name="kd_bulan" value="5">November</label>
                  <label for="" class="checkbox-inline" style="margin-left: 0px;margin-right: 50px;"><input id="des" type="checkbox" name="kd_bulan" value="6">Desember</label>
                  <label for="" class="checkbox-inline" style="margin-left: 0px;margin-right: 50px;"><input id="jan" type="checkbox" name="kd_bulan" value="7">Januari</label>
                  <label for="" class="checkbox-inline" style="margin-left: 0px;margin-right: 50px;"><input id="feb" type="checkbox" name="kd_bulan" value="8">Febuari</label>

                </div>
                <div class="col-sm-3" style="margin-left:0px;">
                  <label for="" class="checkbox-inline" style="margin-left: 0px;margin-right: 50px;"><input id="maret" type="checkbox" name="kd_bulan" value="9">Maret</label>
                  <label for="" class="checkbox-inline" style="margin-left: 0px;margin-right: 50px;"><input id="april" type="checkbox" name="kd_bulan" value="10">April</label>
                  <label for="" class="checkbox-inline" style="margin-left: 0px;margin-right: 50px;"><input id="mei"  type="checkbox" name="kd_bulan" value="11">Mei</label>
                  <label for="" class="checkbox-inline" style="margin-left: 0px;margin-right: 50px;"><input id="juni" type="checkbox" name="kd_bulan" value="12">Juni</label>
                </div>
              </div>
              <div class="form-group col-sm-12" style="padding-top: 10px;">
                <div class="col-sm-3">
                  <label class="control-label" for="">Jumlah</label>
                </div>
                <div class="col-sm-6 margin">
                  <input  id="jumlah_bayar" type="text" class="form-control" placeholder="" name="jumlah" value="" >
                  <!-- <input type="text" name="total" value=""  readonly> -->
                  <!-- <input type=hidden name=hiddentotal value=0></td> -->
                </div>
                <div class="col-sm-3">
                  <input type="hidden" name="keterangan" value="">
                </div>
              </div>

              <div class="form-group col-sm-12 margin_top">
                <div class="col-sm-5">
                </div>
                  <div class="col-sm-7  ">
                  <input class="btn btn-default" type="submit" name="submit" value="Simpan">
                  <input class="btn btn-default" type="submit" name="submit" value="Cancel">
                  </div>
              </div>
              <br>
            </div>
            <div class="panel-footer col-xs-12">

            </div>

          </div>

        </form>
    </div>
  </div>
  <div class="row">
    <div class="table-responsive">
      <table id="data2" class="table table-striped table-bordered data font">
        <thead class="font">
          <tr>
            <th width="15%">Tanggal Transaksi</th>
            <th width="10%">Kode Transaksi </th>
            <th width="7%">NIS</th>
            <th width="15%">Nama Siswa</th>
            <th width="15%">Pembayaran</th>
            <th width="10%">Bulan</th>
            <th width="10%">Tahun Ajaran</th>
            <th width="10%">Jumlah</th>
          </tr>
        </thead>
        <tbody id="datax">
          <tr>
            <td></td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</div>

</div>
<script src="assets/js/jquery-2.1.4.min.js"></script>
<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script> -->
<script type="text/javascript">
function isi_otomatis(){
    var kode_pembayaran = $("#kode_pembayaran").val();
    var kode_tahun_ajaran = $("#kode_tahun_ajaran").val();
    $.ajax({
        url: 'proses_jml_pembayaran.php',
        data:{
          kode_pembayaran:kode_pembayaran,
          kode_tahun_ajaran:kode_tahun_ajaran
        }
        // data:"kode_pembayaran="+kode_pembayaran ,
        // data:"kode_tahun_ajaran="+kode_tahun_ajaran ,
    }).success(function (data) {
        var json = data,
        obj = JSON.parse(json);
        $('#jumlah_pembayaran').val(obj.jumlah_pembayaran);
        $('#jumlah_bayar').val(obj.jumlah_pembayaran);
        // return(formatCurrency(jumlah_pembayaran.value));
        // $('#nama_kelas').val(obj.nama_kelas);
        //  $('#alamat').val(obj.alamat);
    });
  }
  function isi_otomatis2(){
    // menampilkan nama siswa dan kelas siswa berdasarkan NIS
      var nis = $("#nis").val();
      var kode_pembayaran = $("#kode_pembayaran").val();
      var tahun_ajaran = '<?php echo $aktif?>';
      $.ajax({
          url: 'proses-ajax.php',
          data:{
            mode:'detail_mhs', nis:nis,kode_pembayaran:kode_pembayaran,tahun_ajaran:tahun_ajaran}
          // data:"nis="+nis ,
      }).success(function (data) {
          var json = data,
          obj = JSON.parse(json);
          $('#nama_siswa').val(obj.nama_siswa);
          $('#nama_kelas').val(obj.nama_kelas);
          if (obj.kode_semester == 1) {
          }

      });

      get_table(nis , kode_pembayaran, tahun_ajaran)
    }
    function get_table(nis , kode_pembayaran, tahun_ajaran){
            $.ajax({
            url: 'proses-ajax.php',
            data:{mode:'get_table', nis:nis,kode_pembayaran:kode_pembayaran, tahun_ajaran:tahun_ajaran}
        }).success(function (data) {
            // console.log(data);
            // return false;
            var json = data,
            obj = JSON.parse(json);
            var tabeldata = document.getElementById('data2').getElementsByTagName('tbody')[0];
            var j = 0;
            document.getElementById('datax').innerHTML= "";

            document.getElementById('juli').style.display="block";
            document.getElementById('agustus').style.display="block";
            document.getElementById('september').style.display="block";
            document.getElementById('okt').style.display="block";
            document.getElementById('nov').style.display="block";
            document.getElementById('des').style.display="block";
            document.getElementById('jan').style.display="block";
            document.getElementById('feb').style.display="block";
            document.getElementById('maret').style.display="block";
            document.getElementById('april').style.display="block";
            document.getElementById('mei').style.display="block";
            document.getElementById('juni').style.display="block";
            //document.getElementById('ingenap').style.display="block";

            for (var i = obj.length - 1; i >= 0; i--) {
             row = tabeldata.insertRow(tabeldata.rows.length);
             row.value = i;
             cell1 = row.insertCell(0);
             cell2 = row.insertCell(1);
             cell3 = row.insertCell(2);
             cell4 = row.insertCell(3);
             cell5 = row.insertCell(4);
             cell6 = row.insertCell(5);
             cell7 = row.insertCell(6);
             cell8 = row.insertCell(7);
             cell1.innerHTML  = obj[j]['tanggal_transaksi'];
             cell2.innerHTML  = obj[j]['kode_transaksi'];
             cell3.innerHTML  = obj[j]['nis'];
             cell4.innerHTML  = obj[j]['nama_siswa'];
             cell5.innerHTML  = obj[j]['nama_pembayaran'];
             cell6.innerHTML  = obj[j]['bulan'];
             cell7.innerHTML  = obj[j]['tahun_ajaran'];
             cell8.innerHTML  = obj[j]['jumlah'];
             var ju=obj[j]['bulan'],ag=obj[j]['bulan'],
                 se=obj[j]['bulan'],ok=obj[j]['bulan'],
                 no=obj[j]['bulan'],de=obj[j]['bulan'],
                 fe=obj[j]['bulan'],ja=obj[j]['bulan'],
                 ma=obj[j]['bulan'],ap=obj[j]['bulan'],
                 me=obj[j]['bulan'],ju=obj[j]['bulan'];

             if(ju=="Juli"){
               document.getElementById('juli').style.display="none";

             }
             if(ag=="Agustus"){
               document.getElementById('agustus').style.display="none";

             }
             if(se=="September"){
               document.getElementById('september').style.display="none";
             }
             if(ok=="Oktober"){
               document.getElementById('okt').style.display="none";
             }
             if(no=="November"){
               document.getElementById('nov').style.display="none";
             }
             if(de=="Desember"){
               document.getElementById('des').style.display="none";
             }
             if(ja=="Januari"){
               document.getElementById('jan').style.display="none";
             }
             if(fe=="Febuari"){
               document.getElementById('feb').style.display="none";
             }
             if(ma=="Maret"){
               document.getElementById('maret').style.display="none";
             }
             if(ap=="April"){
               document.getElementById('april').style.display="none";
             }
             if(me=="Mei"){
               document.getElementById('mei').style.display="none";
             }
             if(ju=="Juni"){
               document.getElementById('juni').style.display="none";
             }
             j++;
            }

        });
    }
    </script>
<?php require '_footer.php'; ?>
