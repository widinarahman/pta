<?php
require 'config/config.php';
require '_header.php';

if (isset($_POST['submit'])) {

  $no_rekening=$_POST['no_rekening'];
  $tgl_transaksi=date('Y-m-d');
  $jumlah_penarikan=0;
  $jumlah_setor=$_POST['jumlah_setor'];
  $keterangan='Credit';

  // Menampilakan saldo awal
  $sql=mysqli_query($konek, "SELECT saldo FROM no_tabungan WHERE no_rekening='$no_rekening'");
  $row=mysqli_fetch_array($sql);

  $a=strlen($jumlah_setor);
  $saldo=$row['saldo']+$jumlah_setor;

  $sql2="UPDATE no_tabungan SET saldo='$saldo' WHERE no_rekening='$no_rekening'";
  // Simpan transaksi
  if (!preg_match('/^[0-9]*$/',$jumlah_setor)) {
    echo "<script>alert('Jumlah setor hanya boleh angka !')</script>";
  }
  elseif ($a <=3) {
    echo "<script>alert('Minimal nabung Rp 1000 !')</script>";
  }
  elseif(nabung($no_rekening,$tgl_transaksi, $jumlah_penarikan, $jumlah_setor,$keterangan)) {
    echo "<script>alert('Berhasil menambah tabungan')</script>";
    if (mysqli_query($konek, $sql2)) {
    echo "<script>alert('Saldo berhasil di tambah $jumlah_setor makan saldo tabungan anda $saldo')</script>";
    }
  }else {
    echo "Error: " . $query . "<br>" . mysqli_error($konek);
  }
}
 ?>

 <style type="text/css">label {
     width:20em;
     float: left;
   }
   label.error {
     font-family: verdana;
     float: right;
     color: red;
     padding-left: .1em;

   }
   #number_container{
     border: 1px dotted #d0d0d0;
     padding: 15px;
     margin: 10px;
     display: none;
     background: #fafafa;
   }

   div.wrap{
     margin: 10px;
     padding-top: 15px;
   }

   button{
     display: block;
     margin-top: 25px;
   }
</style>




<div class="container" id="container">
  <div class="content">
    <h4>input Setoran Tabungan</h4>
    <ol class="breadcrumb">
      <li class="ti-panel">
        <a href="index.php">Dasboard</a>
      </li>
      <li>
        <a href="tabungan.php">Tabungan</a>
      </li>
      <li class="active">
        Input Setoran Tabungan
      </li>
    </ol>

    <br>
    <div class="row">
      <div class="col-md-3">

      </div>
      <div class="col-md-7">
        <!-- <div class="alert alert-info" role="alert">
          <b>Info</b> Untuk menambah kelas silahkan masukan kode dan nama kelas, kode kelas dan nama kelas tidak boleh sama !
        </div> -->
        <form class="form-inline" id="form1" action="" method="post">
          <div class="panel panel-default">
            <div class="panel-heading">
              Siswa Menabung <span class="date"></span>
              <p class="date"><?php echo date('Y/m/d'); ?></p>
            </div>

            <div class="panel-body">

              <div class="form-group col-sm-12">
                <div class="col-sm-3">
                  <label class="control-label" for="">No Rekening</label>
                </div>
                <div class="col-sm-5 margin">
                  <input  type="text" class="form-control" onkeyup="isi_otomatis_rk()" placeholder="No Rekening" id="no_rekening" name="no_rekening" required>
                </div>
                <div class="col-sm-4">
                  <label for="">NIS</label>
                  <input  type="text" class="form-control" style="width:100px;"placeholder="" name="nis" id="nis"  value=""  disabled>
                </div>
              </div>

              <div class="form-group col-sm-12">
                <div class="col-sm-3">
                  <label class="control-label" for="">Saldo Tabungan</label>
                </div>
                <div class="col-sm-6 margin">
                  <input  type="text" class="form-control" placeholder="" name="saldo" id="saldo"  value=""  disabled>
                </div>
                <div class="col-sm-3">
                </div>
              </div>

            </div>

            <div class="panel-footer col-xs-12">
                  <div class="form-group col-xs-12 ">
                      <label for="jumlah_setor" class="col-md-4">Jumlah Setoran</label><span>Rp</span>
                      <!-- <input id="pricejumlah_setor" onkeypress="return hanyaAngka(event)" type="text" class="form-control margin required number" name="jumlah_setor" value=""> -->
                      <input  onkeypress="return hanyaAngka(event)" type="text" class="form-control" name="jumlah_setor" id="price" value="">
                  </div>

                  <div class="form-group col-sm-12 margin_top">
                    <div class="col-sm-5">
                    </div>
                      <div class="col-sm-7  ">
                      <input   class="btn btn-default" type="submit" name="submit" value="Simpan">
                      </div>
                  </div>
            </div>

          </div>
        </form>
    </div>
  </div>
</div>

</div>
<?php require '_footer.php'; ?>
