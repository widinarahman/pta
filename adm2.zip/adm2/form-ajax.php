<!DOCTYPE html>
<html>
    <head>
        <title>Ajax Jquery - Belajarphp.net</title>
    </head>
    <body>
        <form action="">
            <table>
                <tr><td>NIM</td><td><input type="text" onkeyup="isi_otomatis()" id="nis"></td></tr>
                <tr><td>NAMA</td><td><input type="text" id="nama_siswa"></td></tr>
                <tr><td>kelas</td><td><input type="text" id="nama_kelas"></td></tr>
                <!-- <tr><td>ALAMAT</td><td><input type="text" id="alamat"></td></tr> -->
            </table>
        </form>

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script type="text/javascript">
            function isi_otomatis(){
                var nis = $("#nis").val();
                $.ajax({
                    url: 'proses-ajax.php',
                    data:"nis="+nis ,
                }).success(function (data) {
                    var json = data,
                    obj = JSON.parse(json);
                    $('#nama_siswa').val(obj.nama_siswa);
                    $('#nama_kelas').val(obj.nama_kelas);
                    // $('#alamat').val(obj.alamat);
                });
            }
        </script>
    </body>
</html>
