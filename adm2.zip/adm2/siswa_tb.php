<?php
include '_header.php';
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pta";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['submitx'])) {
  $nis              =$_POST['nis'];
  $kode_kelas       =$_POST['kd_kelas'];
  $nama_siswa       =$_POST['nm_siswa'];
  $alamat           =$_POST['alamat'];
  $tempat_lahir     =$_POST['tempat_lahir'];
  $tanggal_lahir    =$_POST['tgl_lahir'];
  $jenis_kelamin    =$_POST['jenis_kelamin'];

  $thn1=$_POST['thn1'];
  $thn2=$_POST['thn2'];
  $tahun_ajaran_masuk=$thn1.'/'.$thn2;

  $sql = "INSERT INTO siswa (nis, kode_kelas, nama_siswa, alamat, tempat_lahir, tanggal_lahir, jenis_kelamin, tahun_ajaran_masuk)  VALUES ('$nis', '$kode_kelas', '$nama_siswa', '$alamat', '$tempat_lahir', '$tanggal_lahir', '$jenis_kelamin', '$tahun_ajaran_masuk')";

  $kelas ="SELECT * FROM kelas WHERE kode_kelas NOT IN ('do', 'nol','lulus') ORDER BY nama_kelas";
  $result = $conn->query($kelas);

  if ($conn->query($sql) === TRUE) {
    echo "<script>alert('Berhasil menyimpan data $nama_siswa')</script>";
    echo "<script>document.location.href='siswa.php';</script>";
  } else {
      echo "Error: " . $sql . "<br>" . $conn->error;
  }

  $conn->close();
}

?>
<div class="container">
  <div class="content">
    <h4>Data Admin</h4>

    <ol class="breadcrumb">
      <li class="ti-panel">
        <a href="index.php">Dasboard</a>
      </li>
      <li>
        <a href="tabungan.php">Tabungan</a>
      </li>
      <li class="active">
        Input Nasabah Tabungan
      </li>
    </ol>

    <br>
    <div class="row">
      <div class="col-md-3">
      </div>
      <div class="col-md-7">
         <form id="form1" class="form-inline" action="" method="post">
          <div class="panel panel-default">
            <div class="panel-heading">Input Siswa </div>
            <div class="panel-body">
              <!--  NIS-->
              <div class="form-group col-md-12">
                <div class="col-sm-3">
                  <label class="control-label" for="">NIS</label>
                </div>
                <div class="col-sm-6 margin"  >
                  <input style="width:100px;" type="text" class="form-control" placeholder="NIS Siswa" name="nis"  value="" required>
                </div>
                <div class="col-sm-3">
                </div>
              </div>
              <!-- Tanggal masuk -->
              <div class="form-group col-md-12">
                <div class="col-sm-3">
                  <label class="control-label" for="">Tanggal Masuk</label>
                </div>
                <div class="col-sm-6 margin"  >
                  <input style="width:70px;" type="text" class="form-control" placeholder="Tahun Ajaran" name="thn1" required>
                  /
                  <input style="width:70px;" type="text" class="form-control" placeholder="Tahun Ajaran" name="thn2" required>
                  <br>
                  <span>Contoh 2018/2019</span>
                </div>
                <div class="col-sm-3">
                </div>
              </div>
              <!-- Nama siswa -->
              <div class="form-group col-md-12">
                <div class="col-sm-3">
                  <label class="control-label" for="nama">Nama Siswa</label>
                </div>
                <div class="col-sm-6 margin">
                  <input id="nama" type="text" class="form-control require" placeholder="Nama Siswa"  name="nm_siswa"  value="" required>
                </div>
                <div class="col-sm-3">
                </div>
              </div>
              <!--  tanggal lahir-->
              <div class="form-group col-md-12 ">
                <div class="col-sm-3">
                  <label class="control-label" for="">TLL</label>
                </div>
                <div class="col-sm-5 margin">
                  <input type="text" class="form-control" placeholder="Tempat Lahir"  name="tempat_lahir">
                </div>
                <div class="col-sm-4  input-group date" data-provide="datepicker">
                  <input type="date" class="form-control" placeholder="0000-00-00" name="tgl_lahir" required>
                  <div class="input-group-addon" >
                    <span class="glyphicon glyphicon-th"></span>
                  </div>
                </div>
              </div>
              <!-- kelas -->
              <div class="form-group col-md-12">
                <div class="col-sm-3">
                  <label class="control-label" for="">Kelas</label>
                </div>
                <div class="col-sm-6 margin">
                  <select class="" name="kd_kelas" class="form-control" required>
                      <option> Pilih Kelas Siswa</option>

                  </select>
                </div>
                <div class="col-sm-3">
                </div>
               </div>
               <!-- jenis kelamin -->
              <div class="form-inline col-md-12">
                <div class="col-sm-3">
                  <label class="control-label" for="">Jenis Kelamin</label>
                </div>
                <div class="col-sm-6">
                    <label  for="" class="radio-inlin"><input  type="radio" name="jenis_kelamin" value="L">Laki-laki</label>
                    <label  for="" class="radio-inline"><input  type="radio" name="jenis_kelamin" value="P">Perempuan</label>
                </div>
                <div class="col-sm-3">
                </div>
              </div>
              <div class="form-group col-md-12">
                <div class="col-sm-3">
                  <label class="control-label" for="">Alamat</label>
                </div>
                <div class="col-sm-9 margin">
                  <textarea name="alamat" rows="4" class="form-control" cols="40" required></textarea>
                </div>
                <!-- <div class="col-sm-3">
                </div> -->
              </div>




              <div class="form-group col-sm-12 margin_top">
                <div class="col-sm-5">
                </div>
                  <div class="col-sm-7  ">
                  <input class="btn btn-default" type="submit" name="submitx" value="Simpan">
                  <input class="btn btn-default" type="submit" name="" value="Cancel">
                  </div>
              </div>



            </div>
          </div>
        </form>
    </div>
    </div>
  </div>
 </div>
<?php
include '_footer.php';
 ?>
