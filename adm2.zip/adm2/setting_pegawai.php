<?php
  require 'config/config.php';
  require '_header.php';

  $result=tampil_peg();
 ?>
<div class="container">
  <div class="content">
    <h4>Data Pegawai</h4>
    <ol class="breadcrumb">
      <li class="ti-panel">
        <a href="?">Dasboard</a>
      </li>
      <li class="active">
        Data Pegawai
      </li>
    </ol>
    <div class="row">
      <div class="col-lg-5">
        <button class="btn btn-default" type="button" name="" value="Tambah" onclick="window.location.href='setting_input_admin.php'">Tambah</button>
      </div>
    </div>
    <br>
    <div class="table-responsive">
      <table id="data" class="table table-striped table-bordered data">
        <thead>
          <tr>
            <th width="5%">N0</th>
            <th width="10%">NIP</th>
            <th width="20%">Nama </th>
            <th width="10%">Gender </th>
            <th width="15%">Telepon </th>
            <th width="10%">Status</th>
            <th width="30%">Alamat</th>
            <th width="10%">Setiing</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $no=1;
          while ($a=mysqli_fetch_assoc($result)) {
            ?>
              <tr>
                <td><?php echo $no; ?></td>
                <td><?php echo $a['nip']; ?></td>
                <td><?php echo $a['nama_pegawai']; ?></td>
                <td><?php echo $a['jenis_kelamin']; ?></td>
                <td><?php echo $a['no_telepon']; ?></td>
                <td><?php echo $a['status_pegawai']; ?></td>
                <td><?php echo $a['alamat']; ?></td>
                <td class="center">
                  <a class="glyphicon glyphicon-edit" href="transaksi_cek.php?id=<?= $a['id'];?>"></a>
                  <a class="glyphicon glyphicon-trash" href="#"></a>
                </td>
              </tr>
            <?php
            $no++;
          }
          ?>
        </tbody>
      </table>
    </div>
  </div>
  </div>
<?php require '_footer.php'; ?>
