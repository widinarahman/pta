<?php
  require 'config/config.php';
  require '_header.php';

    // Tahun Ajaran
    $thn_aktif=thn_ajar_aktif();
    while ($a=mysqli_fetch_assoc($thn_aktif)) {
    $aktif=$a['tahun_ajaran'];
    $kd_aktif=$a['kode_tahun_ajaran'];
  }
 // Menampilkan data transaksi berdasarkan tahun yang aktif
 $kode_tahun_ajaran=$kd_aktif;
  $result=tampil_transaksi_pemasukan($kode_tahun_ajaran);


 ?>
<div class="container">
  <div class="content">
    <h4>Data Pemasukan</h4>
    <ol class="breadcrumb">
      <li class="ti-panel">
        <a href="?">Dasboard</a>
      </li>
      <li class="active">
        Data Pemasukan
      </li>
    </ol>
    <div class="row">
      <div class="col-lg-5">
        <p>Jenis Pembayaran</p>
        <button class="btn btn-default" type="button" name="" value="Perbulan" onclick="window.location.href='transaksi_p_perbulan.php'">Perbulan</button>
        <button class="btn btn-default" type="button" name="" value="Persemester" onclick="window.location.href='transaksi_p_persemester.php'">Persemester</button>
        <button class="btn btn-default" type="button" name="" value="Pertahun" onclick="window.location.href='transaksi_p_pertahun.php'">Pertahun</button>
        <button class="btn btn-default" type="button" name="" value="Awal Tahun" onclick="window.location.href='transaksi_p_awal_tahun.php'">Awal Tahun</button>
      </div>
    </div><br>
    <div class="row">
      <div class="col-lg-5">
        <p><b>Tahun Ajaran</b><a class='label label-warning'><?php echo $aktif; ?></a></p>
      </div>
    </div>
    <br>
    <div class="table-responsive">
      <table id="data" class="table table-striped table-bordered data">
        <thead>
          <tr>
            <th width="5%">NO</th>
            <th width="10%">Tanggal</th>
            <th width="15%">Pembayaran</th>
            <th width="5%">NIS</th>
            <th width="15%">Nama</th>
            <th width="10%">Bulan</th>
            <th width="10%">Semester</th>
            <th width="10%">TA</th>
            <th width="10%">Jumlah</th>
            <th width="5%">Setting</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $no=1;
          while ($a=mysqli_fetch_assoc($result))
          {
            ?>
              <tr>
                <td><?php echo $no; ?></td>
                <td><?php echo $a['tanggal_transaksi']; ?></td>
                <td><?php echo $a['nama_pembayaran']; ?></td>
                <td><?php echo $a['nis']; ?></td>
                <td><?php echo $a['nama_siswa']; ?></td>
                <td><?php echo $a['bulan']; ?></td>
                <td><?php echo $a['semester']; ?></td>
                <td><?php echo $a['tahun_ajaran']; ?></td>
                <td><?php echo rupiah($a['jumlah']); ?></td>
                <td class="center">
                  <a class="glyphicon glyphicon-trash" href="hapus/hapus_transaksi.php?id=<?=$a['kode_transaksi'];?>" onclick="return confirm('Yakin anda ingin menghapusnya NO Rekening <?=$a['kode_transaksi']?>')"></a>
                </td>
              </tr>
            <?php
           $no++;
          }
          ?>
        </tbody>
      </table>
    </div>
  </div>
  </div>
<?php require '_footer.php'; ?>
