<?php

  require 'config/config.php';
  require '_header.php';
  if (isset($_POST['submit'])) {
    $kd_thn_ajaran=$_POST['kd_thn_ajaran'];
    $kd_pembayaran=$_POST['kd_pembayaran'];
    $jml_pembayaran=$_POST['jml_pembayaran'];

    if (!preg_match('/^[0-9]*$/',$jml_pembayaran)) {
      echo "<script>alert('Jumlah pembayaran harus menggunakan angka !')</script>";
    }
    elseif (inputjumlahpembayaran($kd_thn_ajaran, $kd_pembayaran, $jml_pembayaran)) {
      echo "<script>alert('Jumlah pembayaran berhasil di masukan')</script>";
      echo "<script>window.location.href='setting_jumlahpembayaran.php'</script>";
    }else {
      echo "Error: " . $query . "<br>" . mysqli_error($konek);
    }
  }
  $pembayaran=tampilpembayaran();
  $thn=tampiltahunajaran();
   ?>
<div class="container">
  <div class="content">
    <h4>Data Jumlah Pembayaran</h4>
    <ol class="breadcrumb">
      <li class="ti-panel">
        <a href="index.php">Dasboard</a>
      </li>
      <li>
        <a href="setting_jumlahpembayaran.php">Jumlah Data Pembayaran</a>
      </li>
      <li class="active">
        Input Jumlah Pembayaran
      </li>
    </ol>

    <br>
    <div class="row">
      <div class="col-md-3">

      </div>
      <div class="col-md-7">
        <!-- <div class="alert alert-info" role="alert">
          <b>Info</b> Untuk menambah kelas silahkan masukan kode dan nama kelas, kode kelas dan nama kelas tidak boleh sama !
        </div> -->
        <form class="" action="" method="post" enctype="multipart/form-data">
        <div class="panel panel-default">
          <div class="panel-heading">Input Pembayaran </div>
          <div class="panel-body">

            <div class="form-group">
              <label class="col-sm-4 control-label" for="">Nama Pembayaran</label>
              <div class="col-sm-5 ">
                <select  name="kd_pembayaran" class="form-control">
                  <option> PILIH</option>
                  <?php
                  while($data=mysqli_fetch_assoc($pembayaran)){
                  echo "<option VALUE=$data[kode_pembayaran]>$data[nama_pembayaran]</option>";
                  }
                  ?>



                </select>
              </div>
            </div><br>

            <div class="form-group">
              <label class="col-sm-4 control-label" for="">Tahun Ajaran</label>
              <div class="col-sm-5 ">
                <select  name="kd_thn_ajaran" class="form-control">
                  <option> PILIH</option>
                  <?php
                      while($data=mysqli_fetch_assoc($thn)){
                      echo "<option value=$data[kode_tahun_ajaran]>$data[tahun_ajaran]</option>";
                      } ?>

                </select>
              </div>
            </div><br>
            <div class="form-group">
              <label class="col-sm-4 control-label" for="">Jumlah Pembayaran</label>
              <div class="col-sm-5 ">
                <input onkeypress="return hanyaAngka(event)" type="text" class="form-control" placeholder="Jumlah" name="jml_pembayaran"   value="" required>
                <span>Nominal</span>
              </div>
            </div>
            <br>
            <div class="form-group">
              <div class="col-sm-4">
                <input class="btn btn-default" type="submit" name="submit" value="Simpan">
              </div>
            </div>

          </div>
        </div>
          </form>
      </div>
    </div>
    </div>
  </div>
  <script type="text/javascript">
  function hanyaAngka(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode
     if (charCode > 31 && (charCode < 48 || charCode > 57))

      return false;
    return true;
  }
  </script>
<?php require '_footer.php'; ?>
