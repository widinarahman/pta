<?php

  require 'config/config.php';
  require '_header.php';

  $thn_aktif=thn_ajar_aktif();
  while ($a=mysqli_fetch_assoc($thn_aktif)) {
  $aktif=$a['tahun_ajaran'];
  $kd_aktif=$a['kode_tahun_ajaran'];
}

  $kode_tahun_ajaran=$kd_aktif;
  $result=tampil_transaksi_pengeluaran($kode_tahun_ajaran);
 ?>
<div class="container">
  <div class="content">
    <h4>Data Pengeluaran</h4>
    <ol class="breadcrumb">
      <li class="ti-panel">
        <a href="?">Dasboard</a>
      </li>
      <li class="active">
        Data Pengeluaran
      </li>
    </ol>
    <div class="row">
      <div class="col-lg-5">
        <button class="btn btn-default" type="button" name="" value="" onclick="window.location.href='transaksi_pengeluaran_tmb.php'">Tambah</button>
      </div>
    </div><br>
    <div class="row">
      <div class="col-lg-5">
        <p><b>Tahun Ajaran</b><a class='label label-warning'><?php echo $aktif; ?></a></p>
      </div>
    </div>
    <br>
    <div class="table-responsive">
      <table id="data" class="table table-striped table-bordered data">
        <thead>
          <tr>
            <th width=5%>No</th>
            <th width="10%">Tanggal</th>
            <th width="5%">Kode Transaksi</th>
            <th width="17%">Nama Pengeluaran</th>
            <th width="17%">Dari Pembayaran</th>
            <th class="center" width="16%">Keterangan</th>
            <th width="10%">TA</th>
            <th width="10%">Jumlah</th>
            <th width="5">Hapus</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $no=1;
          while ($a=mysqli_fetch_assoc($result)) {
            ?>
              <tr>

                <td><?php echo $no ?></td>
                <td><?php echo $a['tanggal_transaksi']; ?></td>
                <td><?php echo $a['kode_transaksi']; ?></td>
                <td><?php echo $a['nama_pengeluaran']; ?></td>
                <td><?php echo $a['nama_pembayaran']; ?></td>
                <td><?php echo $a['keterangan']; ?></td>
                <td><?php echo $a['tahun_ajaran']; ?></td>
                <td><?php echo rupiah($a['jumlah']); ?></td>
                <td class="center">

                  <a class="glyphicon glyphicon-trash" href="#"></a>
                </td>
              </tr>
            <?php
            $no++;
           }
          ?>
        </tbody>
      </table>
    </div>
  </div>
  </div>
<?php require '_footer.php'; ?>
