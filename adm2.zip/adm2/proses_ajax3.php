<?php
  include 'config/config.php';
  $mode = $_GET['mode'];


    switch ($mode) {

      	case 'get_table':

      	$kode_kelas = $_GET['kode_kelas'];


        $query ="SELECT a.nis,a.nama_siswa,a.tempat_lahir,a.tanggal_lahir,a.alamat,a.jenis_kelamin,a.tahun_ajaran_masuk,a.kode_kelas,b.nama_kelas
                  from siswa a join kelas b on a.kode_kelas=b.kode_kelas
                  where a.kode_kelas = '$kode_kelas'
                  order by a.nama_siswa";
        $query = mysqli_query($konek, $query);
        //$datatable = mysqli_fetch_array($query,MYSQLI_NUM);
        $data = [];
        $i = 0;
        while ($datatable=mysqli_fetch_assoc($query)) {
        $data[$i]=  array(
                      'nis' => $datatable['nis'],
                      'nama_siswa' => $datatable['nama_siswa'],
                      'tempat_lahir' => $datatable['tempat_lahir'],
                      'tanggal_lahir' => $datatable['tanggal_lahir'],
                      'alamat' => $datatable['alamat'],
                      'jenis_kelamin' => $datatable['jenis_kelamin'],
                      'tahun_ajaran_masuk' => $datatable['tahun_ajaran_masuk'],
                      'nama_kelas' => $datatable['nama_kelas'],
                      );
                    $i++;

                  }
                  echo json_encode($data);

                  default:
                    // echo "wee error";
                  break;


      }
 ?>
