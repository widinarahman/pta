<?php
  include 'config/config.php';
  $mode = $_GET['mode'];


    switch ($mode) {

      	case 'get_table':

        $kd_pem=$_GET['kd_pem'];
        $kd_thn=$_GET['kd_thn'];

        $sp ="CALL sp_PemasukanPengeluaran('$kd_pem', '$kd_thn')";
        $query=mysqli_query($konek,$sp);

        //$datatable = mysqli_fetch_array($query,MYSQLI_NUM);
        $data = [];
        $i = 0;
        while ($datatable=mysqli_fetch_array($query)) {
        $data[$i]=  array(
                      'tanggal' => $datatable['0'],
                      'nm_pm' => $datatable['1'],
                      'jns_trns' => $datatable['2'],
                      'total' => $datatable['3'],
                      );
                    $i++;

                  }
                  echo json_encode($data);


                  default:
                    // echo "wee error";
                  break;
      //   echo "{".$datatable['0']."->".$datatable['1']."->".$datatable['2']."->".$datatable['3']."}";
      // }


      }
 ?>
