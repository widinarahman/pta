<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Ajax</title>
    <script src="js/jquery.min.js"></script>
    <link rel="stylesheet" href="asset/css/bootstrap.min.css" />
    <script src="asset/js/bootstrap.min.js"></script>
  </head>
  <body onload="viewData()">
    <div class="container">
      <p></p>
      <button class="btn btn-primary"  data-toggle="modal" data-target="#addData">Insert Data</button >
        <!-- Modal -->
      <div class="modal fade" id="addData" tabindex="-1" role="dialog" aria-labelledby="addLabel">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title" id="addLabel">Insert Data</h4>
            </div>
            <form>
            <div class="modal-body">
              <div class="form-group">
                <label for="nm">Full name</label>
                <input type="text" class="form-control" id="nm" placeholder="Nama Lengkap">
              </div>
              <div class="form-group">
                <label for="em">email</label>
                <input type="email" class="form-control" id="em" placeholder="Email">

              </div>
              <div class="form-group">
                <label for="hp">Phone number</label>
                <input type="number" class="form-control" id="hp" placeholder="Nomor tlfn">


              </div>
              <div class="form-group">
                <label for="al">address</label>
                <!-- <textarea type="text" class="form-control" id="al" placeholder="alamat"></textarea>
                -->
                <select class="form-control" id="al">
                  <?php
                $konek = mysqli_connect("localhost","root","","ajaxdata");
                $query = "select * from address";
                $hasil = mysqli_query($konek,$query);
                while($data=mysqli_fetch_array($hasil)){
                echo "<option value=$data[id_provinsi]>$data[nama_provinsi]</option>";
              } ?>
              </select>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              <button type="submit" onclick="saveData()"class="btn btn-primary">Save </button>
            </div>
            </form>
          </div>
        </div>
      </div>
      <div id="result"></div>
      <p></p>
        <table class="table table-bordered table-striped">
          <thead>
            <tr>
              <th width="40">ID</th>
              <th>Nama</th>
              <th>email</th>
              <th>Phone</th>
              <th>address</th>
              <th width="150">Action</th>
            </tr>
          </thead>
          <tbody>

          </tbody>
        </table>
    </div>
  </script>
  <script>

    function saveData() {
      var name = $('#nm').val();
      var email = $('#em').val();
      var phone = $('#hp').val();
      var address = $('#al').val();
      $.ajax({
        type :"POST",
        url:"server.php?p=add",
        data:"nm="+name+"&em="+email+"&hp="+phone+"&al="+address,
        success:function (data) {
          viewData();
        }
      });
    }
    function viewData() {
      $.ajax({
        type:"GET",
        url:"server.php",
        success:function(data){
          $('tbody').html(data);
        }
      });
    }
    function updateData(str) {
      var id = str;
      var name = $('#nm-'+str).val();
      var email = $('#em-'+str).val();
      var phone = $('#hp-'+str).val();
      var address = $('#al-'+str).val();
     $.ajax({
        type :"POST",
        url : "server.php?p=edit",
        data:"nm="+name+"&em="+email+"&hp="+phone+"&al="+address+"&id="+id,
        success:function (data) {
          viewData();
        }
      });
    }
  </script>
  </body>
</html>
