<?php
include 'config/config.php';

$no_rekening = $_GET['no_rekening'];
$query = mysqli_query($konek, "SELECT * FROM no_tabungan WHERE no_rekening='$no_rekening' ");
$mahasiswa = mysqli_fetch_array($query);
$data = array(
            'nis'      =>  $mahasiswa['nis'],
            'saldo'   =>  $mahasiswa['saldo'],
            // 'alamat'    =>  $mahasiswa['alamat'],
          );
 echo json_encode($data);
?>
