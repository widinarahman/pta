<?php
  require 'config/config.php';
  require '_header.php';

  if (isset($_POST['submit'])) {
    $thn1=$_POST['thn1'];
    $thn2=$_POST['thn2'];
    $thn_ajaran=$thn1.'/'.$thn2;
    $status='Tidak Aktif';


    $x=strlen($thn1);
    $y=strlen($thn2);


    $cekTahunAjaran = mysqli_fetch_row(mysqli_query($konek, "SELECT * FROM tahun_ajaran WHERE tahun_ajaran='$thn_ajaran'"));

    if ($cekTahunAjaran > 0) {
      echo "<script>alert('Tahun Ajaran yang anda masukan sudah ada, silahkan masukan yang lain')</script>";
    }
    elseif(!preg_match('/^[0-9]*$/',$thn1)){
      echo "<script>alert('Tahun Ajaran harus huruf !')</script>";
    }
    elseif(!preg_match('/^[0-9]*$/',$thn2)){
      echo "<script>alert('Tahun Ajaran harus huruf !')</script>";
    }
    elseif($thn1 >= $thn2){
      echo "<script>alert('Maaf Tahun Ajaran  Tidak Valid, Tahun ke 2 harus lebih besar 1 dari tahun pertama !')</script>";
    }
    elseif($x && $x < 4){
      echo "<script>alert('Tahun Ajaran tidak valid !')</script>";
    }
    elseif (input_thn_ajaran($thn_ajaran, $status)) {
      echo "<script>alert('Tahun ajaran $thn_ajaran telah tersimpan')</script>";
    }else {
       echo "Error: " . $query . "<br>" . mysqli_error($konek);
    }
  }
 ?>
<div class="container">
  <div class="content">
    <h4>Data Tahun Ajaran</h4>
    <ol class="breadcrumb">
      <li class="ti-panel">
        <a href="index.php">Dasboard</a>
      </li>
      <li>
        <a href="setting_thn_ajaran.php">Data Tahun Ajaran</a>
      </li>
      <li class="active">
        Input Tahun Ajaran
      </li>
    </ol>

    <br>
    <style media="screen">
      .center{
        text-align: center;
      }
    </style>
    <div class="row">
      <div class="col-md-3">

      </div>
      <div class="col-md-6">
        <div class="alert alert-info" role="alert">
          <b>Info</b> Untuk menambah Tahun Ajaran silakan masukan tahun ajaran dengan format tahun/tahun sebagai contoh 2017/2018 dan untuk mengaktifan klik button pada tabel Tahun Ajaran.
        </div>
        <form class="" action="" method="post">
          <div class="panel panel-default">
            <div class="panel-heading">Input Tahun Ajaran </div>
            <div class="panel-body">

              <div class="form-inline">
                <label style="width:150px;" class="control-label" for="">Tahun Ajaran</label>
                <input onkeypress="return hanyaAngka(event)" maxlength="4" style="width:60px;" type="text" class="form-control" placeholder="2017" name="thn1" value=""> /
                <input onkeypress="return hanyaAngka(event)" maxlength="4" placeholder="2018" class="form-control" style="width:60px;" type="text" name="thn2" value="">
              </div>
              <!--
              <div class="form-group col-md-12">
                <div class="col-sm-3">
                  <label class="control-label" for="">Tanggal Masuk</label>
                </div>
                <div class="col-sm-9">
                  <input style="width:70px;" type="text" class="form-control" placeholder="Tahun Ajaran" name="thn_ajaran" required><input style="width:70px;" type="text" class="form-control" placeholder="Tahun Ajaran" name="thn_ajaran" required>


                </div>
                <div class="col-sm-3">
                </div>
              </div>
              <br> -->
              <br>
              <div class="form-group">
                <div class="col-sm-12">

                <div class="col-sm-5">

                </div>
                <div class="col-sm-6">
                  <input class="btn btn-default" type="submit" name="submit" value="Simpan">
                </div>
                </div>
              </div>

            </div>
          </div>
        </form>
      </div>
    </div>
    </div>
  </div>
  <script type="text/javascript">
  function hanyaAngka(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode
     if (charCode > 31 && (charCode < 48 || charCode > 57))

      return false;
    return true;
  }
  </script>
<?php require '_footer.php'; ?>
