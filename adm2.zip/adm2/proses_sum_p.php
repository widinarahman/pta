<?php
include 'config/config.php';

$kode_pembayaran = $_GET['kode_pembayaran'];
$query = mysqli_query($konek, "SELECT SUM(jumlah) FROM transaksi WHERE kode_pembayaran ='$kode_pembayaran' and jenis_transaksi='Pemasukan'");
$siswa = mysqli_fetch_array($query);
$data = array(
            'isi'      =>  $siswa['0'],

            // 'alamat'    =>  $mahasiswa['alamat'],
          );
 echo json_encode($data);
?>
