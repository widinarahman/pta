<?php

  require 'config/config.php';
  require '_header.php';

  $result=tampilsiswa();
 ?>
<div class="container">
  <div class="content">
    <h4>Data Siswa</h4>
    <ol class="breadcrumb">
      <li class="ti-panel">
        <a href="?">Dasboard</a>
      </li>
      <li class="active">
        Data Data Siswa
      </li>
    </ol>
    <div class="row">
      <div class="col-lg-5">
        <button class="btn btn-default" type="button" name="" value="Tambah" onclick="window.location.href='siswa_tambah.php'">Input Siswa</button>
      </div>
    </div>
    <br>
    <div class="table-responsive">
      <table id="data" class="table table-striped table-bordered data">
        <thead>
          <tr>
            <th width="5%">NO</th>
            <th width="5%">NIS</th>
            <th width="15%">Nama Siswa</th>
            <th width="10%">No</th>
            <th width="15%">Kelas </th>
            <tH width="15%"> Alamat</th>
            <th width="15%">TTL</th>
            <th width="5%">JK</th>
            <th width="10%">T Masuk</th>
            <th width="5%">Setiing</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $no=1;
          while ($a=mysqli_fetch_assoc($result)) {
            ?>
            <tr>
              <td><?php echo $no; ?></td>
              <td><?php echo $a['nis']; ?></td>
              <td><?php echo $a['nama_siswa']; ?></td>
              <td><?php echo $a['no_tlp']; ?></td>
              <td><?php echo $a['nama_kelas']; ?></td>
              <td><?php echo $a['alamat']; ?></td>
              <td><?php echo $a['tempat_lahir'];echo ", ";echo $a['tanggal_lahir']; ?></td>
              <td><?php echo $a['jenis_kelamin']; ?></td>
              <td><?php echo $a['tahun_ajaran_masuk']; ?></td>
              <td class="center">
                <a class="glyphicon glyphicon-edit" href="siswa_hapus.php?nis=<?=$a['nis'];?>"  onclick="return confirm('Yakin anda ingin menghapusnya NIS <?=$a['nis'];?> ?')"></a>
                <a class="glyphicon glyphicon-trash" href="siswa_edit.php?nis=<?=$a['nis'];?>"></a>
              </td>
            </tr>
            <?php
            $no++;
          }
          ?>
        </tbody>
      </table>
    </div>
  </div>
  </div>
<?php require '_footer.php'; ?>
