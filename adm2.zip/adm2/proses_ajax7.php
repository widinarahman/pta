<?php
  include 'config/config.php';
  $mode = $_GET['mode'];


    switch ($mode) {

      	case 'get_table':

        $thn_sekarang=$_GET['kd_pem'];
        $bln_sekarang=$_GET['kd_thn'];
        $bln_lalu=0;
        $thn_lalu=0;
        //$x=1;

        if ($bln_sekarang == 1) {
          $bln_lalu = 12;
          $thn_lalu = $thn_sekarang - 1;
        }else {
          $bln_lalu = $bln_sekarang - 1;
          $thn_lalu = $thn_sekarang;
        }

        $sp ="CALL sp_LaporanKeuangan('$bln_sekarang', '$bln_lalu',  '$thn_sekarang', '$thn_lalu' )";
        $query=mysqli_query($konek,$sp);

        //$datatable = mysqli_fetch_array($query,MYSQLI_NUM);
        $data = [];
        $i = 0;
        while ($datatable=mysqli_fetch_array($query)) {
        $data[$i]=  array(
                      '1' => $datatable['0'],
                      '2' => $datatable['1'],
                      '3' => $datatable['2'],
                      '4' => $datatable['3'],
                      '5' => $datatable['4'],
                      '6' => $datatable['5'],
                      '7' => $datatable['6'],
                      '8' => $datatable['7'],
                      '9' => $datatable['8'],

                      );
                    $i++;

                  }
                  echo json_encode($data);


                  default:
                    // echo "wee error";
                  break;
      //   echo "{".$datatable['0']."->".$datatable['1']."->".$datatable['2']."->".$datatable['3']."}";
      // }


      }
 ?>
