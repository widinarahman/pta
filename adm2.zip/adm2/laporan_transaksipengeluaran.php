<?php
require 'config/config.php';
require '_header.php';

$result1=tampil_bulan();
$result2=tampilpembayaran_sem();

// $kode_pem =99;
// $kode_thn=2;
//
// $sp ="CALL sp_TunggakanPerbulan ('$kode_pem', '$kode_thn')";

// $r=$konek->query($sp);
//$querypro=mysqli_query($konek,$sp);

?>

<div class="container">
  <div class="content">
    <h4> Data Siswa</h4>
    <ol class="breadcrumb">
      <li class="ti-panel">
        <a href="?">Dasboard</a>
      </li>
      <li class="active">
        Laporan Data Siwa
      </li>
    </ol>

    <!--Pembayaran-->
    <div class="row">
      <!-- <input id="kd_pem" type="text" name="" value="" onkeyup="isi_otomatis()">
      <input id="kd_thn" type="text" name="" value="" onkeyup="isi_otomatis()"> -->
      <div class="col-md-4">
        <label for="">Jenis Pembayaran</label>
        <select id="kd_pem" class="" name="">
          <option value="">Pilih Jenis Pembayaran</option>
            <option value="2016">2016</option>
            <option value="2017">2017</option>
            <option value="2018">2018</option>
            <option value="2019">2019</option>
            <option value="2020">2020</option>
            <option value="2021">2021</option>
            <option value="2022">2022</option>
            <option value="2023">2023</option>

        </select>
      </div>
      <!--  Tahun Ajaran-->
      <div class="col-md-3">
        <label for="">Bulan</label>
        <select id="kd_thn" class="" name="">
          <option value="">Pilih Bulan</option>
          <?php while ($a=mysqli_fetch_assoc($result1)) {  ?>
            <option value="<?php echo $a['kode_bulan']; ?>"  onclick="isi_otomatis()"> <?php echo $a['bulan']; ?></option>
          <?php } ?>
        </select>
      </div>
      <button type="button" name="button">Ok</button>

    </div>
    <br>
    <div class="table-responsive">
      <table id="data2" class="table table-striped table-bordered data">
        <thead>
          <tr>
            <td>NIS</td>
            <td>Nama Siswa</td>
            <td>Nama Kelas</td>
            <td>Genap</td>
            <td>Ganjil</td>
            <td>Tota Bayar</td>
          </tr>
        </thead>
          <tbody id="datax">

              <?php
                // while ($result= mysqli_fetch_array($querypro)) {
                //   $data1=$result['0'];
                //   $data2=$result['1'];
                //   $data3=$result['2'];
                //   $data4=$result['3'];
                //   $data5=$result['4'];
                //   $data6=$result['5'];
                //   $data7=$result['6'];
                //   $data8=$result['7'];
                //   $data9=$result['8'];
                //   $data10=$result['9'];
                //   $data11=$result['10'];
                //   $data12=$result['11'];
                //   $data13=$result['12'];
                //   $data14=$result['13'];
                //   $data15=$result['14'];
                //   $data16=$result['15'];
              ?>
            <!-- <tr>
              <td><?php //echo $data1;  ?></td>
              <td><?php //echo $data2;  ?></td>
              <td><?php //echo $data3;  ?></td>
              <td><?php //echo $data4;  ?></td>
              <td><?php //echo $data5;  ?></td>
              <td><?php //echo $data6;  ?></td>
              <td><?php //echo $data7;  ?></td>
              <td><?php //echo $data8;  ?></td>
              <td><?php //echo $data9;  ?></td>
              <td><?php //echo $data10;  ?></td>
              <td><?php //echo $data11;  ?></td>
              <td><?php //echo $data12;  ?></td>
              <td><?php //echo $data13;  ?></td>
              <td><?php //echo $data14;  ?></td>
              <td><?php //echo $data15;  ?></td>
              <td><?php //echo $data16;  ?></td>

            </tr> -->
          <?php


//        }
          ?>

      </tbody>
     </table>
  </div>
</div>
<script type="text/javascript">
    function isi_otomatis(){
      var kd_pem=$("#kd_pem").val();
      var kd_thn=$("#kd_thn").val();
      if($("#kd_thn").val()==null){
        kd_thn=0;
      }
      if($("#kd_pem").val()==null){
        kd_pem=0;
      }

      get_table(kd_pem, kd_thn);
    }
    function get_table(kd_pem, kd_thn) {
      $.ajax({
        url:'proses_ajax6.php',
        data:{mode:'get_table', kd_pem:kd_pem, kd_thn:kd_thn}
      }).success(function(data){
        var json = data,
        obj = JSON.parse(json);
        var tabeldata = document.getElementById('data2').getElementsByTagName('tbody')[0];
        var j = 0;
        document.getElementById('datax').innerHTML= "";
        for (var i = obj.length - 1; i >= 0; i--) {
         row = tabeldata.insertRow(tabeldata.rows.length);
         row.value = i;
                cell1 = row.insertCell(0);
                cell2 = row.insertCell(1);
                cell3 = row.insertCell(2);
                cell4 = row.insertCell(3);
                cell5 = row.insertCell(4);
                cell6 = row.insertCell(5);
                cell7 = row.insertCell(6);


                cell1.innerHTML  = obj[j]['1'];
                cell2.innerHTML  = obj[j]['2'];
                cell3.innerHTML  = obj[j]['3'];
                cell4.innerHTML  = obj[j]['4'];
                cell5.innerHTML  = obj[j]['5'];
                cell6.innerHTML  = obj[j]['6'];
                cell6.innerHTML  = obj[j]['7'];


        j++;
        }
    });

    }
</script>

<?php
 //mysqli_free_result($r);
require '_footer.php';
 ?>
