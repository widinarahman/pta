<?php
require_once 'config/config.php';

 // require_once 'config/config.php';
 require '_header.php';
   ?>

  <?php
  // $id=$_SESSION['id_admin'];
  // echo "ini adalah .$id ";
   ?>
 <style media="screen">
 .card{
   border-radius: 6px;
   box-shadow: 0 2px 2px rgba(204, 197, 185, 0.5);
   background-color: #FFFFFF;
   color: #252422;
   margin-bottom: 20px;
   position: relative;
   z-index: 1;
 }
 .card .content{
   padding: 15px 15px 10px 15px;
 }
 </style>
 <div class="container">
   <div class="content">
     <div class="container-fluid">
         <div class="row" style="margin-top:100px; ">
             <ol class="breadcrumb">
               <li class="active">
                 <a>Dasboard</a>
               </li>
             </ol>
             <div class="col-lg-3 col-sm-6">
                 <div class="card">
                     <div class="content" style="margin-top :0px;">
                         <div class="row">
                             <div class="col-xs-5">
                                 <div class="icon-big icon-warning text-center">
                                     <i class="ti-server"></i>
                                 </div>
                             </div>
                             <div class="col-xs-7">
                                 <div class="numbers">
                                     <p>Nasbah Tabungan</p>
                                     <span class="label label-info">10 Nasabah</span>
                                 </div>
                             </div>
                         </div>
                         <div class="footer">
                             <hr />
                             <div class="stats">
                                 <!-- <i class="ti-reload"> -->
                                   <a href="#">Detail</a>
                                 <!-- </i> -->
                             </div>
                         </div>
                     </div>
                 </div>
             </div>
             <div class="col-lg-3 col-sm-6">
                 <div class="card">
                     <div class="content" style="margin-top :0px">
                         <div class="row">
                             <div class="col-xs-5">
                                 <div class="icon-big icon-success text-center">
                                     <i class="ti-wallet"></i>
                                 </div>
                             </div>
                             <div class="col-xs-7">
                                 <div class="numbers">
                                     <p>Total Tabungan</p>
                                     <span class="label label-info">Rp.200.000</span>
                                 </div>
                             </div>
                         </div>
                         <div class="footer">
                             <hr />
                             <div class="stats">
                                 <!-- <i class="ti-calendar"></i> Last day -->
                                 <a href="#">Detail</a>
                             </div>
                         </div>
                     </div>
                 </div>
             </div>
             <div class="col-lg-3 col-sm-6">
                 <div class="card">
                     <div class="content" style="margin-top :0px;">
                         <div class="row">
                             <div class="col-xs-5">
                                 <div class="icon-big icon-danger text-center">
                                     <i class="ti-pulse"></i>
                                 </div>
                             </div>
                             <div class="col-xs-7">
                                 <div class="numbers">
                                     <p>Total Penarikan</p>
                                     <span class="label label-info">Rp.100.000</span>
                                 </div>
                             </div>
                         </div>
                         <div class="footer">
                             <hr />
                             <div class="stats">
                                 <!-- <i class="ti-timer"></i> In the last hour -->
                                 <a href="#">Detail</a>
                             </div>
                         </div>
                     </div>
                 </div>
             </div>
             <div class="col-lg-3 col-sm-6">
                 <div class="card">
                     <div class="content" style="margin-top :0px;">
                         <div class="row">
                             <div class="col-xs-5">
                                 <div class="icon-big icon-info text-center">
                                     <i class="ti-twitter-alt"></i>
                                 </div>
                             </div>
                             <div class="col-xs-7">
                                 <div class="numbers">
                                     <p>Total Transaksi</p>
                                     <span class="label label-info">6 Transaksi</span>
                                 </div>
                             </div>
                         </div>
                         <div class="footer">
                             <hr />
                             <div class="stats">
                                 <!-- <i class="ti-reload"></i> Updated now -->
                                 <a href="#">Detail</a>
                             </div>
                         </div>
                     </div>
                 </div>
             </div>
         </div>
         <div class="row">
         </div>
         <div class="row">
         </div>
     </div>
   </div>
 </div>
 <?php require '_footer.php'; ?>
