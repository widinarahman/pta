<?php
require 'config/config.php';
require '_header.php';

  if (empty($no_rekening=$_GET['id'])) {
    echo "<script>alert('tidak dapet')</script>";
  }else {
    $sql=mysqli_query($konek, "SELECT * FROM no_tabungan WHERE no_rekening='$no_rekening' ");
    $row=mysqli_fetch_array($sql);
    $no_rekening=$row['no_rekening'];
  }
  if (isset($_POST['submit'])) {
    $status=$_POST['status'];
    $no_rekening=$no_rekening;
    // echo "<script>alert('$no_rekening')</script>";
    $sql2="UPDATE no_tabungan SET status='$status' WHERE no_rekening='$no_rekening'";

    if (mysqli_query($konek, $sql2)) {
    // if (update_nasabah($status, $no_rekening)) {
      echo "<script>alert('Berhasil')</script>";
      echo "<script>window.location.href='tabungan_nasabah.php'</script>";
    }else {
      echo "<script>alert('Gagal')</script";
    }
  }

?>
<div class="container">
  <div class="content">
    <h4>Data Admin</h4>
    <ol class="breadcrumb">
      <li class="ti-panel">
        <a href="index.php">Dasboard</a>
      </li>
      <li>
        <a href="tabungan.php">Tabungan</a>
      </li>
      <li class="active">
        Input Nasabah Tabungan
      </li>
    </ol>

    <br>
    <div class="row">
      <div class="col-md-3">

      </div>
      <div class="col-md-7">
        <!-- <div class="alert alert-info" role="alert">
          <b>Info</b> Untuk menambah kelas silahkan masukan kode dan nama kelas, kode kelas dan nama kelas tidak boleh sama !
        </div> -->
        <form class="form-inline" action="" method="post">
          <div class="panel panel-default">
            <div class="panel-heading">Input Calon Nasbah </div>
            <div class="panel-body">



              <div class="form-group col-md-12">
                <div class="col-sm-3">
                  <label class="control-label" for="">No Rekening</label>
                </div>
                <div class="col-sm-6 margin">
                  <input  type="text" class="form-control" value='<?= $row['no_rekening']; ?>' name="nis" disabled>
                </div>
                <div class="col-sm-3">
                </div>
              </div>
              <div class="form-group col-md-12">
                <div class="col-sm-3">
                  <label class="control-label" for="">NIS</label>
                </div>
                <div class="col-sm-6 margin">
                  <input  type="text" class="form-control" value='<?= $row['nis']; ?>' placeholder="Nis Siswa" id="nis" name="nis" disabled>
                </div>
                <div class="col-sm-3">
                </div>
              </div>
              <div class="form-group col-md-12">
                <div class="col-sm-3">
                  <label class="control-label" for="">Saldo</label>
                </div>
                <div class="col-sm-6 margin">
                  <?php echo  rupiah($row['saldo']); ?>

                </div>
                <div class="col-sm-3">
                </div>
              </div>
              <div class="form-group col-md-12">
                <div class="col-sm-3">
                  <label class="control-label" for="">Status</label>
                </div>
                <div class="col-sm-6 margin">
                  <!-- <input  type="text" class="form-control" placeholder="Nis Siswa" id="nis" name="nis" required> -->
                  <select class="" name="status">
                    <option value="0">PILIH</option>
                    <option value="Tidak Aktif"> Tidak Aktif</option>
                    <option value="Aktif"> Aktif</option>
                  </select>
                </div>
                <div class="col-sm-3">
                </div>
              </div>


              <div class="form-group col-sm-12 margin_top">
                <div class="col-sm-5">
                </div>
                  <div class="col-sm-7  ">
                  <input class="btn btn-default" type="submit" name="submit" value="Simpan">
                  </div>
              </div>




            </div>
          </div>
        </form>
    </div>
  </div>
</div>

</div>

<?php require '_footer.php'; ?>
