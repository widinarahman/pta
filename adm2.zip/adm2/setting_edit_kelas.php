<?php
  require 'config/config.php';
  require '_header.php';
  if (empty($kd_kelas=$_GET['kode_kelas'])) {
    echo "<script>alert('Kosong')</script>";
  }else {
    $tampilkelaskd=tampilkelaskd($kd_kelas);
  }

  if (isset($_POST['submit'])) {
    $nm_kelas=$_POST['nm_kelas'];

    if(editkelas($nm_kelas,$kd_kelas)) {
      echo "<script>alert('Edit kelas berhasil tersimpan')</script>";
    }else {
      echo "<script>alert('Gagal')</script>";
    }
  }
 ?>
<div class="container">
  <div class="content">
    <h4>Data Kelas</h4>
    <ol class="breadcrumb">
      <li class="ti-panel">
        <a href="index.php">Dasboard</a>
      </li>
      <li>
        <a href="setting_kelas_data.php">Data Kelas</a>
      </li>
      <li class="active">
        Edit Kelas
      </li>
    </ol>

    <br>
    <style media="screen">
      .center{
        text-align: center;
      }
    </style>
    <div class="row">
      <div class="col-md-3">

      </div>
      <div class="col-md-6">
        <!-- <div class="alert alert-info" role="alert">
          <b>Info</b> Untuk menambah kelas silahkan masukan kode dan nama kelas, kode kelas dan nama kelas tidak boleh sama !
        </div> -->

          <form class="" action="" method="post">
            <?php
            while ($a=mysqli_fetch_assoc($tampilkelaskd)) {
            //   # code...
            // ?>
        <div class="panel panel-default">
          <div class="panel-heading">Edit Kelas Siswa </div>
          <div class="panel-body">
            <!-- <div class="form-group">
              <label class="col-sm-4 control-label" for="">Kode Kelas</label>
              <div class="col-sm-5">
                <input  type="text" class="form-control" placeholder="Kode Kelas" name="kd_kelas"  value="" required>
              </div>
            </div> -->

            <div class="form-group">
              <label class="col-sm-4 control-label" for="">Nama Kelas</label>
              <div class="col-sm-5 ">
                <input type="text" class="form-control" placeholder="Nama Kelas" name="nm_kelas"   value="<?= $a['nama_kelas'];?>" required>
              </div>
            </div>

            <div class="form-group">
              <div class="col-sm-4">
                <input class="btn btn-default" type="submit" name="submit" value="Simpan">
              </div>
            </div>

          </div>
        </div>
        <?php
      }
        ?>
          </form>
      </div>
    </div>
    </div>
  </div>
<?php require '_footer.php'; ?>
