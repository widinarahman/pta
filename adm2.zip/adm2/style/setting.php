<?php
ob_start();
	
	include_once ("../asset/komponen/procedural.php");
	@session_start();
	if (!isset($_SESSION['kode_user'])){ 
		header("location:../login/admin/");
	}else{
		if ($_SESSION['kode_user']=='pelanggan') {
			header("location:../login/admin/");
		}else{

?>
<?php	
	include ("../asset/komponen/database_connect.php");

	$tabelname="";$idname="";
	if($_SESSION['kode_user']=="admin"){$tabelname="admin";$idname="idadmin";}else{$tabelname="super_user";$idname="idsuperuser";}

	if(isset($_POST['btnsavebiodata'])){	
		$inalamat=strip_tags($_POST['inalamat']);
		$injk=strip_tags($_POST['injk']);
		$innama=strip_tags($_POST['innama']);
		$innoid=strip_tags($_POST['innoid']);
		$inttl=strip_tags($_POST['inttl']);
		$innotlp=strip_tags($_POST['innotlp']);
		$tempimg=strip_tags($_GET['tempimg']);
		$id=$_SESSION['id'];

		$reloadlink="setting.php?page=dashbord&info=suksesbio";
		$todir="../asset/img/admin/original/";
		$fromdir=$_FILES['inopenfile']['tmp_name'];
		$tumbnaillink="../asset/img/admin/tumbnail/";

		if ($_FILES['inopenfile']['tmp_name']==null) {
			$query_update="update $tabelname set nama='$innama',alamat='$inalamat',no_identitas='$innoid',ttl='$inttl',jenis_kelamin='$injk',no_tlp='$innotlp' where $idname=$id";
			mysqli_query($connect,$query_update) or die(mysqli_error($connect));
			@header("location:$reloadlink");
		}else{
			$namafile=md5($id.date("Y/m/d h:i:s")).basename($_FILES['inopenfile']['name']);
			$query_update="update $tabelname set nama='$innama',alamat='$inalamat',no_identitas='$innoid',ttl='$inttl',jenis_kelamin='$injk',no_tlp='$innotlp',foto='$namafile' where $idname=$id";
			unlink($todir.$tempimg);
			unlink($tumbnaillink.$tempimg);
			if (move_uploaded_file($fromdir, $todir.$namafile)) {			
				mysqli_query($connect,$query_update) or die(mysqli_error($connect));
				eoneImageResize($todir.$namafile,$tumbnaillink.$namafile,200,150);
				@header("location:$reloadlink");				
		    }else{

		    }
		}
	}
	else if(isset($_POST['btnsaveakun'])){	
		$inpassword=strip_tags($_POST['inpassword']);
		$id=$_SESSION['id'];
		$reloadlink="setting.php?page=dashbord&info=suksesakun";
		if ($inpassword!="") {
			$query_update="update $tabelname set password='$inpassword' where $idname=$id";
			mysqli_query($connect,$query_update) or die(mysqli_error($connect));
			@header("location:$reloadlink");
		}
	}

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="../asset/css/ridwan.min.css">
	<link rel="stylesheet" type="text/css" href="../asset/css/font.min.css">	
	<link rel="stylesheet" type="text/css" href="../asset/css/jquery-ui.css">
	<script type="text/javascript" src="../asset/js/jquery.min.js"> </script>
	<script type="text/javascript" src="../asset/js/jquery-ui.min.js"> </script>
	<script type="text/javascript" src="../asset/js/ridwan.min.js"></script>
</head>
<body>
	<?php include ("../asset/komponen/header.php"); ?>
	<div class="pembungkus bc-background" onclick="hideMenu();">
		<input type="checkbox" id="sidenav" style="display: none;">
		<div class="sidenav bc-background fkiri" id="sidenav">
			<div class="rid-dcol-1 shadow bg-putih" style=" height: 89.5vh;overflow-y: scroll;">				
				<div class="sidenav-head">
					<label class=" global-icon fkiri one-bell" style="font-size: 1.5em;padding: 25px 5px 5px 5px;"></label>
					<label class="fkiri global-iconlabel">NOTIFIKASI</label>
				</div>	
				<div class="bar-notifikasi" id="listnotif">

				</div>
				<div class="rid-dcol-1" id="loader2"></div>

				<div class="box-pembungkus" id="loadmorebtn">
					<a class="btn fkanan hover" onclick="loadNotif(_datalimit,'load');">
						<span class="one-flickr4 icon"></span><label class="btn-text">LIHAT LEBIH BANYAK</label>
					</a>
				</div>
			</div>			
		</div>

		<div class="centernav fkiri bc-background">
			<div class="box-pembungkus rid-dcol-1">
				<a class="fkiri">
					<span class="global-icon fkiri one-circle-right c-green"></span>
					<label class="fkiri global-iconlabel2 c-green" style="font-size: 1em">PENGATURAN AKUN</label>
				</a>				
				<a class="btn fkanan hover" onclick="viewElement('editViewBio','show');" onmouseup="viewElement('editView','hide');">
					<span class="one-pencil icon"></span><label class="btn-text">UBAH BIODATA</label>
				</a>
				<a class="btn fkanan hover" onclick="viewElement('editView','show');" onmouseup="viewElement('editViewBio','hide');">
					<span class="one-pencil icon"></span><label class="btn-text">UBAH KATA SANDI</label>
				</a>
				<a class="btn fkanan hover" href="list_member.php?page=dashbord">
					<span class="one-circle-left icon"></span><label class="btn-text">KEMBALI</label>
				</a>
			</div>


<?php 

	$id=$_SESSION['id'];$foto="";
	$query_viewmember=mysqli_query($connect,"select * from $tabelname where $idname=$id");
	$row_viewmember = mysqli_fetch_array($query_viewmember);
		$foto=$row_viewmember['foto'];
 ?>
 		<!--  ------------------------------------------------------INFO----------------------------------- -->
			<div class="box-pembungkus rid-dcol-1 box-style" >
				<div class="judul bc-gray3"><label class="fkiri global-iconlabel3 bc-graydark pad-l-20 pad-r-20 rad">DETAIL AKUN</label></div>
				<div class="list-jasa" style="font-family: 'Lato',sans-serif; ">
					<div class="rid-dcol-1" style="position: relative;">
						<div class="box-pembungkus rid-dcol-1">
							<span class='one-user fkiri icon c-green'></span>							
							<label class="text fkiri  pad-r-5"><?php echo ucwords($row_viewmember['nama']) ?></label> <label class="global-iconlabel4 subtext fkiri "><?php echo strtoupper($row_viewmember['email']) ?></label>
							<span class="harga-icon fkanan">
								<label class="text fkiri"><?php echo ucwords($row_viewmember['status']) ?></label>
								<label class="one-checkmark fkiri"></label>
							</span>
						</div>

						<div class="box-pembungkus rid-dcol-2b pad-10 fkiri">
							<div class="img-box oval-big rad-full" style="background-image: url('../asset/img/admin/tumbnail/<?php echo $foto ?>');"></div>
						</div>
						<div class="box-pembungkus rid-dcol-1b fkiri" style="padding: 5px 0 5px 10px;">
							<div class="rid-dcol-1">
								<div class="viewsubtext rid-mcol-2b fkiri">Tempat Tanggal Lahir</div><div class="global-iconlabel4 viewtext rid-mcol-1b fkiri "><?php echo ucwords($row_viewmember['ttl']) ?></div>
							</div>
							<div class="rid-dcol-1">
								<div class="viewsubtext rid-mcol-2b fkiri">Jenis Kelamin</div><div class="global-iconlabel4 viewtext rid-mcol-1b fkiri "><?php echo oneJk(ucwords($row_viewmember['jenis_kelamin'])) ?></div>
							</div>
							<div class="rid-dcol-1">
								<div class="viewsubtext rid-mcol-2b fkiri">Nomor Identitas KTP/SIM</div><div class="global-iconlabel4 viewtext rid-mcol-1b fkiri "><?php echo ucwords($row_viewmember['no_identitas']) ?></div>
							</div>
							<div class="rid-dcol-1">
								<div class="viewsubtext rid-mcol-2b fkiri">Alamat</div><div class="global-iconlabel4 viewtext rid-mcol-1b fkiri "><?php echo ucwords($row_viewmember['alamat']) ?></div>
							</div>
							<div class="rid-dcol-1">
								<div class="viewsubtext rid-mcol-2b fkiri">Nomor Telephon</div><div class="global-iconlabel4 viewtext rid-mcol-1b fkiri "><?php echo $row_viewmember["no_tlp"] ?></div>
							</div>

						</div>
					</div>
				</div>
			</div>



		<!-- ---------------------------------------- INPUT INFO -------------------------------------------- -->
			<div class="box-pembungkus box-style" style="display: none;" id="editView">
				<div class="judul bc-gray3"><label class="fkiri global-iconlabel3 bc-graydark pad-l-20 rad pad-r-20">UBAH KATA SANDI AKUN</label></div>
				<div class="box-pembungkus rid-dcol-2b fkiri pad-r-10">	
					<div class="input-label pad-10"><span class="icon one-circle-right"> </span> Gunakanlah kata sandi dengan kombinasi angka, huruf dan spesial karakter agar keamanan akun tetap terjaga.
					</div>
				</div>

				<div class="box-pembungkus rid-dcol-1b fkiri">
					<form method="POST" action="" enctype="multipart/form-data">

						<div class="pembungkus">
							<label class="input-label">Email Anda</label>
							<div class="input"><input class="input-ok" rows="5" name="inemail" id="inemail" disabled="1" readonly="1" oninput ="oneCheckData('inemail',2,1000,'email')" value="<?php echo $row_viewmember['email'] ?>"></input></div>
						</div>

						<div class="pembungkus">
							<label class="input-label">Ganti Kata Sandi</label>
							<div class="input"><input type="password"  placeholder="Masukan kata Sandi" name="inpassword" id="inpassword" oninput ="oneCheckData('inpassword',2,30,'password')"></input></div>
						</div>
						<div class="pembungkus">
							<label class="input-label">Ketik Ulang Kata Sandi</label>
							<div class="input"><input type="password" placeholder="Ketik Ulang kata Sandi" name="inpasswordre" id="inpasswordre" oninput ="oneCheckPassword('inpasswordre','inpassword')"></input></div>
						</div>
						
						<div class="box-pembungkus rid-dcol-1">
							<button type="submit" class="btn fkanan hover" name="btnsaveakun" id="btnsaveakun">
								<span class="one-save icon"></span> UBAH
							</button>
						</div>
					</form>						
				</div>
			</div>	

		<!-- -------------------------------------------- INPUT INFO ---------------------------------- -->
			<div class="box-pembungkus box-style" style="display: none;" id="editViewBio">
				<div class="judul bc-gray3"><label class="fkiri global-iconlabel3 bc-graydark pad-l-20 rad pad-r-20">UBAH INFORMASI BIODATA</label></div>
				<div class="box-pembungkus rid-dcol-2b fkiri pad-r-10">	
					<div class="input-label pad-10"><span class="icon one-circle-right"> </span> Isilah dengan menggunakan data yang benar dan gunakanlah kata-kata yang baik dan benar serta sesuai dengan EYD.
					</div>
				</div>

				<div class="box-pembungkus rid-dcol-1b fkiri">
					<form method="POST" action="" enctype="multipart/form-data">
						<div class="pembungkus">
							<label class="input-label">Nama Anda</label>
							<div class="input"><input class="input-ok" placeholder="Masukan nama anda" name="innama" id="innama" oninput ="oneCheckData('innama',2,30,'nama')" value="<?php echo $row_viewmember['nama'] ?>"></input></div>
						</div>

						<label class="input-label">Pilih Jenis Kelamin</label>
						<div class="pembungkus" onmouseleave="comboLeave('combobox');">
							<div class="input"><label class="one-circle-down iconlist cur-poin" for="injk"></label>
								<input class="input-ok" placeholder="Pilih Jenis Kelamin" class="select cur-poin" name="injk" id="injk" readonly="1" onclick ="comboBox('injk',this.value,'combobox');" value="<?php echo oneJk($row_viewmember['jenis_kelamin']) ?>"></input>	
							</div>																				
							<ul id="combobox" class="bc-gray3" onclick="oneCheckData('injk',1,20,'kosong');">
								<li class="bc-graydark" onclick="comboBox('injk','LAKI_LAKI','combobox')">LAKI-LAKI</li>
								<li class="bc-graydark" onclick="comboBox('injk','PEREMPUAN','combobox')">PEREMPUAN</li>
							</ul>
						</div>
						<div class="pembungkus">
							<label class="input-label">Tempat Tanggal Lahir, (Contoh: Jogja, 05 mei 1995)</label>
							<div class="input"><input class="input-ok" required="" placeholder="Jogja, 05 mei 1995" name="inttl" id="inttl" oninput ="oneCheckData('inttl',2,30,'ttl')" value="<?php echo $row_viewmember['ttl'] ?>"></input></div>
						</div>
						<div class="pembungkus">
							<label class="input-label">Alamat</label>
							<div class="input"><textarea class="input-ok" placeholder="Masukan Alamat Fotografer" rows="5" name="inalamat" id="inalamat" oninput ="oneCheckData('inalamat','btnsave',200,3,'deskripsi')"><?php echo $row_viewmember['alamat'] ?></textarea></div>
						</div>

						<div class="pembungkus">
							<label class="input-label">Nomor Identitas KTP/SIM</label>
							<div class="input"><input class="input-ok" placeholder="Harus berupa angka" name="innoid" id="innoid" oninput ="oneCheckData('innoid',6,30,'angka')" value="<?php echo $row_viewmember['no_identitas'] ?>"></input></div>
						</div>
						<div class="pembungkus">
							<label class="input-label">Nomor Telephon /HP</label>
							<div class="input"><input class="input-ok" placeholder="Harus berupa angka"  name="innotlp" id="innotlp" oninput ="oneCheckData('innotlp',6,14,'angka')" value="<?php echo $row_viewmember['no_tlp'] ?>"></input></div>
						</div>

						<label class="input-label">Masukan Foto </label>	
						<div class="pembungkus">						
							<label class="btn fkiri hover" for="inopenfile"><span class="one-image icon"></span></label>
							<div class="input fkiri unnormal"><input type="file" accept=".jpg, .gif,.jpeg,.png" name="inopenfile" id="inopenfile" onchange="openFile(infiletext,inopenfile,event);oneCheckData('infiletext',6,1000,'kosong')" style="display: none;"><input class="input-ok" readonly="true" type="text" name="infiletext" id="infiletext" value="<?php echo $row_viewmember['foto'] ?>"> </div>
						</div>
						<div class="box-pembungkus rid-dcol-1">
							<button type="submit" class="btn fkanan hover" name="btnsavebiodata" id="btnsavebiodata"><span class="one-save icon"></span> UBAH
							</button>
						</div>
					</form>						
				</div>
			</div>	
			
		</div>
	</div>
</body>
</html>
<script type="text/javascript">
	var _datalimit=0;
	loadNotif(_datalimit,'get');
	function loadNotif(datapos,request){
		 _link="../notif/load_notif.php?datapos="+datapos;
		 loadData(_link,'listnotif',request,'loader2');
		 _datalimit +=5;
	}
	$one('inpassword').setCustomValidity("Maaf Password Tidak Boleh Kosong ");
	$one('inpasswordre').setCustomValidity("Maaf Tidak Boleh Kosong ");
</script>
<?php }} ob_end_flush();?>

