<?php

  require 'config/config.php';
  require '_header.php';


  if (isset($_POST['submit'])) {
    $user_name=$_POST['user_name'];
    $password=$_POST['password'];

    // $password=md5($password);
    $confirpassword=$_POST['confirpassword'];

    $nama_admin=$_POST['nama_admin'];
    $alamat=$_POST['alamat'];

    $tpl1=$_POST['tlp1'];
    $tpl2=$_POST['tlp2'];

    $no_telepon=$tpl1.$tpl2;

    $status=$_POST['status'];

    if (!preg_match("/^[a-z]*$/",$user_name)) {
      echo "<script>alert('Maaf, username hanya di perbolehkan menggunakan huruf !')</script>";
      }
    elseif (strlen($user_name) <4) {
        echo "<script>alert('Maaf, Username terlalu pendek minimal  4 karakter')</script>";
    }
    elseif (strlen($nama_admin) <4) {
        echo "<script>alert('Maaf, nama terlalu pendek minimal  4 karakter')</script>";
    }
    elseif (!preg_match("/^[a-zA-Z ]*$/",$nama_admin)) {
      echo "<script>alert('Maaf, username hanya di perbolehkan menggunakan huruf dan spasi !')</script>";
      }
    elseif ($password==$confirpassword) {
      $password=sha1($password);

      if(simpanadmin($user_name, $password, $nama_admin, $alamat, $no_telepon, $status)) {
        echo "<script>alert('tersimpan')</script>";
      }else {
        echo "Error: " . $query . "<br>" . mysqli_error($konek);
      }
    }else {
      echo "<script>alert('Confir Passord tidak sama ! ')</script>";

    }
  }
 ?>


<div class="container">
  <div class="content">
    <h4>Data Admin</h4>
    <ol class="breadcrumb">
      <li class="ti-panel">
        <a href="index.php">Dasboard</a>
      </li>
      <li>
        <a href="setting_admin.php">Data Admin</a>
      </li>
      <li class="active">
        Input Data Admin
      </li>
    </ol>

    <br>
    <div class="row">
      <div class="col-md-3">

      </div>
      <div class="col-md-7">
        <!-- <div class="alert alert-info" role="alert">
          <b>Info</b> Untuk menambah kelas silahkan masukan kode dan nama kelas, kode kelas dan nama kelas tidak boleh sama !
        </div> -->
        <form class="form-inline" action="" method="post" id="form1">
          <div class="panel panel-default">
            <div class="panel-heading">Input Admin </div>
              <div class="panel-body">
                <!-- Username -->
                <!--  -->
                <p>
                <div class="form-group col-md-12">
                  <div class="col-sm-3">
                    <label class="control-label" for="">Username</label>
                  </div>
                  <div class="col-sm-5 margin">
                    <input onkeydown="Check(event);" onkeyup="Check(event)" type="text" class="form-control required" minlength="2" id="username"  placeholder="Username" name="user_name" value="" required>
                  </div>
                  <div class="col-sm-3">
                  </div>
                </div>
                </p>
                <!-- Password -->
                <div class="form-group col-md-12">
                  <div class="col-sm-3">
                    <label class="control-label" for="">Password</label>
                  </div>
                  <div class="col-sm-5 margin">
                    <input type="password" class="form-control" placeholder="Password" id="password" name="password"   value="" required>
                  </div>
                  <div class="checkbox col-sm-3">
                    <label><input type="checkbox" onclick="show()"></label>
                    <!-- <button onclick="show()">Show password</button> -->
                  </div>
                </div><br>
                <div class="form-group col-md-12">
                  <div class="col-sm-3">
                    <label class="control-label" for="">Confir Password</label>
                  </div>
                  <div class="col-sm-5 margin">
                    <input type="password" class="form-control" placeholder="Password" id="password" name="confirpassword"   value="" required>
                  </div>
                  <div class="checkbox col-sm-3">
                    <!-- <label><input type="checkbox" onclick="show()"></label> -->
                    <!-- <button onclick="show()">Show password</button> -->
                  </div>
                </div><br>

                <!--  Nama -->

                <div class="form-group col-md-12">

                  <input type="hidden" name="" value="">

                  <div class="col-sm-3">
                    <label class="control-label" for="">Nama</label>
                  </div>
                  <div class="col-sm-5 margin">
                    <input type="text" class="form-control" placeholder="Nama Lengkap" name="nama_admin"   value="" required>
                  </div>
                  <div class="col-sm-3 margin">
                  </div>
                </div>

                <!-- No telepon -->
                <div class="form-group col-md-12">
                  <div class="col-sm-3">
                    <label class="control-label" for="nama">No Telephon</label>
                  </div>
                  <div class="col-sm-6 margin">
                    <input onkeypress="return hanyaAngka(event)" style="width:60px;" id="nama" type="text" class="form-control require" placeholder="+62"  name="tlp1"  value="+62" readonly="readonly">
                    <input onkeypress="return hanyaAngka(event)"  maxlength="11" style="width:130px;" id="nama" type="text" class="form-control require" placeholder="Nomor Telepon"  name="tlp2"  value="" required>
                  </div>
                  <div class="col-sm-3">
                  </div>
                </div>
                <!--  Status-->
                <div class="form-group  col-md-12">
                  <div class="col-sm-3">
                    <label class="control-label" for="">Status</label>
                  </div>
                  <div class="col-sm-3 margin">
                    <select  name="status" class="form-control" required>
                      <option> PILIH</option>
                      <option value="Admin">Admin</option>
                      <option value="staf_tu">Staf TU</option>
                      <option value="staf_tb">Staf TB</option>
                  </select>
                  </div>
                  <div class="col-sm-3">
                  </div>
                </div>
                <!-- Alamat-->
                <div class="form-group col-md-12">
                  <div class="col-sm-3">
                    <label class="control-label" for="">Alamat</label>
                  </div>
                  <div class="col-sm-5 margin">
                    <textarea class="form-control" name="alamat" rows="2" cols="20" required></textarea>
                    <!-- <input type="text" class="form-control" placeholder="Alamat" name="alamat"   value="" required> -->
                  </div>
                </div>
                <!--  Simpan-->
                <div class="form-group  col-md-12">
                  <div class="col-sm-4">
                  </div>
                  <div class="col-sm-2">
                    <input class="btn btn-default" type="submit" name="submit" value="Simpan">

                  </div>
                  <div class="col-sm-2">
                    <input class="btn btn-default" type="submit" name="cancel" value="Cancel">

                  </div>
                </div>
                <!-- End -->
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
</div>
<script type="text/javascript">
  function show() {
    var password = document.getElementById('password'),
        button = document.getElementsByTagName('button')[0];

    if (button.textContent === 'Show Password') {
        password.setAttribute('type', 'type');
        button.textContent='Hide Password';
    }else {
      password.setAttribute('type', 'type');
      button.textContent='Show Password';

    }
    return false;
  }
  function Checke() {
      var keyCode = (e.keyCode ? e.keyCode : e.which)
      if (keyCode > 47 && ketCode < 58) {
        e.preventDefault();
      }
  }
  function hanyaAngka(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode
     if (charCode > 31 && (charCode < 48 || charCode > 57))

      return false;
    return true;
  }

</script>
<?php require '_footer.php'; ?>
