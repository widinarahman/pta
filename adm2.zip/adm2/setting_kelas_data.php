<?php
  require 'config/config.php';
  require '_header.php';


  $result=tampilkelas();
 ?>
<div class="container">
  <div class="content">
    <h4>Data Kelas</h4>
    <ol class="breadcrumb">
      <li class="ti-panel">
        <a href="?">Dasboard</a>
      </li>
      <li class="active">
        Data Kelas
      </li>
    </ol>
    <div class="row">
      <div class="col-lg-5">
        <button class="btn btn-default" type="button" name="" value="Tambah" onclick="window.location.href='setting_input_kelas.php'">Tambah</button>
      </div>
    </div>
    <br>
    <style media="screen">
      .center{
        text-align: center;
      }
    </style>
    <div class="table-responsive">
      <table id="data" class="table table-striped table-bordered data">
        <thead>
          <tr>
            <th width="20%">Kode Kelas</th>
            <th width="60%">Nama Kelas</th>
            <th class="center" width="10%">Setting</th>
          </tr>
        </thead>
        <tbody>
        <?php while ($a=mysqli_fetch_assoc($result)) {

            ?>
              <tr>
                <td><?php echo $a['kode_kelas']; ?></td>
                <td><?php echo $a['nama_kelas']; ?></td>
                <td class="center">
                  <a class="glyphicon glyphicon-edit" href="setting_edit_kelas.php?kode_kelas=<?= $a['kode_kelas'];?>"></a>
                  <a class="glyphicon glyphicon-trash"href="setting_edit_kelas.php?kode_kelas=<?= $a['kode_kelas'];?>"></a>
                  <!-- <a class="glyphicon glyphicon-eye-open" href="#"></a> -->
                </td>

              </tr>
            <?php
          }
          ?>
        </tbody>
      </table>
    </div>
  </div>
  </div>
<?php require '_footer.php'; ?>
