<?php

  require 'config/config.php';
  require '_header.php';

  if (isset($_POST['submit'])) {
    $kd_pembayaran=$_POST['kd_pembayaran'];
    $nm_pembayaran=$_POST['nm_pembayaran'];
    $ms_pembayaran=$_POST['ms_pembayaran'];
    $sld_pembayaran=$_POST['sld_pembayaran'];

    $cekall=mysqli_fetch_row(mysqli_query($konek, "SELECT * FROM pembayaran WHERE kode_pembayaran='$kd_pembayaran' AND nama_pembayaran='$nm_pembayaran'"));
    $cekkd=mysqli_fetch_row(mysqli_query($konek, "SELECT * FROM pembayaran WHERE kode_pembayaran='$kd_pembayaran'"));
    $ceknm=mysqli_fetch_row(mysqli_query($konek, "SELECT * FROM pembayaran WHERE nama_pembayaran='$nm_pembayaran'"));

    $x=strlen($kd_pembayaran);
    $y=strlen($nm_pembayaran);


    if (preg_match('/[^a-zA-Z_\-0-9]/i',$kd_pembayaran)) {
      echo "<script>alert('Maaf, kode pembayaran hanya boleh angka, huruf dan tanda  - _ </script>";
    }
    elseif ($x < 3 ) {
      echo "<script>alert('Kode pembayaran terlalu pendek, kode pemabayaran minimal 3 karakter !')</script>";
    }
    elseif ($y < 4 ) {
      echo "<script>alert('Nama pembayaran terlalu pendek, nama pembayaran minimal 4 karakter  !')</script>";
    }
    // elseif ($cekall > 0) {
    //   echo "<script>alert('Kode dan nama pembayaran sudah ada !')</script>";
    // }
    // elseif (!preg_match('/[^a-zA-Z_\-0-9]/i',$nm_pembayaran)) {
    //   echo "<script>alert('DFD  !')</script>";
    // }
    elseif ($cekkd > 0) {
      echo "<script>alert('Kode pembayaran $kd_pembayaran sudah ada, silahkan masukan kode yang lain !')</script>";
    }
    // elseif ($ceknm > 0) {
    //   echo "<script>alert('Nama pembayaran sudah ada !')</script>";
    // }
    elseif (!preg_match('/^[0-9]*$/',$sld_pembayaran)) {
      echo "<script>alert('Saldo pembayaran harus menggunakan angka !')</script>";
    }
    elseif (inputpembayaran($kd_pembayaran, $nm_pembayaran, $ms_pembayaran, $sld_pembayaran)) {
      echo "<script>alert('Berhasil')</script>";
    }else {
      echo "Error: " . $query . "<br>" . mysqli_error($konek);
    }
  }
   ?>
<div class="container">
  <div class="content">
    <h4>Data Pembayaran</h4>
    <ol class="breadcrumb">
      <li class="ti-panel">
        <a href="index.php">Dasboard</a>
      </li>
      <li>
        <a href="setting_pembayaran.php">Data Pembayaran</a>
      </li>
      <li class="active">
        Input Pembayaran
      </li>
    </ol>

    <br>
    <div class="row">
      <div class="col-md-3">

      </div>
      <div class="col-md-7">
        <!-- <div class="alert alert-info" role="alert">
          <b>Info</b> Untuk menambah kelas silahkan masukan kode dan nama kelas, kode kelas dan nama kelas tidak boleh sama !
        </div> -->
        <form class="" action="" method="post" enctype="multipart/form-data">
        <div class="panel panel-default">
          <div class="panel-heading">Input Pembayaran </div>
          <div class="panel-body">

            <div class="form-group col-md-12">
              <div class="col-sm-4">
                <label class="control-label" for="">Kode Pembayaran</label>
              </div>
              <div class="col-sm-5">
                <input style="width:90px" type="text" class="form-control" placeholder="kode Pembayaran" name="kd_pembayaran"  value="" required>
              </div>
            </div>
            <!--  -->
            <div class="form-group col-md-12">
              <div class="col-sm-4">
                <label class="control-label" for="">Nama Pembayaran</label>
              </div>
              <div class="col-sm-5 ">
                <input type="text" class="form-control" placeholder="Nama Pembayaran" name="nm_pembayaran"   value="" required>
              </div>
            </div>

            <div class="form-group col-md-12">
              <div class="col-sm-4">
                <label class="control-label" for="">Masa Pembayaran</label>
              </div>
              <div class="col-sm-5 ">
                <select  name="ms_pembayaran" class="form-control" required>
                  <option> PILIH</option>
                  <option value="Perbulan">Perbulan</option>
                  <option value="Persemester">Persemester</option>
                  <option value="Pertahun">Pertahun</option>
                  <option value="Tahun Pertama">Tahun Pertama</option>
                </select>
              </div>
            </div><br>
            <div class="form-group col-md-12">
              <div class="col-sm-4">
                <label class="control-label" for="">Saldo Awal</label>
              </div>
              <div class="col-sm-5 ">
                <input onkeypress="return hanyaAngka(event)" type="text" class="form-control" placeholder="Saldo Awal" name="sld_pembayaran"   value="0" required>
                <span>Nominal</span>
              </div>
            </div>
            <br>
            <div class="form-group">
              <div class="col-sm-4">
                <input class="btn btn-default" type="submit" name="submit" value="Simpan">
              </div>
            </div>

          </div>
        </div>
          </form>
      </div>
    </div>
    </div>
  </div>
  <script type="text/javascript">
  function hanyaAngka(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode
     if (charCode > 31 && (charCode < 48 || charCode > 57))

      return false;
    return true;
  }
  </script>

<?php require '_footer.php'; ?>
