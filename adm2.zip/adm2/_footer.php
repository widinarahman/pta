    <footer class="footer">
        <div class="container-fluid">

            <div class="copyright pull-right  center">
                &copy; <script>document.write(new Date().getFullYear())</script>, Administrasi Keuangan V 1.0 <i class="fa fa-heart heart"></i> Tugas Akhir
            </div>
        </div>
    </footer>
  </div>
  <!-- End Panel-->
</div>
<!-- wrapper -->
          <script src="assets/js/bootstrap.min.js"></script>
        <!-- <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/jQuery.js"></script>
        <script type="text/javascript" src="assets/DataTables/media/js/jquery.js"></script>
        <script type="text/javascript" src="assets/DataTables/media/js/jquery.dataTables.js"></script>
        <script src="assets/js/bootstrap-datepicker.js"></script> -->

        <script type="text/javascript">


          $('.date').datepicker({
            format: 'yyyy-mm-dd',
          })

              $(document).ready( function () {
        			$('#data').DataTable({
        				responsive:true
        			   });
    			    } );
    //===================================================//
    function hanyaAngka(evt) {
      var charCode = (evt.which) ? evt.which : event.keyCode
       if (charCode > 31 && (charCode < 48 || charCode > 57))

        return false;
      return true;
    }
    function isi_otomatis_rk(){
        var no_rekening = $("#no_rekening").val();
        $.ajax({
            url: 'proses_setor_tb.php',
            data:"no_rekening="+no_rekening ,
        }).success(function (data) {
            var json = data,
            obj = JSON.parse(json);
            $('#nis').val(obj.nis);
            $('#saldo').val(obj.saldo);
            // $('#alamat').val(obj.alamat);
        });
      }

    </script>
  </body>
</html>
