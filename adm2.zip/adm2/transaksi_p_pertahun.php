 <?php
require 'config/config.php';
require '_header.php';
//tampilpembayaran_pertahun
$pembayaran=tampilpembayaran_pertahun();
$thn_aktif=thn_ajar_aktif();
$thn_aktif2=thn_ajar_aktif();

if (isset($_POST['submit'])) {

  $kode_pembayaran=$_POST['kode_pembayaran'];
  $id_admin=$_SESSION['id_admin'];

    while($a=mysqli_fetch_assoc($thn_aktif)){
      $aktif=$a['kode_tahun_ajaran'];
      $kode_tahun_ajaran=$aktif;
    }

  $tanggal_transaksi=date('Y/m/d');
  $jenis_transaksi='Pemasukan';
  $jumlah=$_POST['jumlah'];
  $keterangan=null;

  $kekurangan=$_POST['kekurangan'];


    // Detail
    $nis=$_POST['nis'];


    // Terdaftar belum
  $nis=mysqli_fetch_row(mysqli_query($konek, "SELECT * FROM siswa WHERE nis='$nis'"));

  if ($nis < 1) {
      echo "<script>alert('NIS yang di masukan tidak valid !')</script>";
    }
  elseif ($jumlah > $kekurangan) {

    echo "<script>alert('Jumlah yang dimasukan lebih kekurangan, kekurangan anda $kekurangan')</script>";
  }
  elseif (simpan_transaksi($kode_pembayaran, $id_admin, $kode_tahun_ajaran, $tanggal_transaksi, $jenis_transaksi, $jumlah, $keterangan)) {

      echo "<script>alert('Berhasil melakaukan pembayaran ')</script>";

      $sql=mysqli_query($konek, "SELECT kode_transaksi FROM transaksi ORDER BY kode_transaksi DESC LIMIT 1");
      $row=mysqli_fetch_array($sql);
      $id_terakhir=$row['kode_transaksi'];

      //echo "<script>alert($id_terakhir)</script>";

      $nis=$_POST['nis'];
      $kode_transaksi=$id_terakhir;

    if (simpan_detail_pembayaran($nis, $kode_transaksi)) {
      //echo "<script>alert('berhasil detail pembayaran')</script>";
    }else {
        echo "Error: " . $query . "<br>" . mysqli_error($konek);
    }

  }else {
    echo "Error: " . $query . "<br>" . mysqli_error($konek);
  }
}

 ?>


<div class="container">
  <div class="content">
    <h4>Penarikan Tabungan</h4>
    <ol class="breadcrumb">
      <li class="ti-panel">
        <a href="index.php">Dasboard</a>
      </li>
      <li>
        <a href="transaksi_pemasukan.php">Transaksi Pemasukan</a>
      </li>
      <li class="active">
        Pembayaran Awal Tahun
      </li>
    </ol>

    <br>
    <div class="row">
      <div class="col-md-2">

      </div>
      <div class="col-md-8">
        <form class="form-inline" action="" method="post">
          <div class="panel panel-default">
            <div class="panel-heading">
              <div class="form-group col-sm-12">
                <div class="col-sm-3">
                  <label class="control-label" for="">Nama Pembayaran</label>
                </div>
                <div class="col-sm-4 margin">
                  <!-- Pake input -->
                  <!-- <input type="text" name="kode_pembayaran" onkeyup="isi_otomatis()" id="kode_pembayaran" > -->
                  <!-- Pake Select-->
                  <select class="form-control" name="kode_pembayaran" id="kode_pembayaran" required>
                    <option value=""> PILIH </option>
                    <?php
                      while($data=mysqli_fetch_assoc($pembayaran)){
                    ?>
                      <option value="<?php echo $data['kode_pembayaran'];?>" onclick="isi_otomatis()"> <?php echo $data['nama_pembayaran'];?> </option>

                      <?php
                     }
                    ?>
                  </select>
                </div>
                <div class="col-sm-5">
                  <label for="">Tahun Ajaran : </label>
                  <?php
                    while($a=mysqli_fetch_assoc($thn_aktif2)){
                      $aktif=$a['tahun_ajaran'];
                      echo "$aktif";
                  ?>
                    <input type="hidden" name="kode_tahun_ajaran" value="<?php echo $a['kode_tahun_ajaran']; ?>" onkeyup="isi_otomatis()" onkeyup="sum_transaksi_siswa()" id="kode_tahun_ajaran" disabled>
                    <?php

                     ?>
                  <?php } ?>

                     <!-- <input type="text" name="kode_tahun_ajaran" id="kode_tahun_ajaran" value="" onkeyup="isi_otomatis()"> -->
                     <!-- <input type="text" name="kode_tahun_ajaran" value="" onkeyup="isi_otomatis()" id="kode_tahun_ajaran"> -->
                </div>
              </div>
              <div class="form-group col-sm-12">
                <div class="col-sm-3">
                  <label class="control-label" for="">Rp</label>
                </div>
                <div class="col-sm-4 margin">
                  <input type="text" class="form-control" id="jumlah_pembayaran" name="jumlah_pembayaran" value="" readonly="readonly">
                </div>
              </div>
              <p class="date"> Tanggal : <?php echo date('Y/m/d'); ?></p>
            </div>

            <div class="panel-body">
              <div class="form-group col-sm-12">

              </div>
              <div class="form-group col-sm-12">
                <div class="col-sm-3">
                  <label class="control-label" for="">NIS</label>
                </div>
                <div class="col-sm-6 margin">
                  <input style="width:90px"  type="text"  class="form-control"  placeholder="" name="nis" onkeyup="isi_otomatis2();" onkeypress="return hanyaAngka(event)" id="nis" required>
                </div>
                <div class="col-sm-3">
                </div>
              </div>
              <div class="form-group col-sm-12">
                <div class="col-sm-3">
                  <label class="control-label" for="">Nama Siswa</label>
                </div>
                <div class="col-sm-5 margin">
                  <input  type="text" class="form-control" placeholder="Nama Siswa" id="nama_siswa" name="nama_siswa" disabled>
                </div>
                <div class="col-sm-4">
                  <!-- <label for="">Kelas</label> -->
                  <input  type="text" class="form-control" style="width:100px;" placeholder="Kelas" name="nama_kelas" id="nama_kelas"  value=""  disabled>
                </div>
              </div>

              <div class="form-group col-sm-12">
                <div class="col-sm-3">
                  <label class="control-label" for="">Kekurangan</label>
                </div>
                <div class="col-sm-6 margin">
                  <input  id="kekurangan" type="text" class="form-control" placeholder="" name="kekurangan"   value=""  readonly="readonly">
                </div>
                <div class="col-sm-3">
                </div>
              </div>

              <div class="form-group col-sm-12">
                <div class="col-sm-3">
                  <label class="control-label" for="">Sudah di bayar</label>
                </div>
                <div class="col-sm-6 margin">
                  <!-- <samp id="jumlah_sdh"></samp> -->
                  <input  type="text" class="form-control" placeholder="" name= "" id="jumlah_sdh"  value=""  readonly="readonly">
                </div>
                <div class="col-sm-3">
                </div>
              </div>
              <div class="form-group col-sm-12">
                <div class="col-sm-3">
                  <label class="control-label" for="">Jumlah</label>
                </div>
                <div class="col-sm-6 margin">
                  <input  type="text" class="form-control" placeholder="" name="jumlah" onkeypress="return hanyaAngka(event)" value="" required >
                </div>
                <div class="col-sm-3">
                  <input type="hidden" name="keterangan" value="">
                </div>
              </div>
              <div class="form-group col-sm-12 margin_top">
                <div class="col-sm-5">
                </div>
                  <div class="col-sm-7  ">
                  <input class="btn btn-default" type="submit" name="submit" value="Simpan">
                  <input class="btn btn-default" type="submit" name="submit" value="Cancel">
                  </div>
              </div>
              <br>
            </div>
            <div class="panel-footer col-xs-12">

            </div>

          </div>

        </form>
    </div>
  </div>
  <div class="row">
    <div class="table-responsive">
      <table id="data2" class="table table-striped table-bordered data font">
        <thead class="font">
          <tr>
            <th width="15%">Tanggal Transaksi</th>
            <th width="15%">Kode Transaksi </th>
            <th width="10%">NIS</th>
            <th width="15%">Nama Siswa</th>
            <th width="15%">Pembayaran</th>
            <th width="10%">Tahun Ajaran</th>
            <th width="10%">Jumlah</th>
          </tr>
        </thead>
        <tbody id="datax">
          <tr>
            <td></td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</div>

</div>

<script src="assets/js/jquery-2.1.4.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script type="text/javascript">

		function hanyaAngka(evt) {
		  var charCode = (evt.which) ? evt.which : event.keyCode
		   if (charCode > 31 && (charCode < 48 || charCode > 57))

		    return false;
		  return true;
		}

function isi_otomatis(){
    var kode_pembayaran = $("#kode_pembayaran").val();
    var kode_tahun_ajaran = $("#kode_tahun_ajaran").val();
    $.ajax({
        url: 'proses_jml_pembayaran.php',
        data:{
          kode_pembayaran:kode_pembayaran,
          kode_tahun_ajaran:kode_tahun_ajaran
        }
        // data:"kode_pembayaran="+kode_pembayaran ,
        // data:"kode_tahun_ajaran="+kode_tahun_ajaran ,
    }).success(function (data) {
        var json = data,
        obj = JSON.parse(json);
        $('#jumlah_pembayaran').val(obj.jumlah_pembayaran);
        $('#kekurangan').val(obj.jumlah_pembayaran);
        // $('#nama_kelas').val(obj.nama_kelas);
        //  $('#alamat').val(obj.alamat);


    });
  }

  function isi_otomatis2(){
    // menampilkan nama siswa dan kelas siswa berdasarkan NIS
      var nis = $("#nis").val();
      var kode_pembayaran = $("#kode_pembayaran").val();
      var tahun_ajaran = '<?php echo $aktif?>';

      $.ajax({
          url: 'proses-ajax.php',
          data:{
            mode:'detail_mhs', nis:nis,kode_pembayaran:kode_pembayaran,tahun_ajaran:tahun_ajaran}
          // data:"nis="+nis ,
      }).success(function (data) {
          var json = data,
          obj = JSON.parse(json);
          $('#nama_siswa').val(obj.nama_siswa);
          $('#nama_kelas').val(obj.nama_kelas);
          if (obj.kode_semester == 1) {
          }

      });

      get_table(nis , kode_pembayaran, )
    }
    // Tambah tahun ajaran
  function sum_bayar(nis, kode_pembayaran) {
    $.ajax({
        url: 'proses-ajax.php',
        data:{
          mode:'detail_mhs', nis:nis,kode_pembayaran:kode_pembayaran,tahun_ajaran:tahun_ajaran}
        }).success(function (data) {
            var json = data,
            obj = JSON.parse(json);
            $('#jumlah').val(obj.jumlah);
        });
  }
  function get_table(nis , kode_pembayaran){
          $.ajax({
          url: 'proses-ajax.php',
          data:{mode:'get_table', nis:nis,kode_pembayaran:kode_pembayaran}
      }).success(function (data) {
          // console.log(data);
          // return false;
          var json = data,
          obj = JSON.parse(json);
          var tabeldata = document.getElementById('data2').getElementsByTagName('tbody')[0];
          var j = 0;
          var total=0,x=0;
          document.getElementById('datax').innerHTML= "";
          var blm_bayar=$("#jumlah_pembayaran").val();
          // var blm_bayar=0;

          var jml_pembayaran = $("#jumlah_pembayaran").val();
          // var kek = $("#kekurangan").val();


          for (var i = obj.length - 1; i >= 0; i--) {
           row = tabeldata.insertRow(tabeldata.rows.length);
           row.value = i;
           cell1 = row.insertCell(0);
           cell2 = row.insertCell(1);
           cell3 = row.insertCell(2);
           cell4 = row.insertCell(3);
           cell5 = row.insertCell(4);
           cell6 = row.insertCell(5);
           cell7 = row.insertCell(6);
           cell1.innerHTML  = obj[j]['tanggal_transaksi'];
           cell2.innerHTML  = obj[j]['kode_transaksi'];
           cell3.innerHTML  = obj[j]['nis'];
           cell4.innerHTML  = obj[j]['nama_siswa'];
           cell5.innerHTML  = obj[j]['nama_pembayaran'];
           cell6.innerHTML  = obj[j]['tahun_ajaran'];
           cell7.innerHTML  = obj[j]['jumlah'];

           total+=parseInt(obj[j]['jumlah']);

           blm_bayar =jml_pembayaran-total;
           j++;

          }
          document.getElementById('kekurangan').value=blm_bayar;
          document.getElementById('jumlah_sdh').value=total;
      });
  }


</script>
<?php require '_footer.php'; ?>
