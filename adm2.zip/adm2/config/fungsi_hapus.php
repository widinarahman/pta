<?php

// transaksi
function hapus_transaksi($id)
{
  global $konek;
  $query="DELETE FROM transaksi WHERE kode_transaksi = '$id'";
  if(mysqli_query($konek,$query)) return true;
  else return false;
}
 ?>
