<?php

  function simpan_transaksi($kode_pembayaran, $id_admin, $kode_tahun_ajaran, $tanggal_transaksi, $jenis_transaksi, $jumlah, $keterangan)
  {
    global $konek;

    $query=" INSERT INTO transaksi (kode_pembayaran, id_admin, kode_tahun_ajaran, tanggal_transaksi, jenis_transaksi, jumlah, keterangan)
    VALUES ('$kode_pembayaran', '$id_admin', '$kode_tahun_ajaran', '$tanggal_transaksi', '$jenis_transaksi', '$jumlah', '$keterangan')";
    if (mysqli_query($konek, $query)) {
      return true;
    }else {
      return false;
    }
  }

  function simpan_detail_pembayaran($nis, $kode_transaksi)
  {
    global $konek;

    $query="INSERT INTO detail_pembayaran (nis, kode_transaksi, kode_semester, kode_bulan) VALUES('$nis', '$kode_transaksi' ,NULL, NULL)";
    if (mysqli_query($konek, $query)) {
      return true;
    }else {
      return false;
    }
  }
  function simpan_detail_pembayaran_semester($nis, $kode_transaksi,$kode_semester)
  {
    global $konek;

    $query="INSERT INTO detail_pembayaran (nis, kode_transaksi, kode_semester, kode_bulan) VALUES('$nis', '$kode_transaksi' ,'$kode_semester', NULL)";
    if (mysqli_query($konek, $query)) {
      return true;
    }else {
      return false;
    }
  }
  function simpan_detail_pembayaran_bulan($nis, $kode_transaksi,$kode_bulan)
  {
    global $konek;

    $query="INSERT INTO detail_pembayaran (nis, kode_transaksi, kode_semester, kode_bulan) VALUES('$nis', '$kode_transaksi' ,NULL,'$kode_bulan' )";
    if (mysqli_query($konek, $query)) {
      return true;
    }else {
      return false;
    }
  }
  function tampil_transaksi_pemasukan($kode_tahun_ajaran)
  {
    global $konek;
    $query="SELECT a.tanggal_transaksi, a.kode_transaksi, b.nis, b.nama_siswa, c.nama_pembayaran, e.bulan, f.semester,g.tahun_ajaran, a.jumlah FROM siswa b JOIN detail_pembayaran d ON b.nis = d.nis JOIN transaksi a ON d.kode_transaksi = a.kode_transaksi JOIN pembayaran c ON c.kode_pembayaran = a.kode_pembayaran LEFT JOIN bulan e ON d.kode_bulan = e.kode_bulan LEFT JOIN semester f ON d.kode_semester = f.kode_semester left join tahun_ajaran g on a.kode_tahun_ajaran=g.kode_tahun_ajaran WHERE a.kode_tahun_ajaran ='$kode_tahun_ajaran' order by a.tanggal_transaksi desc, a.kode_transaksi desc ";
    $result=mysqli_query($konek,$query) or die('gagal menampilkan data');
    return $result;

  }
  function tampil_transaksi_pengeluaran($kode_tahun_ajaran)
  {
    global $konek;
    $query = "SELECT b.tanggal_transaksi, b.kode_transaksi, d.nama_pengeluaran, a.nama_pembayaran, b.keterangan, e.tahun_ajaran, b.jumlah FROM pembayaran a JOIN transaksi b ON a.kode_pembayaran = b.kode_pembayaran JOIN detail_pengeluaran c ON c.kode_transaksi = b.kode_transaksi JOIN pengeluaran d ON d.kode_pengeluaran = c.kode_pengeluaran JOIN tahun_ajaran e ON e.kode_tahun_ajaran = b.kode_tahun_ajaran where b.kode_tahun_ajaran ='$kode_tahun_ajaran' ORDER BY b.tanggal_transaksi desc, b.kode_transaksi desc";
    $result=mysqli_query($konek,$query) or die('gagal menampilkan data');
    return $result;

  }

  function tampil_nm_pengeluaran()
  {
    global $konek;
    $query="SELECT * FROM pengeluaran";
    $result=mysqli_query($konek,$query) or die('gagal menampilkan data');
    return $result;

  }
  function input_nm_pengeluaran($nama_pengeluaran)
  {
    global $konek;
    $query ="INSERT INTO pengeluaran(nama_pengeluaran) VALUES ('$nama_pengeluaran')";
    if (mysqli_query($konek, $query)) {
      return true;
    }else {
      return false;
    }
  }
  function simpan_detail_pengeluaran($kode_pengeluaran, $kode_transaksi)
  {
    global $konek;
    $query="INSERT INTO detail_pengeluaran(kode_pengeluaran, kode_transaksi) VALUES ('$kode_pengeluaran', '$kode_transaksi')";
    if (mysqli_query($konek, $query)) {
      return true;
    }else {
      return false;
    }
  }
 ?>
