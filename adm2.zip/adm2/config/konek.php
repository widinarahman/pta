<?php
$konek =mysqli_connect("localhost", "root", "", "pta") or die (mysqli_error($konek));
// $konek =mysqli_connect("localhost", "root", "", "pta") or die (mysqli_error($konek));

// Check connection
// if (mysqli_connect_errno())
//   {
//   echo "Failed to connect to MySQL: " . mysqli_connect_error();
//   }
if ($konek->connect_error) {
die("Connection failed: " . $konek->connect_error);
}
// echo "Connected successfully";

date_default_timezone_set('Asia/Jakarta');
 ?>
