<?php
// Kelas
function tampil_peg()
{
  global $konek;
  $result="SELECT * FROM pegawai";
  $result=mysqli_query($konek,$query) or die('Gagal');
  return $result;
}
function tampilkelas()
{
 global $konek;
 $query ="SELECT * FROM kelas WHERE kode_kelas NOT IN ('do', 'nol','lulus') ORDER BY nama_kelas";
 $result=mysqli_query($konek,$query) or die('Gagal menampilkan Kelas');
 return $result;
}
function tampilall()
{
 global $konek;
 $query ="SELECT * FROM kelas ORDER BY nama_kelas";
 $result=mysqli_query($konek,$query) or die('Gagal menampilkan Kelas');
 return $result;
}
function tambahkelas($kd_kelas,$nm_kelas)
{
  global $konek;
  $query="INSERT INTO kelas(kode_kelas, nama_kelas) VALUES ('$kd_kelas', '$nm_kelas')";
    if (mysqli_query($konek, $query)) {
      return true;
    }else {
      return false;
    }
  }
function editkelas($nm_kelas,$kd_kelas)
{
  global $konek;
  $query="UPDATE kelas SET nama_kelas='$nm_kelas' WHERE kode_kelas='$kd_kelas'";
  return run($query);
}
function tampilkelaskd($kd_kelas)
{
  global $konek;
  $query="SELECT * FROM kelas WHERE kode_kelas='$kd_kelas'";
  $result=mysqli_query($konek, $query)or die('Gagal menampilkan Tahun Ajaran');
  return $result;
}
// Tahun Ajaran
function tampiltahunajaran()
{
  global $konek;
  $query= "SELECT * FROM tahun_ajaran";
  $result=mysqli_query($konek, $query)or die('Gagal menampilkan Tahun Ajaran');
  return $result;
}
function input_thn_ajaran($thn_ajaran, $status)
{
  global $konek;
  $query = "INSERT INTO tahun_ajaran(tahun_ajaran, status) VALUES ('$thn_ajaran', '$status')";
  if (mysqli_query($konek, $query)) {
    return true;
  }else {
    return false;
  }

}

function tampilpembayaran()
{
  global $konek;
  $query= "SELECT * FROM pembayaran";
  $result=mysqli_query($konek, $query)or die('Gagal menampilkan Pembayaran');
  return $result;
}
function inputpembayaran($kd_pembayaran, $nm_pembayaran, $ms_pembayaran, $sld_pembayaran)
{
  global $konek;
  $query="INSERT INTO pembayaran(kode_pembayaran, nama_pembayaran, masa_pembayaran, saldo_awal) VALUES ('$kd_pembayaran', '$nm_pembayaran', '$ms_pembayaran', '$sld_pembayaran')";
  if (mysqli_query($konek, $query)) {
    return true;
  }else {
    return false;
  }

}
function jumlahpembayaran()
{
  global $konek;
  $query="select a.nama_pembayaran,b.jumlah_pembayaran,c.tahun_ajaran from pembayaran a join pembayaran_tahun_ajaran b on a.kode_pembayaran=b.kode_pembayaran join tahun_ajaran c on b.kode_tahun_ajaran = c.kode_tahun_ajaran ORDER BY c.tahun_ajaran desc, a.nama_pembayaran";
  $result=mysqli_query($konek, $query)or die('Gagal menampilkan Pembayaran');
  return $result;

}
function inputjumlahpembayaran($kd_thn_ajaran, $kd_pembayaran, $jml_pembayaran)
{
  global $konek;
  $query="INSERT INTO pembayaran_tahun_ajaran(kode_tahun_ajaran, kode_pembayaran, jumlah_pembayaran) VALUES ('$kd_thn_ajaran', '$kd_pembayaran', '$jml_pembayaran')";
  if (mysqli_query($konek, $query)) {
    return true;
  }else {
    return false;
  }
}
function tampiladmin()
{
  global $konek;
  $query= "SELECT * FROM admin";
  $result=mysqli_query($konek, $query)or die('Gagal menampilkan Pembayaran');
  return $result;
}
function tampiladmin_id($id){
	global $konek;
	$query="SELECT * FROM admin WHERE id_admin='$id'";
	$result=mysqli_query($konek,$query) or die('gagal menampilkan data');
	return $result;
}

function tampilsiswa()
{

  	global $konek;
  	$query= "SELECT a.nis,a.nama_siswa,a.no_tlp, a.tempat_lahir,a.tanggal_lahir,a.alamat,a.jenis_kelamin,a.tahun_ajaran_masuk,a.kode_kelas,b.nama_kelas FROM siswa a join kelas b on a.kode_kelas=b.kode_kelas WHERE b.kode_kelas NOT IN('do','lulus') order by b.nama_kelas, a.nama_siswa DESC";
  	$result=mysqli_query($konek,$query) or die('gagal menampilkan data');
  	return $result;

}

function tampilsiswapernis($nis)
{

  	global $konek;
  	$query= "SELECT a.nis,a.nama_siswa,a.no_tlp, a.tempat_lahir,a.tanggal_lahir,a.alamat,a.jenis_kelamin,a.tahun_ajaran_masuk,a.kode_kelas,b.nama_kelas FROM siswa a join kelas b on a.kode_kelas=b.kode_kelas WHERE nis='$nis' ";
  	$result=mysqli_query($konek,$query) or die('gagal menampilkan data');
  	return $result;

}
function ceklogin($user_name, $password)
{
  global $konek;
  $sql="SELECT * FROM admin WHERE user_name='$user_name' AND password='$password'";
  $query=mysqli_query($konek, $sql);

  $cek=mysqli_fetch_array($query);
  $_SESSION['id_admin']=$cek['id_admin'];
  $_SESSION['user_name']=$cek['user_name'];
  $_SESSION['nama_admin']=$cek['nama_admin'];


  if (mysqli_num_rows($query)>0) {
    return true;

  }else {
    return false;
  }

}
function simpan_no_tabungan($no_rekening,$nis,$tgl_kepemilikan,$status)
{
    global $konek;
    $query="INSERT INTO no_tabungan(no_rekening, nis, tgl_kepemilikan, status) VALUES ('$no_rekening', '$nis', '$tgl_kepemilikan', '$status')";
    if (mysqli_query($konek, $query)) {
      return true;
    }else {
      return false;
    }
}
function simpanadmin($user_name, $password, $nama_admin, $alamat, $no_telepon, $status)
{
  global $konek;
  $query=" INSERT INTO admin(user_name, password, nama_admin, alamat, no_telepon, status) VALUES ('$user_name', '$password', '$nama_admin', '$alamat', '$no_telepon', '$status')";
  if (mysqli_query($konek, $query)) {
    return true;
  }else {
    return false;
  }
}

function updatesaldo($no_rekening, $saldo){
  $query ="UPDATE no_tabungan SET saldo = '$saldo' WHERE  no_rekening ='$no_rekening'";
  return run($query);

}
function tampilnasabah()
{
  global $konek;
  $query="SELECT a.no_rekening, a.saldo , a.nis, a.tgl_kepemilikan, a.status, b.nama_siswa FROM no_tabungan a JOIN siswa b on a.nis=b.nis ORDER BY a.no_rekening,b.nama_siswa DESC ";
  $result=mysqli_query($konek,$query) or die('gagal menampilkan data');
  return $result;

}
function nabung($no_rekening, $tgl_transaksi, $jumlah_penarikan, $jumlah_setor, $keterangan)
{
  global $konek;
  $query="INSERT INTO tabungan (no_rekening, tgl_transaksi,jumlah_penarikan, jumlah_setor, keterangan) VALUES ('$no_rekening', '$tgl_transaksi', '$jumlah_penarikan', '$jumlah_setor', '$keterangan')";
  if (mysqli_query($konek, $query)) {
    return true;
  }else {
    return false;
  }
}
function transaksi_tb()
{
  global $konek;
  $query="SELECT a.id_tabungan, a.no_rekening, a.tgl_transaksi, a.jumlah_penarikan, a.jumlah_setor, a.keterangan, a.no_rekening, b.nis FROM tabungan a join no_tabungan b ON a.no_rekening=b.no_rekening ORDER BY id_tabungan DESC ";
  $result=mysqli_query($konek,$query) or die('gagal menampilkan data');
  return $result;
}
function rupiah($angka){
$jadi =number_format($angka,0,',','.');
return $jadi;
}

// function simpan_transaksi($kode_transaksi, $kode_pemabayaran, $id_admin, $kode_tahun_ajaran, $tanggal_transaksi, $jenis_transaksi, $jumlah, $keterangan)
// {
//   global $konek;
//   $query = "INSERT INTO transaksi(kode_pembayaran, id_admin, kode_tahun_ajaran, tanggal_transaksi, jenis_transaksi, jumlah, keterangan) VALUES ('$kd_pembayaran', '$id_admin', '$kd_tahun_ajaran', '$tgl_transaksi', '$jns_transaksi','$jumlah','$keterangan')";
//   $query="INSERT INTO transaksi (kode_transaksi, kode_pemabayaran, id_admin, kode_tahun_ajaran, tanggal_transaksi, jenis_transaksi, jumlah, keterangan) VALUES (NULL, 'yuy', '3', '2', '2017-06-09', 'Pemasukan', '900', 'gjj')";
//   if (mysqli_query($konek, $query)) {
//     return true;
//   }else {
//     return false;
//   }
// }


function tampilpembayaran_thun_pertama()
{
  global $konek;
  $query="SELECT * FROM pembayaran WHERE masa_pembayaran='Tahun Pertama' ";
  $result=mysqli_query($konek,$query) or die('gagal menampilkan data');
  return $result;

}
function tampilpembayaran_sem()
{
  global $konek;
  $query="SELECT * FROM pembayaran WHERE masa_pembayaran='Persemester' ";
  $result=mysqli_query($konek,$query) or die('gagal menampilkan data');
  return $result;

}
function tampilpembayaran_bulan()
{
  global $konek;
  $query="SELECT * FROM pembayaran WHERE masa_pembayaran='Perbulan' ";
  $result=mysqli_query($konek,$query) or die('gagal menampilkan data');
  return $result;

}
function tampilpembayaran_pertahun()
{
  global $konek;
  $query="SELECT * FROM pembayaran WHERE masa_pembayaran='Pertahun' ";
  $result=mysqli_query($konek,$query) or die('gagal menampilkan data');
  return $result;

}

function thn_ajar_aktif()
{
  global $konek;
  $query="SELECT * FROM tahun_ajaran WHERE status='Aktif' ";
  $result=mysqli_query($konek,$query) or die('gagal menampilkan data');
  return $result;

}
function tampil_bulan()
{
  global $konek;
  $query="SELECT * FROM bulan";
  $result=mysqli_query($konek,$query) or die('gagal menampilkan data');
  return $result;

}

function hapus_siswa($nis)
{
  global $konek;
	$query="DELETE FROM siswa WHERE nis='$nis'";
	if(mysqli_query($konek,$query)) return true;
	else return false;
}

function hapus_transaksi_tb($id)
{
  global $konek;
	$query="DELETE FROM tabungan WHERE id_tabungan='$id'";
	if(mysqli_query($konek,$query)) return true;
	else return false;
}

function hapus_tb_nasbah($id)
{
  global $konek;
	$query="DELETE FROM no_tabungan WHERE no_rekening='$id'";
	if(mysqli_query($konek,$query)) return true;
	else return false;
}

function tambahsiswa($nis, $kode_kelas, $nama_siswa, $no_tlp, $alamat, $tempat_lahir, $tanggal_lahir, $jenis_kelamin, $tahun_ajaran_masuk)
{
  global $konek;
  $query ="INSERT INTO siswa (nis, kode_kelas, nama_siswa,no_tlp, alamat, tempat_lahir, tanggal_lahir, jenis_kelamin, tahun_ajaran_masuk)  VALUES ('$nis', '$kode_kelas', '$nama_siswa', '$no_tlp', '$alamat', '$tempat_lahir', '$tanggal_lahir', '$jenis_kelamin', '$tahun_ajaran_masuk')";
    if (mysqli_query($konek, $query)) {
      return true;
    }else {
      return false;
    }

}
function update_nasabah($status, $no_rekening)
{
  $query="UPDATE no_tabungan SET status='$status' WHERE no_rekening='$no_rekening'";
  return run($query);
}

// function ubh_TdkAktf()
// {
//   global $konek;
//   $query= "UPDATE tahun_ajaran SET status='Tidak Aktif' WHERE status='Aktif'";
//   return run($query);
// }
//
// function ubh_Aktf($kd_thn_ajaran)
// {
//   global $konek;
//   $query= "UPDATE tahun_ajaran SET status='Aktif' WHERE kode_tahun_ajaran='$kd_thn_ajaran'";
// ;
//   return run($query);
// }

?>
