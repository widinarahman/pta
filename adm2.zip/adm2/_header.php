<?php
  require_once 'config/config.php';
  session_start();
  if (!isset($_SESSION['mysesi']) && !isset($_SESSION['mytype'])=='Admin')
  {
    echo "<script>window.location.assign('login.php')</script>";
  }
  $tgl = date("Y-m-d");
  $id=$_SESSION['id_admin'];
  // echo  $_SESSION['id_admin'];
  $tampiladmin_id=tampiladmin_id($id);
  ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
	<meta http-equiv="x-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="apple-touch-icon" sizes="76x76" href="style/img/logo.png">
	<link rel="icon" type="image/png" sizes="96x96" href="style/img/logo.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

  <title>Adminisitrasi Keuangan</title>


  <!-- <script type="text/javascript" src="assets/jquery-number-master/jquery.number.min.js"></script> -->

  <script type="text/javascript" src="assets/jquery.js"></script>

  <link rel="stylesheet" href="style/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="style/font-awesome/ion/css/ionicons.min.css">

  <link rel="stylesheet" href="style/style_laporan.php">

	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="assets/DataTables/media/css/jquery.dataTables.css">
	<link rel="stylesheet" type="text/css" href="assets/DataTables/media/css/dataTables.bootstrap.css">

  <script type="text/javascript" src="assets/DataTables/media/js/jquery.js"></script>

    <script type="text/javascript" src="assets/DataTables/media/js/jquery.dataTables.js"></script>
    <!-- <script type="text/javascript" src="style/ridwan.min.js"></script> -->
    <!-- <link rel="stylesheet" type="text/css" href="assets/css/themify-icons.css"> -->
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
  	<link rel="stylesheet" type="text/css" href="assets/DataTables/media/css/jquery.dataTables.css">
     <!-- <link href="assets/themify-icons.css" rel="stylesheet"> -->
    <link rel="stylesheet" href="style/style.css">
      <script src="assets/js/bootstrap-datepicker.js"></script>
    <style type="text/css">
      label {
				width:20em;
				float: left;
			}
			label.error {
				font-family: verdana;
				float: right;
				color: red;
				padding-left: .1em;

			}
/*VALID*/
		.content{
			margin-top: 80px;
		}
    .right{
      #text-align: right;

    }
    body{
      color: #66615b;
      font-size: 14px;
    }
    .wrapper {
      position: relative;
      top: 0;
      height: 100vh;
    }
    .main-panel {
      background-color: #f4f3ef;
      position: relative;
      z-index: 2;
      /*float: right;*/
      /*width: calc(100% - 260px);*/
      /*min-height: 100%;*/
    }
	</style>
</head>
<body>
  <div class="wrapper">
    <div class="main-panel">
    <!-- header -->
    	<nav class="navbar navbar-default navbar-fixed-top">
    		<div class="container">
    			<div class="navbar-header">
    				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
    					<span class="sr-only">Toggle navigation</span>
    					<span class="icon-bar"></span>
    					<span class="icon-bar"></span>
    					<span class="icon-bar"></span>
    				</button>
    				<a class="navbar-brand visible-xs-block visible-sm-block" href="#"><b>Administrasi Keuangan</b></a>
    				<a class="navbar-brand hidden-xs hidden-sm" href="#">Administrasi Keuangan</a>
            <!-- <a class="navbar-brand" href="#">
              Administrasi Keuangan<img alt="Brand" src="style/img/logo.png" width="18%">
            </a> -->
          </div>
    			<div id="navbar" class="navbar-collapse collapse">
    				<ul class="nav navbar-nav">
    					<!-- <li><a href="index.php">Dashboard</a></li> -->
              <li><a href="siswa.php">Siswa</a></li>

              <li role="presentation" class="dropdown">
    						<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">Transaksi<samp class="caret"></samp>
    						</a>
    							<ul class="dropdown-menu">
    								<li><a href="transaksi_pemasukan.php">Pemasukan</a></li>
                    <li><a href="transaksi_pengeluaran.php">Pengeluaran</a></li>
    							</ul>
    					</li>
              <li role="presentation" class="dropdown">
    						<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">Setting<samp class="caret"></samp>
    						</a>
    							<ul class="dropdown-menu">
    								<li><a href="setting_kelas_data.php">Data Kelas</a></li>
                    <li><a href="setting_thn_ajaran.php">Data Tahun Ajaran</a></li>
                    <li><a href="setting_pembayaran.php">Pembayaran</a></li>
                    <li><a href="setting_jumlahpembayaran.php">Jumlah Pembayaran</a></li>
                    <li><a href="setting_admin.php">Data Admin</a></li>
    							</ul>
    					</li>
              <li role="presentation" class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">Tabungan<samp class="caret"></samp></a>
                  <ul class="dropdown-menu">
                    <li><a href="tabungan.php"> Tabungan</a></li>
                    <li><a href="tabungan_nasabah.php">Data Nasabah</a></li>
                    <li><a href="tabungan_setoran.php">Nabung</a></li>
                    <li><a href="tabungan_penarikan.php">Penarikan</a></li>

                  </ul>
               </li>
              <li><a href="">SMS Gateway</a></li>
              <li role="presentation" class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">Laporan<samp class="caret"></samp>
                </a>
                  <ul class="dropdown-menu">
                    <li><a href="laporan_siswa.php">Data Siswa</a></li>
                    <li><a href="laporan_tunggakan_Pbulan.php">Tunggakan Siswa Pem Bulan</a></li>
                    <li><a href="laporan_tunggakan_Psem.php">Tunggakan Siswa Pem Ses</a></li>
                    <li><a href="laporan_tunggakan_Pthn.php">Tunggakan Siswa Pem Tahun</a></li>
                    <li><a href="laporan_tunggakan_PAthn.php">Tunggakan Pem Awal Thn</a></li>
                    <li><a href="laporan_pemasukanpengeluaran.php">Laporan Pemasukan & Pengeluaran </a></li>
                    <!-- <li><a href="">Pemasukan / Pengeluaran </a></li> -->
                    <li><a href="laporan_keuangan.php">Laporan Keuangan</a></li>
                    <li><a href="">Laporan Tabungan</a></li>
                  </ul>
              </li>
    				</ul>
              <?php
              while ($a=mysqli_fetch_assoc($tampiladmin_id)) {

                ?>
            <ul class="nav navbar-nav navbar-right">
              <li><a href="#"><span class="label label-info"><?php echo $a['status']; ?></span></a></li>
              <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="glyphicon glyphicon-user"></i> <?php echo $a['nama_admin']; ?><span class="caret"></span></a>
                <ul class="dropdown-menu">
                  <li><a href="profil_view.php">Profil</a></li>
                  <li><a href="p_ubahpassword.php">Ubah password</a></li>
                  <li role="separator" class="divider"></li>
                  <li><a href="logout.php">Keluar</a></li>
                </ul>
              </li>
            </ul>
            <?php
          }
          ?>
    			</div><!--/.nav-collapse -->
  		  </div>
  	  </nav>
