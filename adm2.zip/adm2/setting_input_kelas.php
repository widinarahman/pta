<?php

  require 'config/config.php';
  require '_header.php';


  if (isset($_POST['submit'])) {
    $kd_kelas=$_POST['kd_kelas'];
    $nm_kelas=$_POST['nm_kelas'];

    $cekkd=strlen($nm_kelas);
    $cekks=strlen($nm_kelas);
    $cekkelas=mysqli_fetch_row(mysqli_query($konek, "SELECT * FROM kelas WHERE kode_kelas='$kd_kelas' or nama_kelas='$nm_kelas'"));
    // $cekkelas=cekkelas();

    if ( $cekkd < 3) {
      echo "<script>alert('Kode kelas harus terdiri dari 3 atau lebih karakter !')</script>";
    }
    elseif (preg_match('/[^a-z_\-0-9]/i',$kd_kelas)) {
      echo "<script>alert('Kode kelas hanya boleh angka dan huruf')</script>";
    }
    elseif ($cekks <3) {
      echo "<script>alert('Nama kelas harus terdiri dari 3 atau lebih karakter !')</script>";

    }
    elseif ($cekkelas > 0) {
      echo "<script>alert('Kode kelas atau nama kelas yang anda masukan sudah ada, silahkan masukan yang lain')</script>";
    }
    elseif(tambahkelas($kd_kelas, $nm_kelas)) {
      echo "<script>alert('Kelas baru berhasil tersimpan')</script>";
    }else {
      echo "Error: " . $query . "<br>" . mysqli_error($konek);
    }
  }

 ?>

<div class="container">
    <div class="content">
    <h4>Data Kelas</h4>
    <ol class="breadcrumb">
      <li class="ti-panel">
        <a href="index.php">Dasboard</a>
      </li>
      <li>
        <a href="setting_kelas_data.php">Data Kelas</a>
      </li>
      <li class="active">
        Input Kelas
      </li>
    </ol>

    <br>
    /*<style media="screen">
      .center{
        text-align: center;
      }
    </style>*/
    <div class="row">
      <div class="col-md-3"></div>
      <div class="col-md-6">
        <div class="alert alert-info" role="alert">
          <b>Info</b> Untuk menambah kelas silahkan masukan kode dan nama kelas. !
        </div>
        <form id="formContoh" action="" method="post">
          <div class="panel panel-default">
            <div class="panel-heading">Input Kelas Siswa </div>
            <div class="panel-body">
              <div class="col-md-12">
                <label class="col-sm-4 control-label" for="">Kode Kelas</label>
                <div class="col-sm-5">
                  <input  type="text" id="kd_kelas" class="form-control" placeholder="Kode Kelas" name="kd_kelas" minlength="3" data-fv-stringlength-message="Username harus lebih dari 4 Karakter">
                </div>
              </div>
              <div class="col-md-12">
                <label class="col-sm-4 control-label" for="">Nama Kelas</label>
                <div class="col-sm-5 ">
                  <input type="text" class="form-control" placeholder="Nama Kelas" name="nm_kelas"   value="" required>
                </div>
              </div>
              <div class="form-group">
                <div class="col-sm-4">
                  <input class="btn btn-default" type="submit" name="submit" value="Simpan">
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
  <!--  row-->
  <div class="row">
		<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
		<!-- Labz -->
		<ins class="adsbygoogle"
		     style="display:block"
		     data-ad-client="ca-pub-5604714187349049"
		     data-ad-slot="6910422014"
		     data-ad-format="auto"></ins>
		<script>
		(adsbygoogle = window.adsbygoogle || []).push({});
		</script>
	</div>

</div>
<script type="text/javascript">
// <script type="text/javascript">
function hanyaAngka(evt) {
  var charCode = (evt.which) ? evt.which : event.keyCode
   if (charCode > 31 && (charCode < 48 || charCode > 57))

    return false;
  return true;
}
</script>

</script>
<?php require '_footer.php'; ?>
