<?php
require 'config/config.php';
  require '_header.php';

  $result=jumlahpembayaran();
 ?>
<div class="container">
  <div class="content">
    <h4>Jumlah Pembayaran</h4>
    <ol class="breadcrumb">
      <li class="ti-panel">
        <a href="?">Dasboard</a>
      </li>
      <li class="active">
        Jumlah pembayaran
      </li>
    </ol>
    <div class="row">
      <div class="col-lg-5">
        <button class="btn btn-default" type="button" name="" value="Tambah" onclick="window.location.href='setting_input_jumlahpembayaran.php'">Tambah</button>
      </div>
    </div>
    <br>
    <div class="table-responsive">
      <table id="data" class="table table-striped table-bordered data">
        <thead>
          <tr>
            <th width="5%">No</th>
            <th width="40%">Nama Pembayaran</th>
            <th width="20%">Tahun Ajaran</th>
            <th width="25%">Jumlah Pembayaran</th>
            <th class="center" width="10%">Setting</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $no=1;
          while ($a=mysqli_fetch_assoc($result)) {
            ?>
              <tr>
                <td><?php echo $no; ?></td>
                <td><?php echo $a['nama_pembayaran']; ?></td>
                <td><?php echo $a['tahun_ajaran']; ?></td>
                <td><?php echo  rupiah($a['jumlah_pembayaran']); ?></td>

                <td class="center">
                  <a class="glyphicon glyphicon-edit"></a>
                  <a class="glyphicon glyphicon-trash" href="#"></a>
                </td>
              </tr>
            <?php
            $no++;
          }
          ?>
        </tbody>
      </table>
    </div>
  </div>
  </div>
<?php require '_footer.php'; ?>
