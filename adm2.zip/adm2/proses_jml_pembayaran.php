<?php
include 'config/config.php';

  $kode_pembayaran = $_GET['kode_pembayaran'];
  $kode_tahun_ajaran =$_GET['kode_tahun_ajaran'];
  $query = mysqli_query($konek, " SELECT * FROM pembayaran_tahun_ajaran WHERE kode_pembayaran='$kode_pembayaran'  AND kode_tahun_ajaran='$kode_tahun_ajaran'");
  $siswa = mysqli_fetch_array($query);
  $data = array(
            'jumlah_pembayaran'      =>  $siswa['jumlah_pembayaran'],
          );
 echo json_encode($data);
?>
