<?php
  require 'config/config.php';
  require '_header.php';
  $id=$_SESSION['id_admin'];
  $tampilprofil=tampiladmin_id($id);
 ?>
<div class="container">
  <div class="content">
    <h4>Data Kelas</h4>
    <ol class="breadcrumb">
      <li class="ti-panel">
        <a href="index.php">Dasboard</a>
      </li>

      <li class="active">
        Profil
      </li>
    </ol>

    <br>
    <style media="screen">
      .center{
        text-align: center;
      }
    </style>
    <div class="row">
      <div class="col-md-3">

      </div>
      <div class="col-md-6">
          <form class="" action="" method="post">
            <?php
            while ($a=mysqli_fetch_assoc($tampilprofil)) {
              $nama=$a['nama_admin'];
              $user=$a['user_name'];
              $alamat=$a['alamat'];
              $no=$a['no_telepon'];
              $status=$a['status'];
            // ?>
            <div class="panel panel-default">
              <div class="panel-heading">Profil  <b><?php echo $nama; ?></b></div>
              <div class="panel-body">
                <div class="form-group">
                  <label class="col-sm-4 control-label" for="">Nama </label>
                  <div class="col-sm-5 ">
                    <p><b><?php echo $nama; ?></b></p>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-4 control-label" for="">Username</label>
                  <div class="col-sm-5 ">
                    <p><b><?php echo $user; ?></b></p>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-4 control-label" for="">Alamat</label>
                  <div class="col-sm-5 ">
                    <p><b><?php echo $alamat; ?></b></p>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-4 control-label" for="">N0 </label>
                  <div class="col-sm-5 ">
                    <p><b><?php echo $no; ?></b></p>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-4 control-label" for="">Status</label>
                  <div class="col-sm-5 ">
                    <span class="label label-info"> <?php echo $status; ?></span>
                  </div>
                </div>
                <div class="form-group col-sm-12 margin_top">
                  <div class="col-sm-4">
                  </div>
                    <div class="col-sm-7  ">
                    <a class="btn btn-default" href="profil_edit.php?id=<?=$a['id_admin'];?>">Ubah</a>

                    <!-- <button type="button" href= name="button"></button> -->
                    <!-- <input  class="btn btn-default" type="submit" name="submit" value="Edit"> -->
                    <!-- <input class="btn btn-default" type="submit" name="submit" value="Cancel"> -->
                    </div>
                </div>

              </div>
            </div>
            <?php
          }
            ?>
        </form>
      </div>
    </div>
  </div>
</div>
<?php require '_footer.php'; ?>
