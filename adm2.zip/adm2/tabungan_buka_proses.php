<?php

include 'config/config.php';
$nim = $_GET['nis'];
$query= mysqli_query($konek, "SELECT a.nis,a.nama_siswa,a.tempat_lahir,a.tanggal_lahir,a.alamat,a.jenis_kelamin,a.tahun_ajaran_masuk,a.kode_kelas,b.nama_kelas FROM siswa a join kelas b on a.kode_kelas=b.kode_kelas WHERE a.nis='$nis' order by b.nama_kelas, a.nama_siswa");

$siswa=mysqli_fetch_array($query);
$data =array(
              'nama' => $siswa['nama'],
              'kelas' => $siswa['kelas'],
             );
echo json_encode($data);
 ?>
