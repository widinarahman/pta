<?php
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
require_once 'config/konek.php';

$username=$_POST['username'];
$password=($_POST['password']);
$id_login=($_POST['id_login']);
$password=sha1($password);
$login=$_POST['login'];

if(isset($login)){

  $res = $konek->query("SELECT * FROM admin where user_name='$username' and password='$password'");
  $row = $res->fetch_assoc();
  $id_admin = $row['id_admin'];
  $user = $row['user_name'];
  $pass = $row['password'];
  $nama = $row['nama_admin'];
  // $name = $row['nip'];
  $alamat = $row['alamat'];
  $no_tlf = $row['no_telepon'];
  $mytype = $row['status'];
  $mysesi = $row['user_name'];
  // $pass = $row['password'];
  $type = $row['status'];
  //
  // $hp = $row['no_telepon'];
  // $id_login = $row['id_admin'];

  if($user==$username && $pass=$password){
    session_start();
    if($type=="Admin"){
      $_SESSION['mysesi']=$user;
      $_SESSION['mytype']=$type;
      $_SESSION['name']=$name;
      echo $_SESSION['id_admin']=$id_admin;
      // $_SESSION['password']=$password;
      echo $_SESSION['mytype'];
      echo "<script>window.location.assign('index.php')</script>";
    } else if($type=="Staf TU"){
      $_SESSION['mysesi']=$user;
      $_SESSION['mytype']=$type;

      echo $_SESSION['id_admin']=$id_admin;
      // $_SESSION['password']=$password;
      echo $_SESSION['mytype'];

      echo "<script>window.location.assign('index_tu.php')</script>";
    }else if ($type =="staf_tb") {
      $_SESSION['mysesi']=$name;
      $_SESSION['mytype']=$type;
      echo "<script>window.location.assign('index_tb.php')</script>";
    }else{
      ?>
      <div class="alert alert-warning alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
        <strong>Maaf!</strong> Tidak sesuai dengan type user.
      </div>
      <?php
    }
  } else{
    ?>
    <div class="alert alert-danger alert-dismissible" role="alert">
      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
      <strong>Warning!</strong> username atau password tidak cocok.
    </div>
    <?php
  }
}
//require_once '_header.php';


?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Administrasi Keuangan</title>
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
    <style media="screen">
      .login {
        margin-top: 50px;
      }
    </style>
  </head>
  <body>

  <div class="container">
    <div class="row">
      <div class="col-md-3">

      </div>
      <div class="col-md-5 login">
        <div class="well">
          <div class="header">
            <center><img src="style/img/logo.png" width="20%" alt=""></center>
          </div>
          <form class="" action="" method="post">
            <div class="form-group">
              <label for="">username</label>
              <input type="text" id="username" name="username" class="form-control">
            </div>
            <div class="form-group">
              <label for="">Password</label>
              <input type="password" id="password" name="password" class="form-control">
            </div>
            <button type="submit" name="login" class="btn btn-primary"> Login</button>
          </form>
        </div>
      </div>
    </div>
  </div>

</body>
</html>
