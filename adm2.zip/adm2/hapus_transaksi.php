<?php

require_once 'config/config.php';

if(isset($_GET['id'])){
  if(hapus_transaksi($_GET['id'])){
    echo "<script>document.location.href='transaksi_pemasukan.php';</script>";
  }else{

   echo "gagal menghapus data";
 }
 }

?>
