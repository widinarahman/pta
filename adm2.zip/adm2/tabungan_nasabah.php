<?php
  require 'config/config.php';
  require '_header.php';

  $result=tampilnasabah();
 ?>
<div class="container">
  <div class="content">
    <h4>Data Nasabah</h4>
    <ol class="breadcrumb">
      <li class="ti-panel">
        <a href="?">Dasboard</a>
      </li>
      <li>
        <a href="tabungan.php">Tabungan</a>
      </li>
      <li class="active">
        Data Nasabah
      </li>
    </ol>
    <div class="row">
      <div class="col-lg-5">
        <button class="btn btn-default" type="button" name="" value="Tambah" onclick="window.location.href='tabungan_buka.php'">Daftar</button>
      </div>
    </div>
    <br>
    <style media="screen">
      .center{
        text-align: center;
      }
    </style>
    <div class="table-responsive">
      <table id="data" class="table table-striped table-bordered data">
        <thead>
          <tr>
            <th width="5%">No</th>
            <th width="10%">Tgl Daftar</th>
            <th width="15%">No rekening</th>
            <th width="15%">Saldo</th>
            <th width="15%">NIS</th>
            <th width="20%">Nama</th>
            <th width="10%">Status</th>
            <th class="center" width="10%">Setting</th>
          </tr>
        </thead>
        <tbody>
        <?php
        $no=1;
        while ($a=mysqli_fetch_assoc($result)) {

            ?>
              <tr>

                <td><?php echo $no; ?></td>
                <td><?php echo $a['tgl_kepemilikan']; ?></td>
                <td><?php echo $a['no_rekening']; ?></td>
                <td><?php echo rupiah($a['saldo']); ?></td>
                <td><?php echo $a['nis']; ?></td>
                <td><?php echo $a['nama_siswa']; ?></td>
                <td><?php
                    if ($a['status'] =="Aktif") {
                      echo "<p class='label label-success'>Aktif</p>";
                    }else {
                      echo "<p class='label label-danger'>Tidak Aktif</p>";
                    }
                //echo $a['status']; ?></td>
                <td class="center">
                  <a class="glyphicon glyphicon-edit" href="tabungan_nasabah_edit.php?id=<?=$a['no_rekening'];?>"></a>
                  <a class="glyphicon glyphicon-trash" href="tabungan_nasabah_hapus.php?id=<?=$a['no_rekening'];?>" onclick="return confirm('Yakin anda ingin menghapusnya NO Rekening <?=$a['no_rekening']?>')"></a>
                  <!-- <a class="glyphicon glyphicon-eye-open" href="#"></a> -->
                </td>

              </tr>
            <?php
            $no++;
          }
          ?>
        </tbody>
      </table>
    </div>
  </div>
  </div>
<?php require '_footer.php'; ?>
