<?php

  require 'config/config.php';
  require '_header.php';

  $result=tampilkelas();

 ?>
 <style media="screen">
 /*<style>*/
   /* General */

   table {
     border-collapse:collapse;
   }

   .center {
     text-align:center;
   }

   .right {
     text-align : right;
   }

   .left {
     text-align : left;
   }

   tr {
     margin : 5px 0 ;
     line-height : 18px;
   }

   th {
     text-align : center;
     padding : 10px 0;
   }

   td {
     padding: 5px 0;
     word-wrap: break-word;
   }

   tr td.label {
     width : 100px;
   }

   .item-header {
     margin : 15px 0;
   }

   table.item-detail,
   table.item-detail	th,
   table.item-detail td {
     border : 1px solid #000;
   }

   /* Header */

   #header {
     /*width : 755px;*/
     padding-bottom : 5px;
     border-bottom:3px solid #000;
     /*//text-align:center;*/

   }
   #logo {
     float:left;
     display:inline;
     width : 100px;
     margin-top: 10px;
   }
   #kop-surat {
     margin-top : -100;

     width : 700px;
     display:inline-block;
     text-align : center;
   }
   #separator {
     padding : 2px 0;
     border-bottom:1px solid #000;
   }

   /* Content */

   #content {
     width : 755px;
   }

   #report-title {
     font-size : 16px;
     text-align : center;
     margin-bottom:10px;
   }

   table.item-summary {
     margin : 15px 0;
   }

   .currency {

   }

   .space {
     width:20px;
   }
   .laporan{
     background-color: #ffffff;
     padding-right: 15px;
     padding-left: 15px;
     width: 1050px;
     margin-left: 95px;
   /*text-align: center;*/
   }
   thead{
     color: #ffffff;
   }

 </style>
<div class="container">
  <div class="content">
    <h4> Data Siswa</h4>
    <ol class="breadcrumb">
      <li class="ti-panel">
        <a href="?">Dasboard</a>
      </li>
      <li class="active">
        Laporan Data Siwa
      </li>
    </ol>

    <div class="form-group col-sm-12">
      <div class="col-sm-2">
        <label class="control-label" for="">Saldo Tabungan</label>
      </div>
      <div class="col-sm-2 margin">
        <select id="kode_kelas" class="" name="">
           <option>Pilih Kelas</option>
          <?php
            while ($a=mysqli_fetch_assoc($result)) {
           ?>
          <option value="<?php echo $a['kode_kelas']; ?>" onclick="isi_otomatis()"><?php echo $a['nama_kelas']; ?></option>

          <?php } ?>
        </select>

        <!-- <input  type="text" class="form-control" placeholder="" name="saldo" id="saldo"  value=""  disabled> -->
      </div>
      <div class="col-sm-3">
        <button class="btn btn-default" type="button" name="" value="" onclick="">Cetak</button>
      </div>
    </div>

    <!-- <div class="row">
      <div class="col-md-12">
        <div class="col-sm-1">
        </div>
        <div class="col-sm-1">
          <label for="">Kelas</label>
        </div>
        <div class="col-sm-">
          <select id="kode_kelas" class="" name="">
             <option>Pilih Kelas</option>
            <?php
              while ($a=mysqli_fetch_assoc($result)) {
             ?>
            <option value="<?php echo $a['kode_kelas']; ?>" onclick="isi_otomatis()"><?php echo $a['nama_kelas']; ?></option>

            <?php } ?>
          </select>
          <button class="btn btn-default" type="button" name="" value="" onclick="">Cetak</button>
        </div>
      </div>
    </div> -->
    <br>
    <br>

  <div class="laporan">
    <br>
    <div id="header">
 			<div id="logo">
 				<img src="style/img/logo.png" alt="" style="width:80%;"/>
 			</div><br>
 			<div id="kop-surat" style="margin-left:50px;">
 				<h4><b>SMK BISMA KERSANA</b></h4>
 				<p style="font-size:12px;">

 					Kecamatan Kersana, Brebes, Jawa Tengah.<br>
 					Telp : 4248755,4221111,4265555 <br />
 					<!-- Email : yayasandaarulhikmah@gmail.com<br /> -->
 				</p>
 			</div>
 		</div>
    <br>
    <div class="" style="text-align:center">
      <hp><b>Data Siswa</p>
    </div>
    <!-- <p>Jenis Pembayaran :<input type="text" name="" value="" disabled> </p>
    <p>Tahun Ajaran :<input type="text" name="" value="" disabled> </p> -->

    <br>

    <div class="table-responsive">
      <table id="data2" class="table table-striped table-bordered data">
        <thead style="background-color:#434747; ">
          <tr>
            <!-- <th width="5%">NO</th> -->
            <th width="5%">NIS</th>
            <th width="18%">Nama Siswa</th>
            <th width="10%">Jenis Kelamin </th>
            <tH width="7%">Tempat</th>
            <th width="10%">Tanggal Lahir</th>
            <th width="12%">Kelas</th>
            <th width="10%">T Masuk</th>
            <th width="20%">Alamat</th>
          </tr>
        </thead>
        <tbody id="datax">
        </tbody>
      </table>
    </div>
    </div>
  </div>
  </div>
  <script type="text/javascript">

  function isi_otomatis() {
    var kode_kelas =$("#kode_kelas").val();
    // $.ajax({
    //     url: 'proses-ajax3.php',
    //     data:{
    //       mode:'detail_mhs', kode_kelas:kode_kelas}
    //     // data:"nis="+nis ,
    // }).success(function (data) {
    //     var json = data,
    //     obj = JSON.parse(json);
    //     $('#kode_kelas').val(obj.kode_kelas);
    //
    //     if (obj.kode_semester == 1) {
    //     }
    //
    // });

    get_table(kode_kelas)
  }
  function get_table(kode_kelas) {
    $.ajax({
      url: 'proses_ajax3.php',
      data:{mode:'get_table', kode_kelas:kode_kelas}
    }).success(function(data){
      var json = data,
      obj = JSON.parse(json);
      var tabeldata = document.getElementById('data2').getElementsByTagName('tbody')[0];
      var j = 0;
      document.getElementById('datax').innerHTML= "";
      for (var i = obj.length - 1; i >= 0; i--) {
       row = tabeldata.insertRow(tabeldata.rows.length);
       row.value = i;
              cell1 = row.insertCell(0);
              cell2 = row.insertCell(1);
              cell3 = row.insertCell(2);
              cell4 = row.insertCell(3);
              cell5 = row.insertCell(4);
              cell6 = row.insertCell(5);
              cell7 = row.insertCell(6);
              cell8 = row.insertCell(7);
              cell1.innerHTML  = obj[j]['nis'];
              cell2.innerHTML  = obj[j]['nama_siswa'];
              cell3.innerHTML  = obj[j]['jenis_kelamin'];
              cell4.innerHTML  = obj[j]['tempat_lahir'];
              cell5.innerHTML  = obj[j]['tanggal_lahir'];
              cell6.innerHTML  = obj[j]['nama_kelas'];
              cell7.innerHTML  = obj[j]['tahun_ajaran_masuk'];

              cell8.innerHTML  = obj[j]['alamat'];
      j++;
      }
  });

  }
    // function isi_otomatis() {
    //   var kode_kelas =$("#kode_kelas").val();
    //   $.ajax({
    //     url:'proses-ajax3.php',
    //     data:{
    //       mode:'detail_mhs',kode_kelas:kode_kelas
    //     }
    //   }).success(function (data) {
    //       var json = data,
    //       obj = JSON.parse(json);
    //       $('#kode_kelas').val(obj.kode_kelas);
    //
    //       if (obj.kode_semester == 1) {
    //       }
    //       var tabeldata = document.getElementById('data2').getElementsByTagName('tbody')[0];
    //       var j = 0;
    //       document.getElementById('datax').innerHTML= "";
    //
    //       for (var i = obj.length - 1; i >= 0; i--) {
    //       row = tabeldata.insertRow(tabeldata.rows.length);
    //       row.value = i;
    //        cell1 = row.insertCell(0);
    //        cell2 = row.insertCell(1);
    //        cell3 = row.insertCell(2);
    //        cell4 = row.insertCell(3);
    //        cell5 = row.insertCell(4);
    //        cell6 = row.insertCell(5);
    //        cell7 = row.insertCell(6);
    //        cell8 = row.insertCell(7);
    //        cell1.innerHTML  = obj[j]['nis'];
    //        cell2.innerHTML  = obj[j]['nama_siswa'];
    //        cell3.innerHTML  = obj[j]['tempat_lahir'];
    //        cell4.innerHTML  = obj[j]['tanggal_lahir'];
    //        cell5.innerHTML  = obj[j]['alamat'];
    //        cell6.innerHTML  = obj[j]['jenis_kelamin'];
    //        cell7.innerHTML  = obj[j]['tahun_ajaran'];
    //       cell7.innerHTML  = obj[j]['nama_kelas'];
    //
    //   });
    //   get_table(kode_kelas)
    //   }
  </script>
<?php require '_footer.php'; ?>
