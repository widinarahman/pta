<?php
    session_start();
    echo "<script>window.location.assign('login.php')";
    session_destroy();
?>
