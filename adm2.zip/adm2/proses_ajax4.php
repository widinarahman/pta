<?php
  include 'config/config.php';
  $mode = $_GET['mode'];


    switch ($mode) {

      	case 'get_table':

        $kd_pem=$_GET['kd_pem'];
        $kd_thn=$_GET['kd_thn'];
      	//$kode_kelas = $_GET['kode_kelas'];

        $sp ="CALL sp_TunggakanPerbulan ('$kd_pem', '$kd_thn')";

        // $r=$konek->query($sp);
        $query=mysqli_query($konek,$sp);


        // $query ="SELECT a.nis,a.nama_siswa,a.tempat_lahir,a.tanggal_lahir,a.alamat,a.jenis_kelamin,a.tahun_ajaran_masuk,a.kode_kelas,b.nama_kelas
        //           from siswa a join kelas b on a.kode_kelas=b.kode_kelas
        //           where a.kode_kelas = '$kode_kelas'
        //           order by b.nama_kelas, a.nama_siswa";
        // $query = mysqli_query($konek, $query);
      ///  $datatable = mysqli_fetch_array($query,MYSQLI_NUM);
        $data = [];
        $i = 0;
        while ($datatable=mysqli_fetch_array($query)) {
        $data[$i]=  array(
                      'nis' => $datatable['0'],
                      'nama_siswa' => $datatable['1'],
                      'nama_kelas' => $datatable['2'],
                      'jul' => $datatable['3'],
                      'agu' => $datatable['4'],
                      'sept' => $datatable['5'],
                      'okt' => $datatable['6'],
                      'nov' => $datatable['7'],
                      'des' => $datatable['8'],
                      'jan' => $datatable['9'],
                      'feb' => $datatable['10'],
                      'mar' => $datatable['11'],
                      'apr' => $datatable['12'],
                      'mei' => $datatable['13'],
                      'juni' => $datatable['14'],
                      'sudahByr' => $datatable['15'],



                      );
                    $i++;

                  }
                  echo json_encode($data);


                  default:
                    // echo "wee error";
                  break;


      }
 ?>
