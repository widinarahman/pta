<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <form class="" action="index.html" method="post">
      <table>
        <tr>
          <td>Nim</td>
        </tr>
      </table>
    </form>
  </body>
</html>
