<?php
require 'config/config.php';
require '_header.php';

$result1=tampil_bulan();
//$result2=tampilpembayaran_sem();

// $kode_pem =99;
// $kode_thn=2;
//
// $sp ="CALL sp_TunggakanPerbulan ('$kode_pem', '$kode_thn')";

// $r=$konek->query($sp);
//$querypro=mysqli_query($konek,$sp);

?>
<style media="screen">
/*<style>*/
  /* General */

  table {
    border-collapse:collapse;
  }

  .center {
    text-align:center;
  }

  .right {
    text-align : right;
  }

  .left {
    text-align : left;
  }

  tr {
    margin : 5px 0 ;
    line-height : 18px;
  }

  th {
    text-align : center;
    padding : 10px 0;
  }

  td {
    padding: 5px 0;
    word-wrap: break-word;
  }

  tr td.label {
    width : 100px;
  }

  .item-header {
    margin : 15px 0;
  }

  table.item-detail,
  table.item-detail	th,
  table.item-detail td {
    border : 1px solid #000;
  }

  /* Header */

  #header {
    /*width : 755px;*/
    padding-bottom : 5px;
    border-bottom:3px solid #000;
    /*//text-align:center;*/

  }
  #logo {
    float:left;
    display:inline;
    width : 100px;
    margin-top: 10px;
  }
  #kop-surat {
    margin-top : -100;
    width : 700px;
    display:inline-block;
    text-align : center;
  }
  #separator {
    padding : 2px 0;
    border-bottom:1px solid #000;
  }

  /* Content */

  #content {
    width : 755px;
  }

  #report-title {
    font-size : 16px;
    text-align : center;
    margin-bottom:10px;
  }

  table.item-summary {
    margin : 15px 0;
  }

  .currency {

  }

  .space {
    width:20px;
  }
  .laporan{
    background-color: #ffffff;
    padding-right: 15px;
    padding-left: 15px;
    width: 1050px;
    margin-left: 95px;
  /*text-align: center;*/
  }
  thead{
    color: #ffffff;
  }
</style>
<div class="container">
  <div class="content">
    <h4> Laporan</h4>
    <ol class="breadcrumb">
      <li class="ti-panel">
        <a href="?">Dasboard</a>
      </li>
      <li class="active">
        Laporan Pemasukan dan Pengeluaran
      </li>
    </ol>
    <div class="row">
    <div class="form-group col-sm-12">
      <div class="col-sm-2">
        <label class="control-label" for="">Jenis Pembayaran</label>
      </div>
      <div class="col-sm-2 margin">
        <select id="kd_pem" class="" name="">
          <option value="">Pilih Tahun</option>
            <option value="2016">2016</option>
            <option value="2017">2017</option>
            <option value="2018">2018</option>
            <option value="2019">2019</option>
            <option value="2020">2020</option>
            <option value="2021">2021</option>
            <option value="2022">2022</option>
            <option value="2023">2023</option>

        </select>
      </div>
      <div class="col-sm-2">
        <label class="control-label" for="" style="text-align:center">Tahun Ajaran</label>
      </div>
      <div class="col-sm-2 margin">
        <select id="kd_thn" class="" name="">
          <option value="">Pilih Bulan</option>

            <option value="1"  onclick="isi_otomatis()">Januari</option>
            <option value="2"  onclick="isi_otomatis()">Febuari</option>
            <option value="3"  onclick="isi_otomatis()">Maret</option>
            <option value="4"  onclick="isi_otomatis()">April</option>
            <option value="5"  onclick="isi_otomatis()">Mei</option>
            <option value="6"  onclick="isi_otomatis()">Juni</option>
            <option value="7"  onclick="isi_otomatis()">Juli</option>
            <option value="8"  onclick="isi_otomatis()">Agustus</option>
            <option value="9"  onclick="isi_otomatis()">September</option>
            <option value="10"  onclick="isi_otomatis()">Oktober</option>
            <option value="11"  onclick="isi_otomatis()">November</option>
            <option value="12"  onclick="isi_otomatis()">Desember</option>

        </select>
      </div>
      <div class="col-sm-3">
        <button class="btn btn-default" type="button" name="" value="" onclick="">Cetak</button>
      </div>
    </div>
    </div>
    <!--Pembayaran-->

    <br>
    <div class="laporan">
      <br>
      <div id="header">
   			<div id="logo">
   				<img src="style/img/logo.png" alt="" style="width:80%;"/>
   			</div><br>
   			<div id="kop-surat" style="margin-left:50px;">
   				<h4><b>SMK BISMA KERSANA</b></h4>
   				<p style="font-size:12px;">

   					Kecamatan Kersana, Brebes, Jawa Tengah.<br>
   					Telp : 4248755,4221111,4265555 <br />
   					<!-- Email : yayasandaarulhikmah@gmail.com<br /> -->
   				</p>
   			</div>
   		</div>
      <br>
      <div class="" style="text-align:center">
        <hp><b>Laporan Pemasukan dan Pengeluaran</b></p>
      </div>
      <!-- <p>Jenis Pembayaran :<input type="text" name="" value="" disabled> </p>
      <p>Tahun Ajaran :<input type="text" name="" value="" disabled> </p> -->

      <br>
    <div class="table-responsive">
      <table id="data2" class="table table-striped table-bordered data">
        <thead style="background-color:#434747;" >
          <tr>
            <td>Tanggal</td>
            <td>Nama Pembayaran</td>
            <td>Jenis Transaksi</td>
            <td><b>Total</b></td>

          </tr>
        </thead>
          <tbody id="datax">

              <?php
                // while ($result= mysqli_fetch_array($querypro)) {
                //   $data1=$result['0'];
                //   $data2=$result['1'];
                //   $data3=$result['2'];
                //   $data4=$result['3'];
                //   $data5=$result['4'];
                //   $data6=$result['5'];
                //   $data7=$result['6'];
                //   $data8=$result['7'];
                //   $data9=$result['8'];
                //   $data10=$result['9'];
                //   $data11=$result['10'];
                //   $data12=$result['11'];
                //   $data13=$result['12'];
                //   $data14=$result['13'];
                //   $data15=$result['14'];
                //   $data16=$result['15'];
              ?>
            <!-- <tr>
              <td><?php //echo $data1;  ?></td>
              <td><?php //echo $data2;  ?></td>
              <td><?php //echo $data3;  ?></td>
              <td><?php //echo $data4;  ?></td>
              <td><?php //echo $data5;  ?></td>
              <td><?php //echo $data6;  ?></td>
              <td><?php //echo $data7;  ?></td>
              <td><?php //echo $data8;  ?></td>
              <td><?php //echo $data9;  ?></td>
              <td><?php //echo $data10;  ?></td>
              <td><?php //echo $data11;  ?></td>
              <td><?php //echo $data12;  ?></td>
              <td><?php //echo $data13;  ?></td>
              <td><?php //echo $data14;  ?></td>
              <td><?php //echo $data15;  ?></td>
              <td><?php //echo $data16;  ?></td>

            </tr> -->
          <?php


//        }
          ?>

      </tbody>
     </table>
  </div>
</div>
<script type="text/javascript">
    function isi_otomatis(){
      var kd_pem=$("#kd_pem").val();
      var kd_thn=$("#kd_thn").val();
      if($("#kd_thn").val()==null){
        kd_thn=0;
      }
      if($("#kd_pem").val()==null){
        kd_pem=0;
      }

      get_table(kd_pem, kd_thn);
    }
    function get_table(kd_pem, kd_thn) {
      $.ajax({
        url:'proses_ajax6.php',
        data:{mode:'get_table', kd_pem:kd_pem, kd_thn:kd_thn}
      }).success(function(data){
        var json = data,
        obj = JSON.parse(json);
        var tabeldata = document.getElementById('data2').getElementsByTagName('tbody')[0];
        var j = 0;
        document.getElementById('datax').innerHTML= "";
        for (var i = obj.length - 1; i >= 0; i--) {
         row = tabeldata.insertRow(tabeldata.rows.length);
         row.value = i;
                cell1 = row.insertCell(0);
                cell2 = row.insertCell(1);
                cell3 = row.insertCell(2);
                cell4 = row.insertCell(3);

                cell1.innerHTML  = obj[j]['tanggal'];
                cell2.innerHTML  = obj[j]['nm_pm'];
                cell3.innerHTML  = obj[j]['jns_trns'];
                cell4.innerHTML  = obj[j]['total'];


        j++;
        }
    });

    }
</script>

<?php
 //mysqli_free_result($r);
require '_footer.php';
 ?>
